<?php $__env->startSection('content'); ?>

    <div class="panel panel-success">
        <div class="panel-heading">Manufacturers</div>
        <div class="panel-body">
            <table class="table table-hover">
                <thead>
                    <th>Manufacturer Id</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact No</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(URL::to('/')); ?>/updateManufacturerDetails?id=<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->id); ?></td>
                          
                        <td><?php echo e($manufacturer->proc != null ?$manufacturer->proc->name:''); ?></td>
                        <td><?php echo e($manufacturer->address); ?></td>
                        <td><?php echo e($manufacturer->proc != null ? $manufacturer->proc->contact:''); ?></td>
                        <td><a href="<?php echo e(URL::to('/')); ?>/updateManufacturerDetails?id=<?php echo e($manufacturer->id); ?>" class="btn btn-primary btn-sm">Edit</a>
                         <a class="btn btn-sm btn-success btn-sm" name="addenquiry" href="<?php echo e(URL::to('/')); ?>/manuenquiry?projectId=<?php echo e($manufacturer->id); ?>" style="color:white;font-weight:bold;padding: 6px;">Add Enquiry</a>
                     </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.leheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>