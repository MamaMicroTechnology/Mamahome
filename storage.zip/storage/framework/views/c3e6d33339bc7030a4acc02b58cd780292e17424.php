<?php $__env->startSection('content'); ?>
<style type="text/css">
  .dot {
    height: 9px;
    width: 9px;
    background-color:green;
    border-radius: 50%;
    display: inline-block;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <?php if(session('Added')): ?>
                <div class="alert alert-success alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session('Added')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('NotAdded')): ?>
               <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                   <?php echo e(session('NotAdded')); ?>

                </div>
            <?php endif; ?>
            <button class="btn btn-default form-control" data-toggle="modal" data-target="#addEmployee" style="background-color:green;color:white;font-weight:bold">Add Employee </button>
            <br><br>
            <div class="panel panel-default" style="border-color:#f4811f">
                <div class="panel-heading" style="background-color:#f4811f"><b style="font-size:1.3em;color:white">Departments</b></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $content = explode(" ",$department->dept_name);
                            $con = implode("",$content);
                        ?>
                        <a id="<?php echo e($con); ?>" class="list-group-item" href="#"><?php echo e($department->dept_name); ?> (<?php echo e($depts[$department->dept_name]); ?>)</a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a id="FormerEmployees" class="list-group-item" href="#">Former Employees (<?php echo e($depts["FormerEmployees"]); ?>)</a>
                </div>
            </div>
        </div>
        <div class="col-md-10" id="disp">
                       
                          <br><br><br><br>
                           <img src="http://mamahome360.com/public/android-icon-36x36.png">
                           MAMA HOME PVT LTD&nbsp;&nbsp;
                           Total employees &nbsp;&nbsp;<span class="dot" style=" height: 9px;
    width: 9px;
    background-color:green;
    border-radius: 50%;
    display: inline-block;"></span> <?php echo e($totalcount); ?>

        </div>
 
<!--Modal-->
<form method="post" action="<?php echo e(URL::to('/')); ?>/amaddEmployee">
    <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="addEmployee" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#f4811f;color:white;fon-weight:bold">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Employee</h4>
        </div>
        <div class="modal-body">
          <table class="table table-hover">
              <tbody>
                  <tr>
                    <td><label>Emp Id</td>
                    <td> <input required type="text" placeholder="Employee Id" class="form-control" name="employeeId"></td>
                  </tr>
                  <tr>
                    <td><label>Name</label></td>
                    <td><input required type="text" placeholder="Name" class="form-control" name="name"></td>
                  </tr>
                  <tr>
                    <td><label>User-Id Of MMT</label></td>
                    <td><input required type="text" placeholder="User-id of MMT" class="form-control" name="email"></td>
                  </tr>
                  <tr>
                    <td><label>Department</label></td>
                      <td><select required class="form-control" name="dept">
                      <option value="">--Select--</option>
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select></td>
                  </tr>
                  <tr>
                    <td><label>Designation</label></td>
                    <td> <select required class="form-control" name="designation">
                      <option value="">--Select--</option>
                      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->group_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select></td>
                  </tr> 
                </tbody>
              </table>
            </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-success">Add</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

</form>
<!-- <div class="col-md-10">
        <div class="panel panel-default">
        <div class="panel-heading" style="background-color: green;color: white;padding-bottom: 20px;">Edit Asset Details
        <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
        </div>
        <div class="panel-body">
             <?php if(session('Success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('Success')); ?>

                        </div>
               <?php endif; ?>
        </div>
    </div>
</div> -->

<div class='b'></div>
<div class='bb'></div>
<div class='message'>
  <div class='check'>
    &#10004;
  </div>
  <p>
    Success
  </p>
  <p>
    <?php if(session('Success')): ?>
    <?php echo e(session('Success')); ?>

    <?php endif; ?>
  </p>
  <button id='ok'>
    OK
  </button>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
    $content = explode(" ",$department->dept_name);
    $con = implode("",$content);
?>
<script type="text/javascript">
$(document).ready(function () {
    $("#<?php echo e($con); ?>").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewmhemployee?count=<?php echo e($depts[$department->dept_name]); ?>&&dept="+encodeURIComponent("<?php echo e($department->dept_name); ?>"), function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
</script>
<script type="text/javascript">
$(document).ready(function () {
    $("#FormerEmployees").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewmhemployee?dept=FormerEmployees&&count=<?php echo e($depts["FormerEmployees"]); ?>", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>