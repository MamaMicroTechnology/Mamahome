<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" style="border-color:#f4811f">
                <div class="panel-heading text-center" style="background-color:#f4811f"><b style="color:white;font-size:1.3em">Assign Enquiry</b>
                    <?php if(session('Error')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('Error')); ?></div>
                    <?php endif; ?>
                       <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button>   
                </div>
                <div class="panel-body">
                 
             <div class="panel-body">
    <form method="POST" name="myform" action="<?php echo e(URL::to('/')); ?>/enquirystore" enctype="multipart/form-data">

  <?php echo e(csrf_field()); ?>

             <table class="table table-responsive table-striped table-hover" class="table">
              
                        <thead>
                            <th style="width:15%">Name</th>
                            <th style="width:15%">Designation</th>
                            <th style="width:15%">Action </th>
                            <th></th>
                          </thead>
                          <?php if(Auth::user()->group_id != 22): ?>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                           <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->group_name); ?></td>
                           
                             <td><button onclick="makeUserId('<?php echo e($user->id); ?>')" type="button" style="background-color: #00e676;color: white" data-toggle="modal" id="#myModal"  data-target="#myModal"  class="btn  pull-left">Assign</button></td>
                          </tr>         
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                            <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                           <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->group_name); ?></td>
                            <td><button onclick="makeUserId('<?php echo e($user->id); ?>')" type="button" style="background-color: #00e676;color: white" data-toggle="modal" id="#myModal"  data-target="#myModal"  class="btn  pull-left">Assign</button></td>
                          </tr>         
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>



                          <input type="hidden" name="user_id" id="userId">
                   
                </table>
 <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background-color:#f4811f;color:white;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Select Ward and Category</h4>
      </div>
      <div class="modal-body" >
        <div id="first">
        <div id="wards">  
        <div class="row">
        <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-2">
          <label>
            <input  onclick="hide('<?php echo e($ward->id); ?>')"  data-toggle="modal" data-target="#myModal<?php echo e($ward->id); ?>" type="checkbox" value="<?php echo e($ward->ward_name); ?>"  name="ward[]">&nbsp;&nbsp;<?php echo e($ward->ward_name); ?>

          </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
  </div>
  <?php $__currentLoopData = $wardsAndSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div id="subwards<?php echo e($subward['ward']); ?>" class="hidden">
    <h4 class="modal-title">Choose SubWard </h4>
    <span class="pull-right"><button id="back<?php echo e($subward['ward']); ?>" onclick="back('<?php echo e($subward['ward']); ?>')" type="button" class="hidden">Back</button></span>
    <label class="checkbox-inline"><input id="check<?php echo e($subward['ward']); ?>" type="checkbox" name="sub" value="submit" onclick="checkall('<?php echo e($subward['ward']); ?>');">All</label>
    <br><br>    
    <div id="ward<?php echo e($subward['ward']); ?>">
      <div class="row"> 
        <?php $__currentLoopData = $subward['subwards']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-2" >
          <label class="checkbox-inline">
            <input  type="checkbox"  name="subward[]" value="<?php echo e($subs->sub_ward_name); ?>">
            &nbsp;&nbsp;<?php echo e($subs->sub_ward_name); ?>

          </label>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  <div class="row">
  <div class="col-md-12">
  <div class="col-md-2">
         <h4>&nbsp;&nbsp; Assign Date</h4>
          <input type="date" name="dateenq" class="form-control" style="width: 130%"> 
  </div>
  <div class="col-md-10">        
        <h4>&nbsp;&nbsp; Select Category</h4>
       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-sm-6">
         <label>
       <input type="checkbox" id="cat<?php echo e($cat->id); ?>" onclick = "displaybrand( <?php echo e($cat->id); ?>)"; style=" padding: 5px;" name="cat[]" value="<?php echo e($cat->category_name); ?>">&nbsp;&nbsp;<?php echo e($cat->category_name); ?>

        </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
</div>
</div>
<p class="text-center"><button onclick="return confirm('Are you sure you Select The Category');" type="submit" class="btn btn-primary">Submit Data</button></p>                                        
<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="hidden" id="brand<?php echo e($cat->id); ?>">
  <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($brand->category_id == $cat->id): ?>
    <label>&nbsp;&nbsp;&nbsp;    
      <input data-toggle="modal" data-target="#myModal2" type="checkbox" id="sub_cat<?php echo e($brand->id); ?>" onclick="clickbrand( <?php echo e($brand->id); ?> )"; name="brand[]" style=" padding: 5px;" value=" <?php echo e($brand->brand); ?>">&nbsp;&nbsp;  <?php echo e($brand->brand); ?> <span style="color:green;">[<?php echo e($cat->category_name); ?>]</span>
    </label>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  </div>
</div>
</div> 
</form>   
</div>
  <?php echo e($users->links()); ?> 
  </div>
</div>
</div>
</div>
</div> 
   <!-- model -->
  
<?php if(session('message')): ?>
<script>
    swal("success","<?php echo e(session('message')); ?>","success");
</script>
<?php endif; ?>

 <?php $__env->stopSection(); ?>          
 <script type="text/javascript">

function hide(arg){
  document.getElementById('wards').className = "hidden";
  document.getElementById('subwards'+arg).className = "";
  document.getElementById('back'+arg).className = "btn btn-primary pull-left";
}
function back(arg){
  document.getElementById('wards').className = "";
  document.getElementById('subwards'+arg).className = "hidden";
  document.getElementById('back'+arg).className = "hidden";
}
</script>



<script language="JavaScript">
  function selectAll(source) {
    checkboxes = document.getElementsByName('stage[]');
    for(var i in checkboxes)
      checkboxes[i].checked = source.checked;
  }
</script>

<script>
function checkall(arg){
var clist = document.getElementById('ward'+arg).getElementsByTagName('input');
  if(document.getElementById('check'+arg).checked == true){
    for (var i = 0; i < clist.length; ++i) 
    { 
      clist[i].checked = true; 
    }
  }else{
    for (var i = 0; i < clist.length; ++i) 
    { 
      clist[i].checked = false; 
    }
  }
}
</script>   
<script>
function displaybrand(arg){

    if(document.getElementById('cat'+arg).checked == true){
        document.getElementById('brand'+arg).className="";
    }else{
        document.getElementById('brand'+arg).className = "hidden";
    }
}
function submitassign(){
  alert();
    if(document.getElementById('cat').checked == true){
      alert("1");
       
    }else{
       alert("2");
    }
}
</script>  
<script>
    function clickbrand(arg){
        if(document.getElementById('sub_cat'+arg).checked == true){
            document.getElementById('sub'+arg).className = "";
        }
    }
    function makeUserId(arg){
      document.getElementById('userId').value = arg;
    }
</script>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>