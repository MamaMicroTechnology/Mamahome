<?php $__env->startSection('content'); ?>
    <div class="col-md-3">
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading text-center">
                <b style="color:white">Custom Daily Slot</b>
            </div>
            <div class="panel-body">
                <form action="<?php echo e(URL::to('/')); ?>/dailyslots" method="GET">
                     <?php echo e(csrf_field()); ?>

                <table class="table table-responsive">
                    <tbody >
                        <tr>
                            <td>Select Listing Engineer</td>
                        </tr>
                        <tr>
                            <td>
                                <select class="form-control" name="list" required>
                                    <option disabled selected value="">(-- SELECT LE --)</option>
                                    
                                    <option value="ALL">All Listing Engineers</option>
                                    <?php if(Auth::user()->group_id != 22): ?>
                                    <?php $__currentLoopData = $le; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Select From Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date" placeholder= "From Date" class="form-control" id="fromdate" name="fromdate" required />
                            </td>
                        </tr>
                        <tr>
                            <td>Select To Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date"  placeholder= "To Date" class="form-control" id="todate" name="todate" required />
                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <button type="submit" class="btn bn-md btn-success" style="width:100">Get Date Range Details</button>
                            </td>
                        </tr>
                        <!--<tr class="text-center">-->
                        <!--    <td>-->
                        <!--        <a class="btn bn-md btn-primary" style="width:100%" onclick="showtodayrecordsle()">Get Date Details</a>-->
                        <!--    </td>-->
                        <!--</tr>-->
                    </tbody>
                </table>
            </form>
            </div>
        </div>
        <div class="panel panel-default" styke="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report of listing engineer  (Today)</b>
            </div>
            <div class="panel-body" style="overflow-x:scroll;">
                 <?php if(Auth::user()->group_id != 22): ?>
                <label style="color:black">Total Projects Added = <b><?php echo e($lcount); ?></b></label><br>
                <label style="color:black">Total Projects Updated = <b><?php echo e($lupcount); ?></b></label><br>
                <label style="color:black">Total RMC Listed = <b><?php echo e($lRMCCount); ?></b></label><br>
                <label style="color:black">Total Blocks Listed = <b><?php echo e($lBlocksCount); ?></b></label>
                <?php else: ?>
                 <label style="color:black">Total Projects Added = <b><?php echo e($tlcount); ?></b></label><br>
                 <label style="color:black">Total Projects Updated = <b><?php echo e($tlupcount); ?></b></label>
                 <?php endif; ?>
                <table class="table table-striped" border="1">
                    <thead>
                        <th style="font-size: 10px;">Name</th>
                        <th style="font-size: 10px;">Sub Ward Name</th>
                        <th style="font-size: 10px;">Added</th>
                        <th style="font-size: 10px;">Updated</th>
                        <th style="font-size: 10px;">RMC</th>
                        <th style="font-size: 10px;">Blocks</th>
                        <th style="font-size: 10px;">Total</th>
                    </thead>
                  <?php if(Auth::user()->group_id != 22): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($user->sub_ward_name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalupdates[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalRMCListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalBlocksListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalListing[$user->id] + $totalupdates[$user->id] + $totalRMCListing[$user->id] + $totalBlocksListing[$user->id]); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th style="font-size: 10px;">Total</th>
                        <th style="font-size: 10px;"></th>
                        <th style="font-size: 10px;"><?php echo e($lcount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($lupcount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($lRMCCount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($lBlocksCount); ?></th>
                        <th style="font-size: 10px;"></th>
                    </tr>
                    <?php else: ?>
                     <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($user->sub_ward_name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalupdates[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalRMCListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalBlocksListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalListing[$user->id] + $totalupdates[$user->id] + $totalRMCListing[$user->id] + $totalBlocksListing[$user->id]); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th style="font-size: 10px;">Total</th>
                        <th style="font-size: 10px;"></th>
                        <th style="font-size: 10px;"><?php echo e($tlcount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($tlupcount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($tlRMCcount); ?></th>
                        <th style="font-size: 10px;"><?php echo e($tlBlocksCount); ?></th>
                        <th style="font-size: 10px;"></th>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report of Account Executive(Today)</b>
            </div>
            <div class="panel-body" style="overflow-x:scroll;">
                <?php if(Auth::user()->group_id != 22): ?>
              <label style="color:black">Total Projects Added = <b><?php echo e($acount); ?></b></label>
              <label style="color:black">Total Projects Updated = <b><?php echo e($aupcount); ?></b></label>
              <label style="color:black">Total RMC Listed = <b><?php echo e($aRMCcount); ?></b></label><br>
              <label style="color:black">Total Blocks Listed = <b><?php echo e($aBlocksCount); ?></b></label>
              <?php else: ?>
              <label style="color:black">Total Projects Added = <b><?php echo e($tlacount); ?></b></label><br>
              <label style="color:black">Total Projects Updated = <b><?php echo e($tlupcount); ?></b></label>
              <label style="color:black">Total RMC Listed = <b><?php echo e($tlAcRMCcount); ?></b></label><br>
              <label style="color:black">Total Blocks Listed = <b><?php echo e($tlAcBlocksCount); ?></b></label>
              <?php endif; ?>
                <table class="table table-striped" border="1">
                    <thead>
                        <th style="font-size: 10px;">Name</th>
                        <th style="font-size: 10px;">Sub Ward Name</th>
                        <th style="font-size: 10px;">Added</th>
                        <th style="font-size: 10px;">Updated</th>
                        <th style="font-size: 10px;">RMC</th>
                        <th style="font-size: 10px;">Blocks</th>
                        <th style="font-size: 10px;">Total</th>
                    </thead>
                <?php if(Auth::user()->group_id != 22): ?>
                    <?php $__currentLoopData = $accusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($user->sub_ward_name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccountlist[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccupdates[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalAccountRMCListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalAccountBlocksListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccupdates[$user->id]  +  $totalaccountlist[$user->id] + $totalAccountRMCListing[$user->id] + $totalAccountBlocksListing[$user->id]); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;">Total</td>
                        <td style="font-size: 10px;"></td>
                        <td style="font-size: 10px;"><?php echo e($acount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($aupcount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($aRMCcount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($aBlocksCount); ?></td>
                        <td style="font-size: 10px;"></td>
                    </tr>
                    <?php else: ?>
                    <?php $__currentLoopData = $tlUsers1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($user->sub_ward_name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccountlist[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccupdates[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalAccountRMCListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalAccountBlocksListing[$user->id]); ?></td>
                        <td style="font-size: 10px;"><?php echo e($totalaccupdates[$user->id]  +  $totalaccountlist[$user->id] + $totalAccountRMCListing[$user->id] + $totalAccountBlocksListing[$user->id]); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;">Total</td>
                        <td style="font-size: 10px;"></td>
                        <td style="font-size: 10px;"><?php echo e($tlacount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($tlaupcount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($tlAcRMCcount); ?></td>
                        <td style="font-size: 10px;"><?php echo e($tlAcBlocksCount); ?></td>
                        <td style="font-size: 10px;"></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-9" >
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading" id="panelhead">
                <label>Daily Listings For The Date : <b><?php echo e(date('d-m-Y',strtotime($date))); ?></b> &nbsp;&nbsp;&nbsp;&nbsp;Projects Added : <b><?php if( $projcount  == 0): ?>
                  No Projects Found
                <?php else: ?>
                  <?php echo e($projcount); ?>

                <?php endif; ?>
                </b></label>
                 <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button> 
            </div>
            <div class="panel-body">
                <table class='table table-responsive table-striped' style="color:black" border="1">
                    <thead>
                        <tr>
                            <th style="text-align:center">Subward Ward Name</th>
                            <th style="text-align:center">Project-ID</th>
                            <th style="text-align:center">Owner Contact Number</th>
                            <th style="text-align:center">Site Engineer Contact Number</th>
                            <th style="text-align:center">Procurement Contact Number</th>
                            <th style="text-align:center">Consultant Contact Number</th>
                            <th style="text-align:center">Contractor Contact Number</th>
                            <th style="text-align:center">Listing Engineer</th>
                            <!--<th style="text-align:center">Verification</th>-->
                        </tr>
                    </thead>
                    <tbody id="mainPanel">
                        <?php $users = []; ?>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($project->quality == "Fake"): ?>
                            <tr style='background-color:#d2d5db'>
                            <?php else: ?>
                                <?php if(!in_array($project->listing_engineer_id, $users)): ?>
                                <tr style='background-color:#91dd71'>
                                <?php else: ?> 
                                    <tr>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php array_push($users, $project->listing_engineer_id); ?>
                           <td style="text-align:center" >
                                <a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($project->project_id); ?> && subward=<?php echo e($project->subward != null ? $project->subward->sub_ward_name : ''); ?>" data-toggle="tooltip" data-placement="top" title="click here to view map" class="red-tooltip" target="_blank"><?php echo e($project->subward != null ? $project->subward->sub_ward_name : ''); ?>

                             </a></td>
                            <td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($project->project_id); ?>&&lename=<?php echo e($project->name); ?>" target="_blank"><?php echo e($project->project_id); ?></a></td>
                            <td style="text-align:center"><?php echo e($project->ownerdetails !=null ?$project->ownerdetails->owner_contact_no :''); ?></td>
                            <td style="text-align:center"><?php echo e($project->siteengineerdetails != null?$project->siteengineerdetails->site_engineer_contact_no:''); ?></td>
                            <td style="text-align:center"><?php echo e($project->procurementdetails !=null?$project->procurementdetails->procurement_contact_no :''); ?></td>
                            <td style="text-align:center"><?php echo e($project->consultantdetails !=null ?$project->consultantdetails->consultant_contact_no :''); ?></td>
                            <td style="text-align:center"><?php echo e($project->contractordetails !=null ?$project->contractordetails->contractor_contact_no:''); ?></td>
                            <td style="text-align:center" id="listname-<?php echo e($project->project_id); ?>">
                                <?php echo e($project->user !=null ?$project->user->name:''); ?>

                                <input type="hidden" id="hiddeninp-<?php echo e($project->project_id); ?>" value="<?php echo e($project->listing_engineer_id); ?>" />
                            </td>
                            <!--<td style="text-align:center"><a onclick="" class="btn btn-sm btn-danger">Verify</a></td>-->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <center>
                    <div id="wait" style="display:none;width:200px;height:200px;"><img src='https://www.tradefinex.org/assets/images/icon/ajax-loader.gif' width="200" height="200" /></div>
                </center>
            </div>
        </div>
    </div>
    <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    <script type='text/javascript'>
        $( document ).ready(function() {
            var arr = new Array();
            var ids = new Array();
            for(var i=0; i<10000; i++)
            {
                if(document.getElementById('listname-'+i))
                {
                    arr[i] = document.getElementById('listname-'+i).innerText; //Pulling all names in arr array
                    ids[i] = document.getElementById('hiddeninp-'+i).value;
                }
            }
            var unique = arr.filter(function(item, i, ar){ return ar.indexOf(item) === i; }); //Filtering out unique names from arr array
            var uniqueids = ids.filter(function(item, i, ar){ return ar.indexOf(item) === i; }); //Filtering out unique IDs from ids array
            var ans = new Array();
            for(var i=0;i<unique.length;i++)
            {
                var x = unique[i];
                ans[x] = 0;
                for(var k=0;k<arr.length;k++)
                {
                    if(x == arr[k])
                    {
                        ans[x]++;
                    }
                }
            }


        });
    </script>
    <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
     background-color: #00acd6 

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>