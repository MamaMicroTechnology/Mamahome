<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <?php if(session('Added')): ?>
                <div class="alert alert-success alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session('Added')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('NotAdded')): ?>
               <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                   <?php echo e(session('NotAdded')); ?>

                </div>
            <?php endif; ?>
            <button class="btn btn-default form-control" data-toggle="modal" data-target="#addEmployee" style="background-color:green;color:white;font-weight:bold">Add Asset Type</button>
            <br><br>
            <div class="panel panel-default" style="border-color:#f4811f">
                <div class="panel-heading" style="background-color:#f4811f;text-align: center;"><b style="font-size:1.3em;color:white;">Assets</b></div>
                <div class="panel-body" style="overflow-x: hidden;overflow-y: scroll;">
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $content = explode(" ",$asset->type);
                            $con = implode("",$content);
                        ?>
                        <a id="<?php echo e($con); ?>" class="list-group-item" href="#"><?php echo e($asset->type); ?> (<?php echo e($asts[$asset->type]); ?>)</a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a id="simcard" class="list-group-item" href="#">SIMCard (<?php echo e($asts["SIMCard"]); ?>)</a>
                   
                </div>
            </div>
        </div>
        <div class="col-md-10" id="disp">

        </div>
    </div>
</div>
<!--Modal-->
<form method="post" action="<?php echo e(URL::to('/')); ?>/addtype">
    <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="addEmployee" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#f4811f;color:white;fon-weight:bold">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Asset Type</h4>
        </div>
        <div class="modal-body">
           <table class="table table-responsive table-hover">
                        <tbody>
                            <tr>
                                <td style="width:30%"><label>   Asset Name: </label></td>
                                <td style="width:50%"><input type="text" required name="aname" placeholder=" Asset name" pattern="[ A-Za-z,]+" class="form-control" style="width:50%" /></td>
                            </tr>
                        </tbody>
                </table>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-success">Add</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</form>
<div class='b'></div>
<div class='bb'></div>
<div class='message'>
  <div class='check'>
    &#10004;
  </div>
  <p>
    Success
  </p>
  <p>
    <?php if(session('Success')): ?>
    <?php echo e(session('Success')); ?>

    <?php endif; ?>
  </p>
  <button id='ok'>
    OK
  </button>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
    $content = explode(" ",$asset->type);
    $con = implode("",$content);
?>
<script type="text/javascript">
$(document).ready(function () {
    $("#<?php echo e($con); ?>").on('click',function(){
        
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewasset?asset="+encodeURIComponent("<?php echo e($asset->type); ?>"), function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });

        $(document.body).css({'cursor' : 'default'});
    });
});

</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
$(document).ready(function () {
    $("#simcard").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewasset?asset=SimCard", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
        
    });
});
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>