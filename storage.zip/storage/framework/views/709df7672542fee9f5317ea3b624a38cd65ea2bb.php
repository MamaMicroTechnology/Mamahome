<?php $__env->startSection('content'); ?>   
    <div class="col-md-12">     
    <div class="col-md-12" >

    <div class="panel panel-default" style="overflow: scroll;">
            <div class="panel-heading" style="background-color:#158942;color:white;font-size:1.4em;">Manufacture Projects List  <p class="pull-right">Count&nbsp;:&nbsp; <?php echo e($projectcount); ?> </p></div>  
         <div class="panel-body" id="page">
       <table class="table table-hover table-striped">
                <thead>
                  <th>Manufacture Id</th>
                  <th>Manufacture Name</th>
                  <th style="width:15%">Address</th>
                  <th>Contact No.</th>
                 <th>Action</th>
                 <th>History</th>

                
               </thead>
                <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
                   

                   <td  style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/updateManufacturerDetails?id=<?php echo e($project->id); ?>" target="_blank"><?php echo e($project->id); ?></a></td>
                   <td><?php echo e($project->proc != null ? $project->proc->name :$project->name); ?></td>
                    <td>
                                     <a target="_blank" href="https://maps.google.co.in?q=<?php echo e($project->address != null ? $project->address : ''); ?>"><?php echo e($project->address); ?></a>
                                    </td>
                   <td><?php echo e($project->proc != null ? $project->proc->contact :$project->contact_no); ?></td>
                    <td><form method="post" action="<?php echo e(URL::to('/')); ?>/confirmedmanufacture" >
                                      <?php echo e(csrf_field()); ?>

                                      <input type="hidden" value="<?php echo e($project->id); ?>" name="id">
                                      <div>
                                   
                                      <a class="btn btn-sm btn-success" name="addenquiry" href="<?php echo e(URL::to('/')); ?>/manuenquiry?projectId=<?php echo e($project->id); ?>" style="color:white;font-weight:bold;padding: 6px;">Add Enquiry</a>
                                      
                                      <?php if( $project->confirmed !== "0" ||  $project->confirmed == "true" ): ?>
                                   <button  type="button" id="demo"  style="padding: 5.5px;background-color:#e57373;color:white" class="btn btn-sm " <?php echo e($project->confirmed !== "0" ||  $project->confirmed == "true" ? 'checked': ''); ?>  name="confirmed" onclick="this.form.submit()">Called
                                   <span class="badge">&nbsp;<?php echo e($project->confirmed); ?>&nbsp;</span>
                                   </button>
                                  <?php endif; ?>
                                   <?php if( $project->confirmed == "0" ||  $project->confirmed == "false" ): ?>
                                   <button style="padding: 5.5px;background-color: #aed581;color:white" id="demo"  type="button" class="btn  btn-sm "  <?php echo e($project->confirmed !== "0" ||  $project->confirmed == "true" ? 'checked': ''); ?>  name="confirmed" onclick="this.form.submit()">Called
                                    <span class="badge">&nbsp;<?php echo e($project->confirmed); ?>&nbsp;</span>
                                   </button></div>
                                  <?php endif; ?>
                                  <button  type="button" data-toggle="modal" data-target="#myquestions<?php echo e($project->id); ?>" class="btn btn-sm btn-warning " style="color:white;font-weight:bold;padding: 6px;width:80px;">Questions</button>
                                </form>
<div id="myquestions<?php echo e($project->id); ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">
 <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:rgb(245, 127, 27);color: white;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Select The Questions</h4>
        </div>
        <div class="modal-body">
          <form method="get" action="<?php echo e(URL::to('/')); ?>/manustorequery ">
            <?php echo e(csrf_field()); ?>

           <input type="hidden" value="<?php echo e($project->id); ?>" name="id">
          <table class="table table-responsive">
            <tr>

              <td><label>Questions :</label></td>
              <td>
                          <select required style="width: 100%" class="form-control" name="qstn">
                                    <option disabled selected>--- Select ---</option>
                                    <option value="NOT INTERESTED">NOT INTERESTED</option>
                                    <option  value="BUSY">BUSY</option>
                                    <option  value="WRONG NO">WRONG NO</option>
                                    <option  value="PROJECT CLOSED">PROJECT CLOSED</option>
                                    <option  value="CALL BACK LATER">CALL BACK LATER</option>
                                    <option value="THEY WILL CALL BACK WHEN REQUIRED">THEY WILL CALL BACK WHEN REQUIRED</option>
                                    <option value="CALL NOT ANSWERED">CALL NOT ANSWERED</option>
                                    <option value="FINISHING">FINISHING</option>
                                    <option  value="SWITCHED OFF">SWITCHED OFF</option>
                                    <option  value="SAMPLE REQUEST">SAMPLE REQUEST</option>
                                    <option  value="MATERIAL QUOTATION">MATERIAL QUOTATION</option>
                                    <option  value="WILL FOLLOW UP AFTER DISCUSSION WITH OWNER">WILL FOLLOW UP AFTER DISCUSSION WITH OWNER</option>
                                    <option  value="DUPLICATE NUMBER">DUPLICATE NUMBER</option>
                                    <option  value="NOT REACHABLE">NOT REACHABLE</option>
                                    <option  value="THEY HAVE REGULAR SUPPLIERS">THEY HAVE REGULAR SUPPLIERS</option>
                                    <option  value="CREDIT FACILITY">CREDIT FACILITY</option>
                                  </select>
                        </td>
                      </tr>
                      <tr>
                        <td><label>Call Remark : </label></td>
                        <td><textarea required style="resize: none;" class="form-control" placeholder="Remarks" name="remarks" ></textarea></td>
                      </tr>
                    </table>
       
      <button type="submit" class=" form-control btn btn-primary">Submit</button>
      </form>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
</td>
        <td>
<button style="padding: 5.5px;background-color: #757575 ;color: white" data-toggle="modal" data-target="#myModal1<?php echo e($project->id); ?>"   type="button" class="btn  btn-sm "  >
             History </button>
</td>  

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModal1<?php echo e($project->id); ?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header  " style="background-color:#868e96;padding:5px; " >
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"> Customer History </h4>
        </div>
        <div class="modal-body">
              <table class="table table-responsive">
                                      <tr>
                                        <td style="padding: 10px;" >Manufacturer Id<Enquiry/td>
                                        <td>:</td>
                                        <td style="padding: 10px;"> <?php echo e($project-> id); ?></td>
                                      </tr>           
                                      <tr>
                                         <td style="padding: 10px;" > Manufacturer Created At</td>
                                         <td>:</td>
                                         <td style="paddiEnquiryng: 10px;"><?php echo e(date('d-m-Y', strtotime( $project->created_at))); ?></td>
                                          <td>
                                                <?php echo e(date('h:i:s A', strtotime($project->created_at))); ?>

                                              </td>
                                       </tr>
                                        <tr>
                                           <td> Manufacturer Updated At</td>
                                           <td>:</td>
                                           <td ><?php echo e(date('d-m-Y', strtotime(  $project->updated_at))); ?></td>
                                            <td>
                                                  <?php echo e(date('h:i:s A', strtotime($project->updated_at))); ?>

                                                </td>
                                       </tr>
                </table>

                              <table class="table table-responsive table-hover">
                                       <thead>
                                          <!-- <th>User_id</th> -->
                                          <th>Serial No</th>
                                          <th>Called Date</th>
                                          <th>Called Time</th>
                                          <th> Name </th>
                                          <th>Question</th>
                                          <th>Call Remark</th>
                                       </thead>
                                       <tbody>
                                     <label>Call History</label>
                                         <?php $i=1 ?>
                                          <?php $__currentLoopData = $his; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($call->manu_id == $project->id): ?>
                                          <tr>
                                           <!--  <td>
                                              <?php echo e($call->user_id); ?>

                                            </td> -->
                                           
                                            <td><?php echo e($i++); ?></td>
                                            <td>
                                              <?php echo e(date('d-m-Y', strtotime($call->called_Time))); ?>

                                            </td>
                                            <td>
                                              <?php echo e(date('h:i:s A', strtotime($call->called_Time))); ?>

                                            </td>
                                            <td>
                                             <?php echo e($call->username); ?>

                                            </td>
                                            <td>
                                              <?php echo e($call->question); ?>

                                            </td>
                                            <td>
                                              <?php echo e($call->remarks); ?>

                                            </td>
                                          </tr>
                                      <?php endif; ?>
      <center><?php echo e($project->links()); ?></center>   
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                        </table>
                                      
        </div>
        <div class="modal-footer" style="padding:1px;">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</div>

  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>