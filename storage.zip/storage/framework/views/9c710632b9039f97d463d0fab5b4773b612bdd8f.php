<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 6? "layouts.leheader":"layouts.app");
?>


<?php $__env->startSection('content'); ?>

<?php if($ldate < $lodate): ?>
  <div>You are ahead of time.</div>
  <?php elseif($ldate > $outtime): ?>
  <div>You are done for today. Take a rest.</div>
  <?php else: ?>
<div class="container">
    <div class="row">
      <?php if($subwards): ?>
      <div class="col-md-3"> 
         You are in <?php echo e($subwards->sub_ward_name); ?><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/listingEngineer">Add New Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/roads">Update Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/requirementsroads">Project Enquiry</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/reports">My Report</a><br><br>
         <a href="<?php echo e(URL::to('/')); ?>/kra" class="form-control btn btn-primary">KRA</a><br><br>
         <label>
           You have listed <strong><?php echo e($numbercount); ?></strong> projects so far.<br>
           You have listed <?php echo e($total); ?> projects today.<br>
           <?php echo e($ordersInitiated); ?> orders has been initiated by you<br>
           out of which <?php echo e($ordersConfirmed); ?> has been confirmed
         </label><br><br>
            <center></center>
            <div class="panel-panel-primary">
                <div class="panel-heading text-center">
                    <!--<b><u>CURRENT PRICE LIST</u></b>-->
                </div>
                <div class="panel-body">

                            
                </div>
            </div>
            
       </div>
        <div class="pull-right col-lg-8">
          <img class="img-thumbnail" src="<?php echo e(URL::to('/')); ?>/public/subWardImages/<?php echo e($subwards->sub_ward_image); ?>">
        </div>
       <?php else: ?>
       No wards assigned to you yet
       <?php endif; ?>
    </div>
</div>

<br><br>

<div class="col-md-8 col-md-offset-2" style="border-style: ridge;">
<div id="map" style="width:100%;height:400px"></div>
</div>

<script type="text/javascript" scr="https://maps.google.com/maps/api/js?sensor=false"></script>

  <script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      locations.push(["<a href=\"https://maps.google.com/?q=<?php echo e($project->address); ?>\"><?php echo e($project->project_id); ?> <?php echo e($project->project_name); ?>,<?php echo e($project->address); ?></a>",<?php echo e($project->latitude); ?>, <?php echo e($project->longitude); ?>]);

      created.push("<?php echo e($project->created_at); ?>");
      updated.push("<?php echo e($project->updated_at); ?>");
      status.push("<?php echo e($project->status); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 10,
      center: new google.maps.LatLng(locations[0][1], locations[0][2]),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) { 
    if(created[i] == updated[i]){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
      });
    }else if(status[i] == "Order Confirmed"){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'
      });
    }else{
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
      });
    }

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
  }
  </script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU&callback=myMap"></script>

<script>

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>