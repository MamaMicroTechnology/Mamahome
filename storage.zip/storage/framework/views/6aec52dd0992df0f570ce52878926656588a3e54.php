<?php
    $use = Auth::user()->group_id;
    $ext = ($use == 1? "layouts.app":"layouts.leheader");
?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12 col-sm-12">
	<div class="panel panel-primary" style="overflow-x: scroll;">
		<div class="panel-heading text-center">
			<b style="color:white;font-size:1.4em">Confirmed Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Total Count : <?php echo e($count); ?></b>
			<a class="pull-right btn btn-sm btn-danger" href="<?php echo e(URL::to('/')); ?>/home" id="btn1" style="color:white;"><b>Back</b></a>
		</div>
		<div id="orders" class="panel-body">
			<table class="table table-responsive table-striped">
				<thead>
				    <th style="text-align:center">Project ID</th>
                    <th style="text-align: center;">Order Id</th>
					<th style="text-align:center">Product</th>
					<th style="text-align:center">Quantity</th>					
					<!-- <th style="text-align:center">Dispatch Status</th> -->
					<th style="text-align:center">Payment Status</th>
					<th style="text-align:center">Delivery Status</th>
                    <th style="text-align:center">Action</th>
                    <th style="text-align:center">Deposit Bank</th>

                    <th style="text-align:center">Remark</th>


				</thead>
				<tbody>
					<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr id="row-<?php echo e($rec->id); ?>">
						<td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/showProjectDetails?id=<?php echo e($rec->project_id); ?>"><?php echo e($rec -> project_id); ?></a></td>
                        <td style="text-align:center"><?php echo e($rec->orderid); ?></td>
						<td>
							<?php echo e($rec->main_category); ?><br>
							(<?php echo e($rec->sub_category); ?>)
						</td>
						<td style="text-align:center"><?php echo e($rec->quantity); ?> <?php echo e($rec->measurement_unit); ?></td>
						<!-- <td style="text-align:center"></td> -->
						<!-- <td style="text-align:center">
						<?php if($rec->dispatch_status=='Yes'): ?>
						    Dispatched
						<?php else: ?>
						    <button onclick="updateDispatch('<?php echo e($rec->orderid); ?>')" class="btn btn-success btn-sm">Dispatch</button>
						<?php endif; ?>    
						</td> -->
				        <td style="text-align: center;">
				      
				             
                            <?php if($rec->paymentStatus != "Payment Received" ): ?>
                              
							<button data-toggle="modal" data-target="#PaymentModal<?php echo e($rec->orderid); ?>" class="btn btn-success btn-sm">Payment Details</button>

                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/payment" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

									<div id="PaymentModal<?php echo e($rec->orderid); ?>" class="modal fade" role="dialog">
										<div class="modal-dialog modal-sm">
											<!-- Modal content-->
											<div class="modal-content">
											<div class="modal-header">
												Payment<br>
												
												<input type="hidden" name="orderid" value="<?php echo e($rec->orderid); ?>">
												
											</div>
											<div class="modal-body">
											<label for="PaymentDoneBy">Customer Name</label>
											<input type="text" name="c_name" class="form-control input-sm">
											 <?php if($rec->payment_mode != "Cheq Clear"): ?>
												<label for="paymentMethod">Payment Mode:</label><br>
                                          <label><input  value="RTGS"  type="checkbox" name="payment_method[]" onclick="rtgs()"><span>&nbsp;</span>RTGS(Online)</label>&nbsp;&nbsp;&nbsp;&nbsp;
                                          <label><input  value="Cash"  type="checkbox" name="payment_method[]" onclick="cash()"><span>&nbsp;</span>Cash</label>
                                           <?php endif; ?>
												<label for="amount">Cash Amount Received:</label>
												<input  type="text" name="amount" id="cash" placeholder="Amount Received" class="hidden">
												<label for="amount">RTGS Amount Received:</label>
												<input  type="text" name="rtgs" id="rtgs" placeholder="Amount Received" class="hidden">
												<label for="sign">Signature:</label>
												<input required type="file" name="signature" id="sign" class="form-control input-sm" accept="image/*">
												<div id="show<?php echo e($rec->project_id); ?>" class="show">
													<label for="amount">Payment Picture</label>
													<input id="adv"  type="file" name="signature1" id="sign" class="form-control input-sm" accept="image/*">
												</div>
												
												<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">
												<input type="hidden" name="project_id" value="<?php echo e($rec->project_id); ?>">
												<input type="hidden" name="log_name" value="<?php echo e($rec->delivery_boy); ?>">
												
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-success pull-left">Save</button>
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(URL::to('/')); ?>/public/signatures/<?php echo e($rec->signature); ?>"><?php echo e($rec->paymentStatus); ?></a>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                            <?php if($rec->delivery_status == "Not Delivered"): ?>
								<!-- Trigger the modal with a button -->
								 <?php if($rec->paymentStatus == "Payment Received" ): ?>
							<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal<?php echo e($rec->orderid); ?>">Deliver</button>
                             <?php endif; ?>
							<!-- Modal -->
							
							<form action="<?php echo e(URL::to('/')); ?>/saveDeliveryDetails" method="post" enctype="multipart/form-data">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">
								<div id="myModal<?php echo e($rec->orderid); ?>" class="modal fade" role="dialog">
								<div class="modal-dialog">

									<!-- Modal content-->
									<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Order Delivery Form</h4>
									</div>
									<div class="modal-body">
										<table class="table table-hover" border=1>
											<tr>
												<td colspan=2><label for="Images">Images</label></td>
											</tr>
											<tr>
												<td>Vehicle No.</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="vno" id="vno" class="form-control"></td>
											</tr>
											<tr>
												<td>Location Picture</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="lp" id="lp" class="form-control"></td>
											</tr>
											<tr>
												<td>Quality of Material</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="qm" id="qm" class="form-control"></td>
											</tr>
											<tr>
												<td colspan="2"><center><label for="Video">Video</label></center></td>
											</tr>
											<tr>
												<td>
													Delivery Video
													<br>(Video should cover all the<br>necessary fields as in images)
												</td>
												<td><input accept="video/*" oninput="inputcheck()" type="file" name="vid" id="vid" class="form-control"></td>
											</tr>
										</table>
									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-success pull-left">Save</button>
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									</div>
									</div>
								</div>
								</div>
							</form>
							
                                <!-- <button onclick="deliverOrder('<?php echo e($rec->orderid); ?>')" class="btn btn-success btn-sm">Deliver</button> -->
                            <?php else: ?>
							<?php
								$images = "<a target='_blank' class='".($rec->vehicle_no == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->vehicle_no."'>Vehicle No</a><br>"
											."<a target='_blank' class='".($rec->location_picture == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->location_picture."'>Location Picture</a><br>"
											."<a target='_blank' class='".($rec->quality_of_material == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->quality_of_material."'>Quality Of Material</a><br>"
											."<a target='_blank' class='".($rec->delivery_video == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->delivery_video."'>Video</a>";
							?>
								<a href="#" data-toggle="popover" title="Delivery Images" data-content="<?php echo $images; ?>">
									<?php echo e($rec->delivery_status); ?>

								</a>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                            <?php if($rec->paymentStatus == "Payment Received"): ?>
                                <?php echo e($rec->paymentStatus); ?>

                             
                            <?php elseif($rec->delivery_status != "Delivered"): ?>
    				           <!--  <a onclick="cancelOrder('<?php echo e($rec->orderid); ?>')" class="btn btn-sm btn-danger" style="width:99%" >
    				                <b>Cancel Order</b>
    				            </a>
 -->
                            <?php else: ?>
                                Order Delivered
                            <?php endif; ?>
				        </td>
				        <td>
				        <?php if($rec->payment_status != "Closed" ): ?> 
				      <?php if($rec->paymentStatus == "Payment Received" ): ?> 
                    <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal6<?php echo e($rec->orderid); ?>">Deposit</button>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if($rec->paymentStatus == "Payment Received" ): ?> 
                     <?php if($rec->payment_status == "Closed" ): ?> 
                    <button class="btn btn-danger btn-sm" data-toggle="modal" >Closed</button>
                    <?php endif; ?>
                   <?php endif; ?>
                   
<div class="modal" id="myModal6<?php echo e($rec->orderid); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header" style="background-color:green">
        <h4 class="modal-title"><CENTER style="color: white;">Cash Collection  </CENTER></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
               <form action="<?php echo e(URL::to('/')); ?>/deposit" method="post" enctype="multipart/form-data">
                 <?php echo e(csrf_field()); ?>

								<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">
								<input type="hidden" name="user_id" value="<?php echo e($rec->delivery_boy); ?>">


                     <table class="table table-hover" border=1 >
											
											<tr>
												<td>Bank Name</td>
												<td>
                                                <select class="form-control" style="width: 40%" name="zone_id">
                                                	<option value="select">----Select----</option>
                                                	<?php $__currentLoopData = $zone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($zones->id); ?>"><?php echo e($zones->zone_name); ?></option>
                                                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                 <select class="form-control" style="width: 40%;margin-top: -35px;margin-left:45%;" name="bankname">
                                                	<option value="select">----Select----</option>
                                                	<option value="AxisBank">Axis Bank</option>
                                                </select>
                                               </td>
											</tr>
											<tr>
												<td>Amount</td>
												<td>
                                                 <input required class="form-control" type="text" name="Amount" value="<?php echo e($rec->amount); ?>">
                                               </td>
											</tr>
											<tr>
												<td>Date Of Deposit </td>
												<td>
                                                 <input required class="form-control" type="date" name="bdate" >
                                               </td>
											</tr>
											<!-- <tr>
												<td>Location Of Bank</td>
												<td>
                                                 <input required class="form-control" type="text" name="location">
                                               </td>
											</tr> -->
											<tr>
												<td>Cash Deposit Receipt Pic</td>
												<td>
                                                 <input required class="form-control" type="file" name="image">
                                               </td>
											</tr>
										</table>
			 <center><button type="submit" value="submit" class="btn btn-success btn-sm">Submit</button></center>

       </form> 
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


                        </td>
				        <td>
				        <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal5<?php echo e($rec->orderid); ?>">Feedback</button>

				        
	<div class="modal" id="myModal5<?php echo e($rec->orderid); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
     <div class="modal-header" style="background-color:green">
        <h4 class="modal-title"><CENTER style="color: white;">Coustomer Information  </CENTER></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>


      <!-- Modal body -->
      <div class="modal-body">
      <form action="<?php echo e(URL::to('/')); ?>/feedback" method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

								<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">

               <table class="table table-hover" border=1 >
											
											<tr>
												<td>Customer Satisfied ?</td>
												<td>
                                    
                                      <label><input required value="Yes" id="home1" type="radio" name="happy"><span>&nbsp;</span>Yes</label>
                                      <span>&nbsp;&nbsp;&nbsp;  </span>
                                  
                                      <label><input required value="No" id="home2" type="radio" name="happy"><span>&nbsp;</span>No</label>
                                       <span>&nbsp;&nbsp;&nbsp;  </span>
                                
                                      <label><input required value="None" id="home3" type="radio" name="happy"><span>&nbsp;</span>None</label>
                                   
                                 </td>
											</tr>
											<tr>
												<td>Customer Is Happy With Quality Of Material?</td>
												<td>
                                    
                                      <label><input required value="Yes" id="home1" type="radio" name="quan"><span>&nbsp;</span>Yes</label>
                                      <span>&nbsp;&nbsp;&nbsp;  </span>
                                  
                                      <label><input required value="No" id="home2" type="radio" name="quan"><span>&nbsp;</span>No</label>
                                       <span>&nbsp;&nbsp;&nbsp;  </span>
                                
                                      <label><input required value="None" id="home3" type="radio" name="quan"><span>&nbsp;</span>None</label>
                                   
                                 </td>
											</tr>
											<tr>
												<td>Customer Issue  ?</td>
												<td>
                                    
                                      <label><input required value="Yes" id="home1" type="radio" name="issue"><span>&nbsp;</span>Yes</label>
                                      <span>&nbsp;&nbsp;&nbsp;  </span>
                                  
                                      <label><input required value="No" id="home2" type="radio" name="issue"><span>&nbsp;</span>No</label>
                                       <span>&nbsp;&nbsp;&nbsp;  </span>
                                
                                      <label><input required value="None" id="home3" type="radio" name="issue"><span>&nbsp;</span>None</label>
                                   
                                 </td>
											</tr>
											
											<tr>
												<td>Note</td>
												<td>
                                    
                                      <textarea required value="Yes" class="form-control"  type="text" name="note"></textarea><span>&nbsp;</span>
                                     
                                   
                                 </td>
											</tr>
										</table>
			<center><button type="submit" value="submit" class="btn btn-success btn-sm">Submit </button></center>

       </form> 
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>	
			</table>
			<br>
			<center><?php echo e($view->links()); ?></center>	
		</div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
	function rtgs(){
		document.getElementById('rtgs').className = "form-control input-sm";
		document.getElementById('cash').className = "hidden";
	}
	function cash(){
		document.getElementById('cash').className = "form-control input-sm";
		document.getElementById('rtgs').className = "hidden";
	}
$(document).ready(function(){
    $('[data-toggle="popover"]').popover({html:true});   
});
</script>
<script type="text/javascript">
	
	function pay(arg)
	{
		var ans = confirm('Are You Sure ? Note: Changes Made Once CANNOT Be Undone');
		if(ans){
			$.ajax({
				type: 'GET',
				url: "<?php echo e(URL::to('/')); ?>/updateampay",
				data: {id: arg},
				async: false,
				success: function(response){
					console.log(response);
				}
			});
		}
		return false;
	}

	function updateDispatch(arg)
	{
		var ans = confirm('Are You Sure ? Note: Changes Made Once CANNOT Be Undone');
		if(ans){
    		$.ajax({
    			type: 'GET',
    			url: "<?php echo e(URL::to('/')); ?>/updateamdispatch",
    			data: {id: arg},
    			async: false,
    			success: function(response){
    				console.log(response);
                     $("#orders").load(location.href + " #orders>*", "");
    			}
    		});
		}
		return false;	
	}
	
	function deliverOrder(arg)
	{
	    var ans = confirm('Are You Sure To Confirm This Order ?');
	    if(ans)
	    {
    	    $.ajax({
    	       type:'GET',
    	       url: "<?php echo e(URL::to('/')); ?>/deliverOrder",
    	       data: {id : arg},
    	       async: false,
    	       success: function(response)
    	       {
    	           console.log(response);
    	           $("#orders").load(location.href + " #orders>*", "");
    	       }
    	    });
	    }    
	}
	
	function cancelOrder(arg)
	{
	    var ans = confirm('Are You Sure To Cancel This Order ?');
	    if(ans)
	    {
    	    $.ajax({
    	       type:'GET',
    	       url: "<?php echo e(URL::to('/')); ?>/cancelOrder",
    	       data: {id : arg},
    	       async: false,
    	       success: function(response)
    	       {
    	           console.log(response);
    	           $("#orders").load(location.href + " #orders>*", "");
    	       }
    	    });
	    }
	 }
	function changeValue(val, id){
	//use comparison operator   
		if(val=="Cheque" || val=="RTGS" || val=="Cash" )
			document.getElementById('show'+id).className = "";
		else{
			document.getElementById('show'+id).className="hidden";
		}
	}

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>