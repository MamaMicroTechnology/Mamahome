<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/gmaps.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/')); ?>/js/jscolor.js"></script>
  <!-- <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css" /> -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/some.css" />
  <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/app.css" />
  <?php if(isset($_GET['userId'])): ?>
    <script type="text/javascript">
        var track = [];
        <?php $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            track.push([<?php echo e(round($trac->latitude,4)); ?>,<?php echo e(round($trac->longitude,4)); ?>]);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        var map;
        $(document).ready(function(){
        map = new GMaps({
            el: '#map',
            lat: 12.9716,
            lng: 77.5946,
            click: function(e){
            console.log(e);
            }
        });
        map.setZoom(16);
        path = track;

        map.drawPolyline({
            path: path,
            strokeColor: '#131540',
            strokeOpacity: 0.6,
            strokeWeight: 2
        });
        });
    </script>
    <?php else: ?>
    <script type="text/javascript">
    var map;
    $(document).ready(function(){
      map = new GMaps({
        el: '#map',
        lat: 12.9716,
        lng: 77.5946,
        zoomControl : true,
        zoomControlOpt: {
            style : 'SMALL',
            position: 'TOP_LEFT'
        },
        panControl : false,
        streetViewControl : false,
        mapTypeControl: false,
        overviewMapControl: false
      });
      map.setZoom(11);
    });
  </script>
    <?php endif; ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2" style="max-height:550px; height:550px; overflow-y: scroll;">
              <?php if(Auth::user()->group_id != 22): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="font-family:'Times New Roman'" class="list-group-item"
                    href="<?php echo e(URL::to('/')); ?>/<?php echo e(Auth::user()->id == 1 ? 'letracking' : 'tltracking'); ?>?userId=<?php echo e($user->id); ?>">
                    <?php echo e($user->employeeId); ?> <?php echo e($user->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                 <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="font-family:'Times New Roman'" class="list-group-item"
                    href="<?php echo e(URL::to('/')); ?>/<?php echo e(Auth::user()->id == 1 ? 'letracking' : 'tltracking'); ?>?userId=<?php echo e($user->id); ?>">
                    <?php echo e($user->employeeId); ?> <?php echo e($user->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-10">
              <div style="height:550px;" id="map"></div>
            </div>
        </div>
    </div>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>