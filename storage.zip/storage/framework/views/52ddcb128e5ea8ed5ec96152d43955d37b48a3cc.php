<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
    <div class="panel panel-default">
        <div class="panel-heading" style="background-color: green;color:white;">KRA List</div>
        <div class="panel-body">
            <table class="table table-hover" border=1>
                <thead>
                    <th>Department Name</th>
                    <th>Designation</th>
                    <th>Role</th>
                    <th>Goal</th>
                    <th>Key Result Area</th>
                    <th>Key Performance Area</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($kra->dept_name); ?></td>
                        <td><?php echo e($kra->group_name); ?></td>
                        <td><?php echo e($kra->role); ?></td>
                        <td><?php echo e($kra->goal); ?></td>
                        <td><?php echo e($kra->key_result_area); ?></td>
                        <td><?php echo e($kra->key_performance_area); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>