<?php $__env->startSection('content'); ?>
<?php $count = 1; ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <table class="table table-hover" border=1>
                <center><label for="Points"><?php echo e($user->name); ?>'s Points For <?php echo e(date('d-M-Y',strtotime($date))); ?></label></center>
                <thead>
                    <th>Reason For Earning Point</th>
                    <th>Points Earned</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $points_indetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $points): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo $points->reason; ?>

                            <?php if($points->confirmation == 0): ?>
                            <a href="<?php echo e(URL::to('/')); ?>/approvePoint?id=<?php echo e($points->id); ?>" class="btn btn-primary btn-xs pull-right">Approve</a>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right"><?php echo e($points->type == "Add" ? "+".$points->point : "-".$points->point); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan=2>
                            <button type="button" class="btn btn-info btn-sm form-control" data-toggle="modal" data-target="#myModal">Add More Point</button>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align: right;"><b>Total</b></td>
                        <td style="text-align: right"><?php echo e($total); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">Report of <?php echo e($user->name); ?> for <?php echo e(date('d-M-Y',strtotime($date))); ?>

                </div>
                <div class="panel-body">
                    <form method=POST action="<?php echo e(URL::to('/')); ?>/grade">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="userId" value="<?php echo e($user->employeeId); ?>">
                        <input type="hidden" name="date" value="<?php echo e($date); ?>">
                            <div class="col-md-12">
                                <div class="col-md-4">AM Remark:</div>
                                <div class="col-md-8"><input placeholder="AM Remark" type="text" value="<?php echo e($attendance->am_remarks); ?>" name="amremark" class="form-control"></div>
                            </div><br><br>
                            <div class="col-md-12">
                                <div class="col-md-4">Credits earned:</div>
                                <div class="col-md-8"><textarea name="remark" class="form-control" placeholder="Remark" rows="1"><?php echo e($attendance->remarks); ?></textarea></div>
                            </div><br><br><br>
                            <div class="col-md-12">
                                <div class="col-md-4">Grade:</div>
                                <div class="col-md-8">
                                    <select name="grade" class="form-control input-xs">
                                        <option value="">--Select--</option>
                                        <option value="A" <?php echo e($attendance->grade == "A"?'selected':''); ?>>A</option>
                                        <option value="B" <?php echo e($attendance->grade == "B"?'selected':''); ?>>B</option>
                                        <option value="C" <?php echo e($attendance->grade == "C"?'selected':''); ?>>C</option>
                                        <option value="D" <?php echo e($attendance->grade == "D"?'selected':''); ?>>D</option>
                                    </select>
                                </div>
                            </div><br><br>
                            <p><button id="save" class="btn btn-primary form-control">Save</button></p>
                        </form>
                        <p><?php echo e($attendance->am_remark); ?></p>
                    </div>
                    <table class="table">
                        <thead>
                            <th>Sl.No.</th>
                            <th>Report</th>
                            <th>Start</th>
                            <th>End</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($report->report); ?></td>
                                <td><?php echo e($report->start); ?></td>
                                <td><?php echo e($report->end); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<form action="<?php echo e(URL::to('/')); ?>/aMaddPoints" method="post">
<?php echo e(csrf_field()); ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Points To <?php echo e($user->name); ?></h4>
      </div>
      <div class="modal-body">
        <table class="table table-hover">
		<input type="hidden" name="userId" value="<?php echo e($user->id); ?>">
		<input type="hidden" name="date" value="<?php echo e(date('Y-m-d H:i:s',strtotime($date))); ?>">
			<tr>
				<td>Type</td>
				<td>:</td>
				<td>
					<select name="type" id="" class="form-control">
						<option value="">--Select--</option>
						<option value="Add">Add</option>
						<option value="Subtract">Subtract</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Reason</td>
				<td>:</td>
				<td>
					<textarea name="reason" rows="3" class="form-control" placeholder="Reason for adding points"></textarea>
				</td>
			</tr>
			<tr>
				<td>Points</td>
				<td>:</td>
				<td><input type="number" name="point" class="form-control" placeholder="Amount you want to add"></td>
			</tr>
		</table>
      </div>
      <div class="modal-footer">
		<button type="submit" class="btn btn-success pull-left">Add</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>