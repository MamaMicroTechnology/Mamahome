<?php $__env->startSection('content'); ?>

<div class="col-md-10 col-md-offset-1">
        <center>Manufacturer's Information</center><br>
        <div class="panel panel-danger">
            <div class="panel-heading">
                Details
                  <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(URL::to('/')); ?>/home" id="btn1" style="color:white;"><b>Back</b></a>
            </div>
            <div style="overflow-x: scroll;" class="panel-body">
                <div class="col-md-3" >
                    <select id="category" onchange="displaycategory()" class="form-control input-sm">
                        <option>--Category Wise--</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat); ?>"><?php echo e($cat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <br>
                <table id="manufacturer" class="table table-responsive" border=1><br>
                    <thead>
                        <th>Company Name</th>
                        <th>Category</th>
                        <th>CIN</th>
                        <th>GST</th>
                        <th>PAN</th>
                        <th>Address</th>
                        <th>MD</th>
                        <th>CEO</th>
                        <th>Sales Contact</th>
                        <th>Finance Contact</th>
                        <th>Quality Department</th>
                        <th>Production Capacity</th>
                    </thead>
                    <tbody>
                        <?php $count = 0; $count1 = 0; ?>
                        <?php $__currentLoopData = $mfdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detail->company_name); ?></td>
                            <td><?php echo e($detail->category); ?></td>
                            <td><?php echo e($detail->cin); ?></td>
                            <td><?php echo e($detail->gst); ?></td>
                            <td><?php if($detail->pan != NULL): ?> <a href="<?php echo e(URL::to('/')); ?>/pan/<?php echo e($detail->pan); ?>">View</a><?php endif; ?></td>
                            <td>
                                Registered office: <?php echo e($detail->registered_office != NULL ? $detail->registered_office:''); ?><br>
                                Wear House : <?php echo e($detail->ware_house_location != NULL ? $detail->ware_house_location:''); ?><br>
                                Factory Location : <?php echo e($detail->factory_location != NULL ? $detail->factory_location:''); ?>

                            </td>
                            <td><?php echo e($detail->md); ?></td>
                            <td><?php echo e($detail->ceo); ?></td>
                            <td><?php echo e($detail->sales_contact); ?></td>
                            <td><?php echo e($detail->finance_contact); ?></td>
                            <td><?php echo e($detail->quality_department); ?></td>
                            <td><?php echo e($detail->production_capacity); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
</div>

<script>
    function displaycategory() {
      var input, filter, table, tr, td, i;
      input = document.getElementById("category");
      filter = input.value.toUpperCase();
      table = document.getElementById("manufacturer");
      tr = table.getElementsByTagName("tr");
      for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1];
        if (td) {
          if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
          } else {
            tr[i].style.display = "none";
          }
        }       
      }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>