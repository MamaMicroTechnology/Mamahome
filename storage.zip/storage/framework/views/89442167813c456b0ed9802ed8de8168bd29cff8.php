<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 7? "layouts.sales":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<br><br>
<div style="background-color:white" class="container" >
<h2 ><center>WELCOME TO <?php echo e(Auth::user()->group_id == 17 ? ' SALES CONVERTER' : 'ASSISTANT MANAGER OF SALES AND MARKETING'); ?>

<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><B><SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
    <center><h2>Your Ward is :<?php $__currentLoopData = $ward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><br>
                         <?php echo e($name->ward_name); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h2></center>

</center></h2></div>
<center class="countdownContainer">
    <h1>Operation <i style="color:yellow; font-size: 50px;" class="fa fa-bolt"></i> Lightning</h1>
    <div id="clockdiv">
        <div>
            <span class="days"></span>
            <div class="smalltext">Days</div>
        </div>
        <div>
            <span class="hours"></span>
            <div class="smalltext">Hours</div>
        </div>
        <div>
            <span class="minutes"></span>
            <div class="smalltext">Minutes</div>
        </div>
        <div>
            <span class="seconds"></span>
            <div class="smalltext">Seconds</div>
        </div>
    </div>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>