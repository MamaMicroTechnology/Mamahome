<?php $__env->startSection('content'); ?>

<div class="col-md-10 col-md-offset-1">
    <div class="panel panel-primary">
        <div class="panel-heading"><center>Total Invoices : <?php echo e($invoice); ?></center></div>
        <div class="panel-body">
          <b>Category Wise Invoices : <?php echo e($total); ?></b>
 <center>  <form action="<?php echo e(URL::to('/')); ?>/viewInvoices" method="get" >
        <b> Select Category:</b>   <select class="form-control" name="cat" onchange="form.submit()" style="width:30%;">
              <option value="select">----Select category----</option>
              <option value="ALL">ALL</option>

              <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cate->category_name); ?>"><?php echo e($cate->category_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </select>
</form></center>
        <table class="table table-hover">
            <thead>
                <th>Invoice No</th>
                <th>OrderId</th>
                <th>ProjectId</th>
                <th>Location</th>
                <th>Name</th>
                <th>Delivery Date</th>
               
            </thead>
            <?php $__currentLoopData = $inc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(URL::to('/')); ?>/invoice?id=<?php echo e($invoice->invoice_id); ?>"><?php echo e($invoice->invoice_id); ?></td>
                    <td><?php echo e($invoice->requirement_id); ?></td>
                    <td>
                        
                    <a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($invoice->project_id); ?>" target="_blank"><?php echo e($invoice->project_id); ?> </a>
                    </td>
                    
                    <td><?php echo e($invoice->deliver_location); ?></td>
                    <td><?php echo e($invoice->customer_name); ?></td>
                    <td>
                       <?php echo e(date('d-m-Y', strtotime($invoice->delivery_date))); ?>

                    </td>
                 </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>