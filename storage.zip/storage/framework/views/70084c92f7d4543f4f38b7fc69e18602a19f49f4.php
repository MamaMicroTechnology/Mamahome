<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
		<div class="panel panel-danger">
			<div class="panel-heading">Orders Pipelined</div>
			<div class="panel-body">
				<table class="table table-responsive">
					<thead>
						<th>Project Id</th>
						<th>Main Category</th>
						<th>Sub Category</th>
						<th>Material Specification</th>
						<th>Requirement Date</th>
						<th>Measurement Unit</th>
						<th>Unit Price</th>
						<th>Quantity</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pipelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pipeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($pipeline->project_id); ?></td>
							<td><?php echo e($pipeline->main_category); ?></td>
							<td><?php echo e($pipeline->sub_category); ?></td>
							<td><?php echo e($pipeline->material_spec); ?></td>
							<td><?php echo e($pipeline->requirement_date); ?></td>
							<td><?php echo e($pipeline->measurement_unit); ?></td>
							<td><?php echo e($pipeline->unit_price); ?></td>
							<td><?php echo e($pipeline->quantity); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>