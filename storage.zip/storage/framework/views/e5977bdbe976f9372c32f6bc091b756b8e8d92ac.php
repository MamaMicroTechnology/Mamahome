<?php $__env->startSection('content'); ?>

<div class="col-md-6 col-md-offset-3">
	<div class="panel panel-default">
		<div class="panel-heading">Report of <?php echo e(date('d-M-Y',strtotime($loginTimes->logindate))); ?></div>
		<div class="panel-body">
		    <form method="GET" action="<?php echo e(URL::to('/')); ?>/reports">
					<div class="col-md-3">
						Choose Date:
					</div>
					<div class="col-md-4">
						<input required type="date" name="date" class="form-control input-sm">
					</div>
					<div>
						<button type="submit">Submit</button>
					</div>
				</form><br>
			<label>Morning</label>
			<table class="table">
				<tr>
					<td>Login Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->loginTime); ?></td>
				</tr>
				<tr>
					<td>Allocated Ward</td>
					<td>:</td>
					<td><?php echo e($loginTimes->allocatedWard); ?></td>
				</tr>
				<tr>
					<td>First Listing Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->firstListingTime); ?></td>
				</tr>
				<tr>
						<td>First Update Time</td>
						<td>:</td>
						<td><?php echo e($loginTimes->firstUpdateTime); ?></td>
					</tr>
				<tr>
					<td>No. of projects listed <br> in the morning</td>
					<td>:</td>
					<td><?php echo e($loginTimes->noOfProjectsListedInMorning); ?></td>
				</tr>
				<tr>
					<td>No. of projects updated <br> in the morning</td>
					<td>:</td>
					<td><?php echo e($loginTimes->noOfProjectsUpdatedInMorning); ?></td>
				</tr>
				<?php if($loginTimes->morningMeter != NULL): ?>
				<tr>
					<td>Meter Image</td>
					<td>:</td>
					<td>
						<img src="<?php echo e(URL::to('/')); ?>/public/meters/<?php echo e($loginTimes->morningMeter); ?>" height="100" width="200" class="img img-thumbnail">
					</td>
				</tr>
				<tr>
				    <td>Meter Reading</td>
				    <td>:</td>
					<td>
					    <?php echo e($loginTimes->gtracing); ?>

					</td>
				</tr>
				<?php endif; ?>
				<?php if($loginTimes->morningData != NULL): ?>
				<tr>
					<td>Data Image</td>
					<td>:</td>
					<td><img src="<?php echo e(URL::to('/')); ?>/public/data/<?php echo e($loginTimes->morningData); ?>" height="100" width="200" class="img img-thumbnail"></td>
				</tr>
				<tr>
					<td>Data Reading</td>
					<td>:</td>
					<td><?php echo e($loginTimes->afternoonData); ?></td>
				</tr>
				<?php endif; ?>
				<tr>
				    <td>Morning Remarks</td>
				    <td>:</td>
				    <td><?php echo e($loginTimes->morningRemarks); ?></td>
				</tr>
			</table>
			<?php if($loginTimes->morningMeter == NULL): ?>
			<form method="post" action="<?php echo e(URL::to('/')); ?>/addMorningMeter" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="morningCount" value="<?php echo e($projectCount); ?>">
				<table class="table">		
					<tr>
						<td>Meter Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="morningMeter" class="form-control"></td>
					</tr>
					<tr>
						<td>Meter Reading</td>
						<td>:</td>
						<td><input required type="text" name="morningMeterReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn form-control btn-xs btn-primary">
			</form>
			<?php endif; ?>
			<?php if($loginTimes->morningData == NULL): ?>
			<form method="post" action="<?php echo e(URL::to('/')); ?>/addMorningData" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<table class="table">		
					<tr>
						<td>Data Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="morningData" class="form-control"></td>
					</tr>
					<tr>
						<td>Data Reading</td>
						<td>:</td>
						<td><input required type="text" name="morningDataReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn form-control btn-xs btn-primary">
			</form>
			<?php endif; ?>
			<label>Evening</label>
			<table class="table">
			    <tr>
					<td>Last Listing Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->lastListingTime); ?></td>
				</tr>
				<tr>
					<td>Last Update Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->lastUpdateTime); ?></td>
				</tr>
			    <tr>
					<td>Total Projects Listed</td>
					<td>:</td>
					<td><?php echo e($loginTimes->TotalProjectsListed); ?></td>
				</tr>
				<tr>
					<td>Total Projects Updated</td>
					<td>:</td>
					<td><?php echo e($loginTimes->totalProjectsUpdated); ?></td>
				</tr>
				<?php if($loginTimes->eveningMeter != NULL): ?>
				<tr>
					<td>Meter Image</td>
					<td>:</td>
					<td><img src="<?php echo e(URL::to('/')); ?>/public/meters/<?php echo e($loginTimes->eveningMeter); ?>" height="100" width="200" class="img img-thumbnail"></td>
				</tr>
				<tr>
					<td>Meter Reading</td>
					<td>:</td>
					<td><?php echo e($loginTimes->afternoonMeter); ?></td>
				</tr>
				<?php endif; ?>
				<?php if($loginTimes->eveningData != Null): ?>
				<tr>
					<td>Data Image</td>
					<td>:</td>
					<td><img src="<?php echo e(URL::to('/')); ?>/public/data/<?php echo e($loginTimes->eveningData); ?>" height="100" width="200" class="img img-thumbnail"></td>
				</tr>
				<tr>
					<td>Data Reading</td>
					<td>:</td>
					<td><?php echo e($loginTimes->afternoonRemarks); ?></td>
				</tr>
				<?php endif; ?>
				<?php if($loginTimes->AmGrade != Null): ?>
				<tr>
				    <td>Asst. Manager Remarks</td>
				    <td>:</td>
				    <td><?php echo e($loginTimes->AmRemarks); ?></td>
				</tr>
				<tr>
				    <td>Grade</td>
				    <td>:</td>
				    <td><?php echo e($loginTimes->AmGrade); ?></td>
				</tr>
				<?php endif; ?>
			</table>
			<?php if($loginTimes->eveningMeter == NULL): ?>
			<form method="POST" action="<?php echo e(URL::to('/')); ?>/eveningMeter" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<table class="table">
					<tr>
						<td>Meter Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="eveningMeterImage" class="form-control"></td>
					</tr>
					<tr>
						<td>Meter Reading</td>
						<td>:</td>
						<td><input required type="text" name="eveningMeterReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn btn-primary btn-xs form-control">
			</form>
			<?php endif; ?>
			<?php if($loginTimes->eveningData == Null): ?>
			<form method="POST" action="<?php echo e(URL::to('/')); ?>/eveningData" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="totalCount" value ="<?php echo e($projectCount); ?>">
				<table class="table">
					<tr>
						<td>Data Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="eveningDataImage" class="form-control"></td>
					</tr>
					<tr>
						<td>Data Reading</td>
						<td>:</td>
						<td><input required type="text" name="eveningDataReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn btn-primary btn-xs form-control">
			</form>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>