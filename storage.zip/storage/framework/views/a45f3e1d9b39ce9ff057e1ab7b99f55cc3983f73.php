<?php $__env->startSection('content'); ?>
<div class="col-md-10 col-md-offset-2">
    <div class="col-md-10">
        <div class="panel panel-default" style="border-color:#337ab7">
            <div class="panel-heading text-center" style="background-color:#337ab7">
                <b style="color:white">Assign Category</b>
            </div>
            <div class="panel-body">
             <form action="<?php echo e(URL::to('/')); ?>/postcat" method="POST" enctype="multipart/form-data"> 
                    <?php echo e(csrf_field()); ?>

                
                <div class="col-md-2">
                   <label>Select Category</label>
                    <select id="sc" class="form-control" name="cat" required>
                      <option value="">--Select Category--</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?>&nbsp;[&nbsp;&nbsp;Projects : &nbsp;<?php echo e($nofprojects[$category->id]); ?>&nbsp;&nbsp;Enquiries:&nbsp;&nbsp;<?php echo e($nofenquirys[$category->id]); ?>]</option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                  <div class="col-md-2">
                   <label>Category Officers</label>
                    <select id="co" class="form-control" name="user_id" required>
                      <option value="">-- Category Officers--</option>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option  value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div> 

               <div class="col-md-4">
                   <label>Set Instructions</label>
                   <textarea style="resize:none;" class="form-control" type="text" name="ins" style="width:100%;">
                   </textarea>
                 </div> 
  
                  <div class="col-md-2">
                    <button id="this" onclick="selectcat()" class="form-control btn btn-primary" value="submi" style="margin-top:40px;">Assign</button>
                 </div> 

            </div>
            </form>
<table  class="table" border="1">
                <thead>
                    <tr>
                        <th>SLNO</th>
                        <th>Category Officer Name</th>
                        <th>Category</th>
                        <th>Previous Category</th>
                        <th>Created On</th>
                        <th>Updated On</th>
                        <th>Instructions</th>

                    </tr>
                </thead>

                <tbody>
                  <?php 
                  $i = 1;
                  ?>
                  <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($cate->user != null ? $cate->user->name :''); ?></td>
                  <td><?php echo e($cate->category != null ? $cate->category->category_name :''); ?></td>
                  <td><?php echo e($cate->prev); ?></td>
                  <td><?php echo e($cate->created_at->format('d-m-Y')); ?></td>
                  <td><?php echo e($cate->updated_at->format('d-m-y')); ?></td>
                  <td><?php echo e($cate->instraction); ?></td>
                  
                    
                   </tbody>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </table>

        </div>
    </div>
</div>
</div>
<script type="text/javascript">
	function check(arg){
	    var input = document.getElementById(arg).value;
	    if(isNaN(input)){
	      	while(isNaN(document.getElementById(arg).value)){
	      	var str = document.getElementById(arg).value;
	      	str     = str.substring(0, str.length - 1);
	      	document.getElementById(arg).value = str;
	      	}
	    }
	    else{
	      	input = input.trim();
	      	document.getElementById(arg).value = input;
	    }
	    return false;
	}
	function edit(arg){
	    var initial = document.getElementById(arg);
	    var getdetails = initial.getElementsByTagName("td");
	    var category = getdetails[0].innerText;
	    var subcategory = getdetails[1].innerText;
	    var measure = getdetails[2].innerText;
	    var price = getdetails[3].innerText;
	    document.getElementById('category').value = category;
	    document.getElementById('subcategory').value = subcategory;
	    document.getElementById('price').value = price;
	    document.getElementById('measure').value = measure;
	    document.getElementById('id').value = arg;
	}
function selectcat(){
  var input = document.getElementById('sc').value;
  var value = document.getElementById('co').value;
  if(input == ""){
    alert("You Have Not Selected Category");
  }
  else if(value == ""){
     alert("You Have Not Selected Sales Officer");
  }
  else{
    document.getElementById('this').form.submit();
  }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>