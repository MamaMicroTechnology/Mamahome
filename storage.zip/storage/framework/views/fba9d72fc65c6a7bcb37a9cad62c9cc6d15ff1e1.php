<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading" style="background-color: green;color: white;">Project Details 
				<?php if($projects != "None"): ?>
					(<?php echo e(count($projects)); ?> <?php echo e(count($projects) < 2 ? 'project' : 'projects'); ?> selected)
				<?php endif; ?>
			</div>
			<div class="panel-body" style="overflow-x: scroll;">
				<?php if(Auth::user()->group_id == 1): ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/viewallProjects">
					<div class="col-md-6">
						<div class="col-md-4">
							<select name="ward" onchange="getSubwards()" id="ward" class="form-control">
								<option value="">--SELECT--</option>
								<option value="All">All</option>
								<?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ward->id); ?>"><?php echo e($ward->ward_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="col-md-4">
							<select name="subward" id="subward" class="form-control">
								
							</select>
						</div>
						<div class="col-md-4">
							<input type="submit" class="form-control" value="Fetch">
						</div>
					</div>
				</form>
				<?php endif; ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/<?php echo e(Auth::user()->group_id == 1 ? 'viewallProjects':'projectDetailsForTL'); ?>">
					<div class="col-md-4 pull-right">
						<div class="input-group">
							<input type="text" name="phNo" class="form-control" placeholder="Phone number and project_id search">
							<div class="input-group-btn">
								<input type="submit" class="form-control" value="Search">
							</div>
						</div>
					</div>
				</form>
				<table class="table table-hover">
					<thead>
						<th>Project Id</th>
						<th>Project Name</th>
						<th>Construction Type</th>
						
						<th>Sub-Ward</th>
						<th>Project Status</th>
						<th>Quality</th>
						<th>Address</th>
						<th>Floors</th>
						<th>Project Size</th>
						<th>Budget</th>
						<th>Image</th>
						<th>Remarks</th>
						<?php if(Auth::user()->group_id != 7 &&  Auth::user()->group_id != 17): ?>
						<th>Listed By</th>
						<?php endif; ?>
						<th>Called By</th>
						<th>Listed On</th>
						<th>Last update</th>
						<?php if(Auth::user()->group_id == 2 ): ?>
						<th>Last updated By</th>
						<?php endif; ?>
					</thead>
					<tbody>
						<?php if($projects != "None"): ?>
						<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<a target="_none" href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($project->project_id); ?>"><?php echo e($project->project_id); ?></a>
							</td>
							<td><?php echo e($project->project_name); ?></td>
							<td><?php echo e($project->construction_type); ?></td>
							
							<td><?php echo e($project->sub_ward_name); ?></td>
							<td><?php echo e($project->project_status); ?></td>
							<td><?php echo e($project->quality); ?></td>
							<td><a href="https://www.google.com/maps/place/<?php echo e($project->siteaddress != null ? $project->siteaddress->address  : ''); ?>/{{ $project->siteaddress != null ? $project->siteaddress->latitude : '' }},<?php echo e($project->siteaddress != null ? $project->siteaddress->longitude : ''); ?>" target="_blank"><?php echo e($project->address); ?></a></td>
							<td>B(<?php echo e($project->basement); ?>)+G(<?php echo e($project->ground); ?>)+1=<?php echo e($project->basement + $project->ground + 1); ?></td>

							<td><?php echo e($project->project_size); ?></td>
							<td><?php echo e($project->budget); ?></td>
							<td><button class="btn btn-primary btn-xs"data-toggle="modal" data-target="#viewimage<?php echo e($project->project_id); ?>">View Image</button>
								<div id="viewimage<?php echo e($project->project_id); ?>" class="modal fade" role="dialog">
								  <div class="modal-dialog" style="width: 50%;height: 30%">

								    <!-- Modal content-->
								    <div class="modal-content">
								      <div class="modal-header" style="background-color: green;color:white;">
								        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
								        <h4 class="modal-title">Image</h4>
								      </div>
								      <div class="modal-body">
								        <img style=" height:350px; width:640px;" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($project->image); ?>">
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								      </div>
								    </div>

								  </div>
							</div>



							</td>
							
							<td><?php echo e($project->remarks); ?></td>
							<?php if(Auth::user()->group_id != 7 && Auth::user()->group_id != 17): ?>
							<td><?php echo e($project->name); ?></td>
							<?php endif; ?>
							<td>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($project->call_attended_by == $user->id): ?>
								<?php echo e($user->name); ?>

								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</td>
							
							<td>
								<?php echo e(date('d/m/Y',strtotime($project->created_at))); ?>

							</td>
							<td>
								<?php echo e(date('d/m/Y', strtotime($project->updated_at))); ?>

								<br><small>(<?php echo e($project->updated_at->diffForHumans()); ?>)</small>
							</td>
							<?php if(Auth::user()->group_id == 2 ): ?>
							<td><?php if($updater != null): ?>
                                   <?php echo e($updater->name); ?>

                                <?php endif; ?></td>
                            <?php endif; ?>
							<?php if(Auth::user()->group_id == 1): ?>
							<td>
								<button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete<?php echo e($project->project_id); ?>">Delete</button>
								<!-- Modal -->
							  <div class="modal fade" id="delete<?php echo e($project->project_id); ?>" role="dialog">
							    <div class="modal-dialog modal-sm">
							      <div class="modal-content">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal">&times;</button>
							          <h4 class="modal-title">Delete</h4>
							        </div>
							        <div class="modal-body">
							          <p>Are you sure you want to delete this project?</p>
							        </div>
							        <div class="modal-footer">
							        	<a class="btn btn-danger pull-left" href="<?php echo e(URL::to('/')); ?>/deleteProject?projectId=<?php echo e($project->project_id); ?>">Yes</a>
							          <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
							        </div>
							      </div>
							    </div>
							  </div>
							</td>
							
							<?php endif; ?>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>



	<script type="text/javascript">
		function getSubwards()
	    {
	        var ward = document.getElementById("ward").value;
	        $.ajax({
	            type:'GET',
	            url:"<?php echo e(URL::to('/')); ?>/loadsubwards",
	            async:false,
	            data:{ward_id : ward},
	            success: function(response)
	            {
	                document.getElementById('subward').innerHTML = "<option value='' disabled selected>----Select----</option>";
	                for(var i=0; i < response.length; i++)
	                {
	                    document.getElementById('subward').innerHTML += "<option value="+response[i].id+">"+response[i].sub_ward_name+"</option>";
	                }
	            }
	        });    
	    }
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>