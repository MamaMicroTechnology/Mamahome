<?php
    $group = Auth::user()->group->group_name;
    if($group == "Auditor"){
        $content = "auditor.layout.auditor";
    }else{
        $content = "layouts.app";
    }
?>

<?php $__env->startSection('content'); ?>
    <?php $totalRequirement = 0; $totalPrice = 0; ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-success">
            <div class="panel-heading">
            <center style="font-size: 17px;"><b>
            Business Plan (Monthly)
            </b></center>
            
            </div>
            <div class="panel-body">
                <form action="">
                    <div class="col-md-4">
                        <select required name="category" id="" class="form-control">
                            <option value="">--Select Category--</option>
                            <option <?php echo e(isset($_GET['category']) ? ($_GET['category'] == "all" ? 'selected' : '') : ''); ?> value="all">All</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(isset($_GET['category']) ? ($cat->category == $_GET['category'] ? 'selected' : '') : ''); ?> value="<?php echo e($cat->category); ?>"><?php echo e(ucwords($cat->category)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select required name="ward" id="" class="form-control">
                            <option value="">--Select Ward--</option>
                            <option <?php echo e(isset($_GET['ward']) ? ($_GET['ward'] == "all" ? 'selected' : '') : ''); ?> value="all">All</option>
                            <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(isset($_GET['ward']) ? ($ward->id == $_GET['ward'] ? 'selected' : '') : ''); ?> value="<?php echo e($ward->id); ?>"><?php echo e($ward->ward_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="submit" value="Get" class="btn btn-success form-control">
                    </div>
                </form>
                <?php if(isset($_GET['ward']) && $_GET['category'] != "all"): ?>
                <br><br><br>
                <div class="pull-left" id="left">
                    <label for="">Business Cycle : <?php echo e($category->business_cycle); ?></label><br>
                    <label for="">Price : <?php echo e($category->price); ?></label><br>
                    <label for="">Target : <?php echo e($category->target); ?>%</label><br>
                    <label for="">Transactional Profit Target : <?php echo e($category->transactional_profit); ?>%</label><br>
                </div>
                <div class="pull-right" id="right">
                </div>
                <br><br><br><br><br>
                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#myModal">Reset</button>
                <br><br>
                <table class="table table-hover" border=1>
                <tr>
                    <th>Stage</th>
                    <th>Total <?php echo e($conversion->unit); ?></th>
                    <th>Amount</th>
                </tr>
                <?php $__currentLoopData = $projections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($projection['stage']); ?></td>
                        <td>
                            <?php if($projection['stage'] == "Electrical & Plumbing"): ?>
                                <?php $stage = "electrical"; ?>
                            <?php else: ?>
                                <?php $stage = $projection['stage']; ?>
                            <?php endif; ?>
                            <?php echo e(number_format(($projection['size'] * $conversion->minimum_requirement/$conversion->conversion)/100*($utilizations[strtolower($stage)]))); ?>

                            <?php $totalRequirement += ($projection['size'] * $conversion->minimum_requirement/$conversion->conversion)/100*($utilizations[strtolower($stage)]); ?>
                        </td>
                        <td>
                            <?php echo e(number_format(($projection['size'] * $conversion->minimum_requirement/$conversion->conversion)/100*($utilizations[strtolower($stage)]) * $category->price)); ?>

                            <?php $totalPrice += ($projection['size'] * $conversion->minimum_requirement/$conversion->conversion)/100*($utilizations[strtolower($stage)]) * $category->price; ?>
                        </td>
                    </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th>Total Requirement</th>
                        <th><?php echo e(number_format($totalRequirement)); ?></th>
                        <th><?php echo e(number_format($totalPrice)); ?></th>
                    </tr>
                    <tr>
                        <th>Monthly Requirement</th>
                              <th><?php echo e(number_format($monthly = $totalRequirement/$category->business_cycle)); ?></th>
                        <th><?php echo e(number_format($monthlyPrice = $totalPrice/$category->business_cycle)); ?></th>
                    </tr>
                </table>
                <!-- Modal -->
                <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Confirmation</h4>
                        </div>
                        <div class="modal-body">
                        <p>Are you sure you want to reset this planning?</p>
                        </div>
                        <div class="modal-footer">
                        <a href="<?php echo e(URL::to('/')); ?>/reset?category=<?php echo e($_GET['category']); ?>" class="btn btn-danger pull-left">Yes</a>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                        </div>
                    </div>
                    </div>
                </div>
                <?php elseif(isset($_GET['category']) && $_GET['category'] == "all"): ?>
                <?php echo $text; ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Modal -->
<div class="modal fade" id="reset" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Confirmation</h4>
        </div>
        <div class="modal-body">
        <p style="text-align:center">Are you sure you want to reset the entire planning?</p>
        </div>
        <div class="modal-footer">
        <a href="<?php echo e(URL::to('/')); ?>/reset?category=all" class="btn btn-danger pull-left">Yes</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        </div>
    </div>
    </div>
</div>
    <?php if(isset($_GET['ward']) && $_GET['category'] != 'all'): ?>
    <?php 
        if($category->incremental_percentage != null)
            $incremental_percentage = 100 * $category->incremental_percentage;
        else
            $incremental_percentage = 1;
    ?>
    <script>
        var text = "<label>Monthly Target:</label><br>"+
        "<label><?php echo e($conversion->unit); ?> : <?php echo e(number_format(($monthly/100*$category->target)/$incremental_percentage)); ?></label><br>"+
        "<label>Amount : <?php echo e(number_format($amount = $monthlyPrice/100*$category->target)); ?></label><br>"+
        "<label>Transactional Profit : <?php echo e(number_format($amount/100*$category->transactional_profit)); ?></label></b>";
        document.getElementById("right").innerHTML = text;
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($content, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>