<?php $__env->startSection('content'); ?>
<div class="container">
<div class="col-md-6">
    <div class="panel panel-default" style="border-color:green;">

               
                <div class="panel-heading" style="background-color: green;color:white;"><b> View Training Videos</b> <br> Please select the Department and designation in order to get the training videos


                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                </div>
                <div class="panel-body">
            <form method="GET" action="<?php echo e(URL::to('/')); ?>/video">
                            <table class="table">
                                <tr>
                                    <td>Department</td>
                                    <td>Designation</td>
                                    
                                </tr> 
                                <tr>
                                    <td><select required class="form-control" name="dept">
                                    <option value="">--Select--</option>
                                        <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->dept_name); ?>

                                    </option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                    </td>
                                    <td>
                                    <select required class="form-control" name="designation">
                                    <option value="">--Select--</option>
                                     <?php $__currentLoopData = $grps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($grp->id); ?>"><?php echo e($grp->group_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                    </td>
                                    <td>
                                     <input type="submit" class="btn btn-success" value="Submit">
                                     </td>

                                </tr>
                            
                        </table>
                    </form>
                    <table class="table table-responsive">
                        <tr>
                                    <td>Video Title </td>
                                    <td >Action</td>

                        </tr>
                        <?php if($videos != "none"): ?>
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($video->remark); ?></td>
                            <td>
                                <button data-toggle="modal" data-target="#myModal<?php echo e($video->id); ?>" class="btn btn-sm btn-primary">View</button>
                           
                                <!-- <a href="<?php echo e(URL::to('/')); ?>/deleteentry?id=<?php echo e($video->id); ?>" class="btn btn-sm btn-danger" >Delete</a> -->
                               
                            </td>
                        </tr>
                   
                            <div id="myModal<?php echo e($video->id); ?>" class="modal fade" role="dialog">
                              <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"><?php echo e($video->remark); ?></h4>
                                  </div>
                                  <div class="modal-body">
                                    <video class="img img-responsive" controls controlslist="nodownload">
                                      <source src="<?php echo e(URL::to('/')); ?>/public/trainingvideo/<?php echo e($video->upload); ?>" type="video/mp4">
                                      <source src="<?php echo e(URL::to('/')); ?>/public/trainingvideo/<?php echo e($video->upload); ?>" type="video/ogg">
                                      
                                    </video>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                  </div>
                                </div>

                              </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </table>    
            </div>
        </div>
     </div>

<div class="col-md-6">
            <div class="panel panel-default" style="border-color:green">
                <div class="panel-heading" style="background-color: green;color:white;"><b>Upload Training Videos</b>
                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                </div>
                <div class="panel-body">
            <form method="POST" action="<?php echo e(URL::to('/')); ?>/uploadvideo" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <table class="table">
                                <tr>
                                    <td>Department</td>
                                    <td>Designation</td>
                                    <td>Upload video(only mp4 format)</td>
                                </tr>
                                <tr>
                                    <td><select required class="form-control" name="dept">
                                    <option value="">--Select--</option>
                                        <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->dept_name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                    </td>
                                    <td>
                                    <select required class="form-control" name="designation">
                                    <option value="">--Select--</option>
                                     <?php $__currentLoopData = $grps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($grp->id); ?>"><?php echo e($grp->group_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                </td>

                                    <td><input type="file" name="upload" required class="form-control input-sm" accept="video/*">
                                    </td>
                                    
                                    
                                </tr>
                                <tr>
                                <tr>
                                    <td>
                                    Video Title
                                    </td>
                                </tr>
                                    <td>
                                        <input type="text" name="remark" class="form-control"  placeholder="Title">
                                    </td>
                                
                                    <td ><button type="submit" class="btn btn-success pull-right ">Save</button></td>
                                </tr>
                            </table>
                             
                        </form>                                                   
            	</div>
			</div>
        </div>
</div>
<div class="container">
<div class="col-md-6"></div>
<div class="col-md-6">
            <div class="panel panel-default" style="border-color:green;">
                <div class="panel-heading" style="background-color: green;color:white;"><b>Available Videos</b>
                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                </div>
                <div class="panel-body" style="height: 500px;max-height: 500pxoverflow-y: scroll;overflow-x: scroll;">
                    <table class="table table-responsive">
                        <tr>
                                    <td><b>Video Title</b></td>
                                    

                        </tr>
                       
                        <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($title->remark); ?></td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                       
                    </table>
                </div>
            </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>