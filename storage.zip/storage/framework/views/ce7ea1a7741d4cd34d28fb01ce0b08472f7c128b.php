<?php $__env->startSection('content'); ?>

<div class="col-md-6 col-md-offset-3">
    <div class="panel panel-success">
        <div class="panel-heading">Add details</div>
        <div class="panel-body">
            <form method="POST" action="<?php echo e(URL::to('/')); ?>/edit/save" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php $id = $_GET['UserId']; ?>
                <input type="hidden" name="userid" value="<?php echo e($id); ?>">
                <table class="table table-responsive">
                    <tr>
                        <td>Date of Joining</td>
                        <td><input type="date" value="<?php echo e($employeeDetails != NULL? $employeeDetails->date_of_joining:''); ?>" name="doj" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Aadhar No.</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->adhar_no:''); ?>" name="aadhar" class="form-control input-sm" placeholder="Aadhar No."></td>
                    </tr>
                    <tr>
                        <td>Aadhar Card Image</td>
                        <td>
                            <input type="file" name="aadharImg" class="form-control input-sm"><br>
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->aadhar_image != NULL): ?>
                                <img height="200" width="200" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($employeeDetails->aadhar_image); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Date of Birth</td>
                        <td><input type="date" value="<?php echo e($employeeDetails != NULL? $employeeDetails->dob:''); ?>" name="dob" class="form-control input-sm"></td>
                    </tr>
                    <tr>
                        <td>Blood Group</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->blood_group:''); ?>" name="bloodGroup" class="form-control input-sm" placeholder="Blood Group"></td>
                    </tr>
                    <tr>
                        <td>Father's Name</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->fathers_name:''); ?>" name="fatherName" class="form-control input-sm" placeholder="Father's Name"></td>
                    </tr>
                    <tr>
                        <td>Mother's Name</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->mothers_name:''); ?>" name="motherName" class="form-control input-sm" placeholder="Mother's Name"></td>
                    </tr>
                    <tr>
                        <td>Spouse Name</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->spouse_name:''); ?>" name="spouseName" class="form-control input-sm" placeholder="Spouse Name"></td>
                    </tr>
                    <tr>
                        <td>Contact No.</td>
                        <td><input type="text" name="contact" value="<?php echo e($user->contactNo); ?>" class="form-control" placeholder="Contact No."></td>
                    </tr>
                    <tr>
                        <td>Office Phone No.</td>
                        <td><input type="text" name="office" value="<?php echo e($employeeDetails != NULL?$employeeDetails->office_phone:''); ?>" class="form-control" placeholder="Office Phone No."></td>
                    </tr>
                    <tr>
                        <td>Alternative Phone No.</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->alt_phone:''); ?>" name="altPh" class="form-control input-sm" placeholder="Alternative phone No."></td>
                    </tr>
                    <tr>
                        <td>Permanent Address</td>
                        <td><textarea class="form-control" name="perAdd" placeholder="Permanent address" rows="3" max-row="5"><?php echo e($employeeDetails != NULL? $employeeDetails->permanent_address:''); ?></textarea></td>
                    </tr>
                    <tr>
                        <td>Permanent Address Proof</td>
                        <td>
                            <input type="file" class="form-control input-sm" name="permanenAddressProof">
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->permanent_address_proof != NULL): ?>
                                <img height="200" width="200" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($employeeDetails->permanent_address_proof); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Present Address</td>
                        <td><textarea class="form-control" name="preAdd" placeholder="Present address" rows="3" max-row="5"><?php echo e($employeeDetails != NULL? $employeeDetails->temporary_address:''); ?></textarea></td>
                    </tr>
                    <tr>
                        <td>Present Address Proof</td>
                        <td><input type="file" class="form-control input-sm" name="presentAddressProof">
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->temporary_address_proof != NULL): ?>
                                <img height="200" width="200" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($employeeDetails->temporary_address_proof); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Emergency Contact 1 Name (Blood Relative) </td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->emergency_contact_name:''); ?>" name="emergencyName" class="form-control input-sm" placeholder="Emergency Contact Name"></td>
                    </tr>
                    <tr>
                        <td>Emergency Contact 1 No. </td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->emergency_contact_no:''); ?>" name="emergencyContact" class="form-control input-sm" placeholder="Emergency Contact No."></td>
                    </tr>
                    <tr>
                        <td>Confirmation Call Audio</td>
                        <td>
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->confirmation_call != NULL): ?>
                                <audio controls>
                                    <source src="<?php echo e(URL::to('/')); ?>/public/employeeAudios/<?php echo e($employeeDetails->confirmation_call); ?>" type="audio/ogg">
                                    <source src="<?php echo e(URL::to('/')); ?>/public/employeeAudios/<?php echo e($employeeDetails->confirmation_call); ?>" type="audio/mpeg">
                                </audio>
                            <?php endif; ?>
                            <?php endif; ?>
                            <input type="file" name="cfa" class="form-control input-sm" accept=".mp3">
                        </td>
                    </tr>
                    <tr>
                        <td>Emergency Contact 2 Name (Friend)</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->emergency_contact2_name:''); ?>" name="emergencyName2" class="form-control input-sm" placeholder="Emergency Contact Name"></td>
                    </tr>
                    <tr>
                        <td>Emergency Contact 2 No.</td>
                        <td><input type="text" value="<?php echo e($employeeDetails != NULL? $employeeDetails->emergency_contact2_no:''); ?>" name="emergencyContact2" class="form-control input-sm" placeholder="Emergency Contact No."></td>
                    </tr>
                    <tr>
                        <td>Confirmation Call Audio 2</td>
                        <td>
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->confirmation_call2 != NULL): ?>
                                <audio controls>
                                    <source src="<?php echo e(URL::to('/')); ?>/public/employeeAudios/<?php echo e($employeeDetails->confirmation_call2); ?>" type="audio/ogg">
                                    <source src="<?php echo e(URL::to('/')); ?>/public/employeeAudios/<?php echo e($employeeDetails->confirmation_call2); ?>" type="audio/mpeg">
                                </audio>
                            <?php endif; ?>
                            <?php endif; ?>
                            <input type="file" name="cfa2" class="form-control input-sm" accept=".mp3">
                        </td>
                    </tr>
                    <tr>
                        <td>Curriculum Vite (CV)</td>
                        <td><input type="file" name="cv" class="form-control input-sm">
                            <?php if($employeeDetails != NULL): ?>
                            <?php if($employeeDetails->curriculum_vite != NULL): ?>
                                <img height="200" width="200" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($employeeDetails->curriculum_vite); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <input type="submit" class="btn btn-primary form-control" value="Save">
            </form>
        </div>
    </div>
    <div class="panel panel-success">
        <div class="panel-heading">Bank Account details</div>
        <div class="panel-body">
            <form method="POST" action="<?php echo e(URL::to('/')); ?>/edit/bank_account" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="userid" value="<?php echo e($id); ?>">
                <table class="table table-responsive">
                    <tr>
                        <td>Bank Name</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->bank_name:''); ?>" name="bankName" class="form-control input-sm" placeholder="Bank Name"></td>
                    </tr>
                    <tr>
                        <td>Account Holder Name</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->accountHolderName:''); ?>" name="acHolder" class="form-control input-sm" placeholder="Account Holder Name"></td>
                    </tr>
                    <tr>
                        <td>Account No.</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->accountNo:''); ?>" name="acNo" class="form-control input-sm" placeholder="Account No."></td>
                    </tr>
                    <tr>
                        <td>IFSC</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->ifsc:''); ?>" name="ifsc" class="form-control input-sm" placeholder="IFSC"></td>
                    </tr>
                    <tr>
                        <td>Branch Name</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->branchName:''); ?>" name="branchName" class="form-control input-sm" placeholder="Branch Name"></td>
                    </tr>
                    <tr>
                        <td>Passbook</td>
                        <td>
                            <input type="file" name="passbook" class="form-control input-sm">
                            <?php if($bankDetails != NULL): ?>
                            <?php if($bankDetails->passbook != NULL): ?>
                                <br>
                                <img height="400" width="400" class="pull-right img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($bankDetails->passbook); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Pan Card No.</td>
                        <td><input type="text" value="<?php echo e($bankDetails != NULL? $bankDetails->pan_card_no:''); ?>" name="panCard" class="form-control input-sm" placeholder="Pan Card No."></td>
                    </tr>
                    <tr>
                        <td>Pan Card Image</td>
                        <td>
                            <input type="file" name="panCardImage" class="form-control input-sm">
                            <?php if($bankDetails != NULL): ?>
                            <?php if($bankDetails->pan_card_image != NULL): ?>
                                <br>
                                <img height="400" width="400" class="pull-right img-responsive" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($bankDetails->pan_card_image); ?>">
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <input type="submit" class="btn btn-primary form-control" value="Save">
            </form>
        </div>
    </div>
    <div class="panel panel-warning">
        <div class="panel-heading">Asset Info</div>
        <div class="panel-body">
            <table class="table table-responsive">
                <tr>
                    <td>Name</td>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <td>Designation</td>
                    <td><?php echo e($user->group->group_name); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <td>Assets</td>
                    <td>
                        <?php if($assetInfos != NULL): ?>
                        <table class="table table-responsive">
                            <thead>
                                <th>Type</th>
                                <th>Details</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $assetInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($assetInfo->asset_type); ?></td>
                                    <td><?php echo e($assetInfo->description); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteAsset">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($assetInfo->id); ?>">
                                            <input type="submit" value="Delete" class="btn btn-xs btn-danger">
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(URL::to('/')); ?>/edit/saveAssetInfo">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="userId" value="<?php echo e($user->employeeId); ?>">
                            <table id="asset" class="table table-responsive">
                                
                                <tbody>
                                    <tr>
                                        <td>
                                            <select required class="form-control" name="type[]">
                                                <option value="">--Select--</option>
                                                <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($asset->type); ?>"><?php echo e($asset->type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td>
                                            <textarea required class="form-control" placeholder="Asset description" name="details[]"></textarea>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <button onclick="addRow()">+</button>
                            <button onclick="deleteRow()">-</button>
                            <input type="submit" class="form-control btn btn-success" value="Save">
                        </form>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="panel panel-success">
        <div class="panel-heading">Certificates</div>
        <div class="panel-body">
            <button onclick="addCertificateRow()">+</button>
            <form method="POST" action="<?php echo e(URL::to('/')); ?>/edit/uploadCertificates" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" value="<?php echo e($user->employeeId); ?>" name="userId">
            <table class="table table-responsive" id="Certificate">
                <thead>
                    <th>Certificate Name</th>
                    <th>File</th>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" class="form-control input-sm" placeholder="Certificate Type" name="type[]"></td>
                        <td><input type="file" class="form-control input-sm" name="certificateFile[]"></td>
                    </tr>
                </tbody>
            </table>
            <input type="submit" value="Save" class="form-control btn btn-success">
            </form>
            <?php if($certificates != NULL): ?>
            <table class="table table-responsive">
                <thead>
                    <th>Type</th>
                    <th>Details</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($certificate->type); ?></td>
                        <td>
                            <img onclick="display('certificate<?php echo e($certificate->id); ?>')" id="certificate<?php echo e($certificate->id); ?>" height="200" width="200" alt="<?php echo e($user->name); ?>" class="img img-responsive myImg" src="<?php echo e(URL::to('/')); ?>/public/employeeImages/<?php echo e($certificate->location); ?>">
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteCertificate">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($certificate->id); ?>">
                                <input type="submit" value="Delete" class="btn btn-xs btn-danger">
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
    function addRow() {
            var table = document.getElementById("asset");
            var row = table.insertRow(-1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.innerHTML = "<select required class=\"form-control\" name=\"type[]\"><option value=\"\">--Select--</option><?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value=\"<?php echo e($asset->id); ?>\"><?php echo e($asset->type); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </select>";
            cell2.innerHTML = "<textarea required class=\"form-control\" placeholder=\"Asset description\" name=\"details[]\"></textarea>";
        }
        function deleteRow() {
            document.getElementById("asset").deleteRow(-1);
        }
        function addCertificateRow() {
            var table = document.getElementById("Certificate");
            var row = table.insertRow(-1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.innerHTML = "<input type=\"text\" class=\"form-control input-sm\" placeholder=\"Certificate Type\" name=\"type[]\">";
            cell2.innerHTML = "<input type=\"file\" class=\"form-control input-sm\" name=\"certificateFile[]\">";
        }
        function deleteCertificateRow() {
            document.getElementById("asset").deleteRow(-1);
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>