<?php $__env->startSection('content'); ?>
    <div class="col-md-2">
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading text-center">
                <b style="color:white">Custom Daily Slot</b>
            </div>
            <div class="panel-body">
                <table class="table table-responsive">
                    <tbody >
                        <tr>
                            <td>Select Listing Engineer</td>
                        </tr>
                        <tr>
                            <td>
                                <select class="form-control" id="selectle">
                                    <option disabled selected value="">(-- SELECT LE --)</option>
                                    <option value="ALL">All Listing Engineers</option>
                                    <?php $__currentLoopData = $le; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Select From Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date" placeholder= "From Date" class="form-control" id="fromdate" name="fromdate" />
                            </td>
                        </tr>
                        <tr>
                            <td>Select To Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date"  placeholder= "To Date" class="form-control" id="todate" name="todate" />
                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <a class="btn bn-md btn-success" style="width:100%" onclick="showrecordsle()">Get Date Range Details</a>
                            </td>
                        </tr>
                        <!--<tr class="text-center">-->
                        <!--    <td>-->
                        <!--        <a class="btn bn-md btn-primary" style="width:100%" onclick="showtodayrecordsle()">Get Date Details</a>-->
                        <!--    </td>-->
                        <!--</tr>-->
                    </tbody>
                </table>
            </div>
        </div>
        <div class="panel panel-default" styke="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report (Today)</b>
            </div>
            <div class="panel-body" id="minireport">
                <label style="color:black">Total Count : <b><?php echo e($projcount); ?></b></label>
            </div>
        </div>
    </div>
    <div class="col-md-10" >
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading" id="panelhead">
                <label>Daily Listings For The Date : <b><?php echo e($date); ?></b> &nbsp;&nbsp;&nbsp;&nbsp;Current Count: <b><?php echo e($projcount); ?></b></label>
                <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
            </div>
            <div class="panel-body">
                <table class='table table-responsive table-striped' style="color:black" border="1">
                    <thead>
                        <tr>
                            <th style="text-align:center">Ward No.</th>
                            <th style="text-align:center">ID</th>
                            <th style="text-align:center">Owner Contact Number</th>
                            <th style="text-align:center">Site Engineer Contact Number</th>
                            <th style="text-align:center">Procurement Contact Number</th>
                            <th style="text-align:center">Consultant Contact Number</th>
                            <th style="text-align:center">Contractor Contact Number</th>
                            <th style="text-align:center">Listing Engineer</th>
                            <!--<th style="text-align:center">Verification</th>-->
                        </tr>
                    </thead>
                    <tbody id="mainPanel">
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:center"><?php echo e($project->sub_ward_name); ?></td>
                            <td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($project->project_id); ?>&&lename=<?php echo e($project->name); ?>"><?php echo e($project->project_id); ?></a></td>
                            <td style="text-align:center"><?php echo e($project->owner_contact_no); ?></td>
                            <td style="text-align:center"><?php echo e($project->site_engineer_contact_no); ?></td>
                            <td style="text-align:center"><?php echo e($project->procurement_contact_no); ?></td>
                            <td style="text-align:center"><?php echo e($project->consultant_contact_no); ?></td>
                            <td style="text-align:center"><?php echo e($project->contractor_contact_no); ?></td>
                            <td style="text-align:center" id="listname-<?php echo e($project->project_id); ?>">
                                <?php echo e($project->name); ?>

                                <input type="hidden" id="hiddeninp-<?php echo e($project->project_id); ?>" value="<?php echo e($project->listing_engineer_id); ?>" />
                            </td>
                            <!--<td style="text-align:center"><a onclick="" class="btn btn-sm btn-danger">Verify</a></td>-->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    <script type='text/javascript'>
        $( document ).ready(function() {
            var arr = new Array();
            var ids = new Array();
            for(var i=0; i<10000; i++)
            {
                if(document.getElementById('listname-'+i))
                {
                    arr[i] = document.getElementById('listname-'+i).innerText; //Pulling all names in arr array 
                    ids[i] = document.getElementById('hiddeninp-'+i).value;
                }
            }
            var unique = arr.filter(function(item, i, ar){ return ar.indexOf(item) === i; }); //Filtering out unique names from arr array
            var uniqueids = ids.filter(function(item, i, ar){ return ar.indexOf(item) === i; }); //Filtering out unique IDs from ids array
            var ans = new Array();
            for(var i=0;i<unique.length;i++)
            {
                var x = unique[i];
                ans[x] = 0;
                for(var k=0;k<arr.length;k++)
                {
                    if(x == arr[k])
                    {
                        ans[x]++;
                    }
                }
            }
            for (var k in ans){
                if (ans.hasOwnProperty(k)) {
                     document.getElementById('minireport').innerHTML += "<br><label style='color:black'>"+ k + " : "+ans[k];
                     //alert("Key is " + k + ", value is" + ans[k]);
                }
            }
            
        });
        function showrecordsle()
        {
            var e = document.getElementById("selectle");
            var le_id = e.options[e.selectedIndex].value;
            var from_date = document.getElementById('fromdate').value;
            var to_date = document.getElementById('todate').value;
            if(to_date==""){
                showtodayrecordsle();
            }else if(!le_id || !from_date){
                alert('Incomplete Details ! Please Select All Three Fields !!');
                return false;
            }
            else
            {
                orig_from_date = from_date;
                orig_to_date = to_date;
                from_date += ' 00:00:00';
                to_date += ' 00:00:00';
                document.getElementById('mainPanel').innerHTML = '';
                document.getElementById('panelhead').innerHTML = '';
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(URL::to('/')); ?>/getleinfo",
                    data: { id: le_id, from: from_date, to: to_date },
                    async: false,
                    success: function(response)
                    {
                        document.getElementById('panelhead').innerHTML = "<label style='font-weight:bold;'>Listings From Date : <b> "+orig_from_date+" </b> To "+orig_to_date+"  &nbsp;&nbsp;&nbsp;&nbsp; Total Count: <b>"+response[1]+"</b></label>";
                        
                        document.getElementById('mainPanel').innerHTML = '';
                        for(var i=0; i<response[0].length;i++)
                        {
                            document.getElementById('mainPanel').innerHTML += 
                            "<tr><td>"
                                +response[0][i].sub_ward_name+
                            "</td><td><a href='<?php echo e(URL::to('/')); ?>/admindailyslots?projectId="+response[0][i].project_id+"&&lename="+response[0][i].name+"'>"
                                +response[0][i].project_id+
                            "</a></td><td>"
                                +response[0][i].owner_contact_no+
                            "</td><td>"
                                +response[0][i].site_engineer_contact_no+
                            "</td><td>"
                                +response[0][i].procurement_contact_no+
                            "</td><td>"
                                +response[0][i].consultant_contact_no+
                            "</td><td>"
                                +response[0][i].contractor_contact_no+
                            "</td><td><a href='<?php echo e(URL::to('/')); ?>/dailyslots?userId="+response[0][i].id+"'>"
                                +response[0][i].name+
                            "</a></td></tr>";
                        }
                        console.log(response);   
                    }    
                });
            }
            return false;
        }
        function showtodayrecordsle()
        {
            var e = document.getElementById("selectle");
            var le_id = e.options[e.selectedIndex].value;
            var from_date = document.getElementById('fromdate').value;
            if(!le_id || !from_date){
                alert('Please Select A Listing Engineer And From Date !!');
                return false;
            }
            else
            {
                orig_from_date = from_date;
        
                document.getElementById('mainPanel').innerHTML = '';
                document.getElementById('panelhead').innerHTML = '';
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(URL::to('/')); ?>/gettodayleinfo",
                    data: { id: le_id, from_date: from_date },
                    async: false,
                    success: function(response)
                    {
                        document.getElementById('panelhead').innerHTML = "<label style='font-weight:bold;'>Listings From Date : <b> "+from_date+" </b>  &nbsp;&nbsp;&nbsp;&nbsp; Total Count: <b>"+response[1]+"</b></label>";
                        
                        document.getElementById('mainPanel').innerHTML = '';
                        for(var i=0; i<response[0].length;i++)
                        {
                            document.getElementById('mainPanel').innerHTML += 
                            "<tr><td>"
                                +response[0][i].sub_ward_name+
                            "</td><td><a href='<?php echo e(URL::to('/')); ?>/admindailyslots?projectId="+response[0][i].project_id+"&&lename="+response[0][i].name+"'>"
                                +response[0][i].project_id+
                            "</a></td><td>"
                                +response[0][i].owner_contact_no+
                            "</td><td>"
                                +response[0][i].site_engineer_contact_no+
                            "</td><td>"
                                +response[0][i].procurement_contact_no+
                            "</td><td>"
                                +response[0][i].consultant_contact_no+
                            "</td><td>"
                                +response[0][i].contractor_contact_no+
                            "</td><td><a href='<?php echo e(URL::to('/')); ?>/dailyslots?userId="+response[0][i].id+"'>"
                                +response[0][i].name+
                            "</a></td></tr>";
                        }
                        console.log(response);   
                    }    
                });
            }
            return false;
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>