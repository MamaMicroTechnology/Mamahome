<?php $__env->startComponent('mail::layout'); ?>

    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => 'https://mamahome360.com']); ?>
            Mamahome360.com
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
Hello <?php echo e($name); ?>,

We have received your registration request. We will verify your registration in a few minutes.
After that, your login credentials will be<br>
Email : <?php echo e($email); ?><br>
Password : <?php echo e($password); ?><br>

<?php $__env->startComponent('mail::button', ['url' => 'https://mamahome360.com/webapp/blogin']); ?>
Click Here to login
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
Mamahome Pvt. Ltd.


<?php $__env->slot('footer'); ?>
    <?php $__env->startComponent('mail::footer'); ?>
        All Rights Reserved https://mamahome360.com
    <?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>