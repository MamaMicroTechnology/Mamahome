<style>
    .switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div class="panel panel-default" style="border-color:green">
<div class="panel-heading" style="background-color:green;font-weight:bold;font-size:1.3em;color:white">Employees on <?php echo e($dept); ?></div>
<div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
<table class="table table-hover">
<thead>
    <th>Emp Id</th>
    <th>Name</th>
    <th>Dept.</th>
    <th>Designation</th>
    <th>Contact</th>
    <th>Attendance/Reports</th>
    <th>Emp. Details</th>
    <th>Verification</th>
    <th></th>
</thead>
<tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->employeeId); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->department->dept_name); ?></td>
        <td><?php echo e($user->group->group_name); ?></td>
        <td><?php echo e($user->office_phone); ?></td>
        <td>
            <?php if($user->department->dept_name == "Operation" && $user->group->group_name == "Listing Engineer"): ?>
            <a href="<?php echo e(URL::to('/')); ?>/amdate?uid=<?php echo e($user->id); ?>">
                Report
            </a>
            <?php else: ?>
            <a href="<?php echo e(URL::to('/')); ?>/amattendance?userId=<?php echo e($user->employeeId); ?>">
                Attendance
            </a>
            <?php endif; ?>
        </td>
        <td><a href="<?php echo e(URL::to('/')); ?>/ameditEmployee?UserId=<?php echo e($user->employeeId); ?>">Edit</a> &nbsp;|&nbsp;<a href="<?php echo e(URL::to('/')); ?>/amviewEmployee?UserId=<?php echo e($user->employeeId); ?>">View</a></td>
        <td>
            <label class="switch">
                <input <?php echo e($user->verification_status != NULL? $user->verification_status == "Verified"?'checked': '' : 'disabled'); ?>  id="<?php echo e($user->employeeId); ?>" type="checkbox" onchange="updateUser('<?php echo e($user->employeeId); ?>')">
                <span class="slider round"></span>
            </label>
        </td>
        <td>
            <form method="post" action="<?php echo e(URL::to('/')); ?>/inactiveEmployee">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($user->employeeId); ?>">
                <input type="submit" value="Mark Inactive" class="btn btn-sm btn-danger">
            </form>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>

<script>
    function updateUser(arg)
    {
        var userId = arg;
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/updateUser",
            async:false,
            data:{userId : userId},
            success: function(response)
            {
                alert(response);
            }
        });    
    }
</script>