<!DOCTYPE html>
<html>
<body>

<style>
 th, td {
    border: 1px solid black;
}
</style>

<form  method="POST" action="<?php echo e(URL::to('/')); ?>/map" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

   
    <input type="file" name="logo" accept="image/*" />
    <br /><br />
    <input type="submit" value=" Save " />
</form>

<form  method="get" action="<?php echo e(URL::to('/')); ?>/getmap" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

   
    <input type="text" name="mapname" />
    <br /><br />
    <input type="submit" value=" Save " />
</form>

 <table class=" table table-bordered" style="text-align: center; padding:30px;">

 	
                    <tr>
                        <th>project Name</th>
                        <th>Location</th>
                         <th>Latitude</th>
                         <th>Longitude</th>
                         <th>project status</th>
                        
                    </tr>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                        <td> <?php echo e($proj->project_name); ?></td>
                        <td> <?php echo e($proj->siteaddress->address); ?></td>
                        <td> <?php echo e($proj->siteaddress->latitude); ?></td>
                        <td><?php echo e($proj->siteaddress->longitude); ?> </td>
                        <td><?php echo e($proj->project_status); ?> </td>
                    </tr>
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12"></div>
 </table>

 

<div id="map" style="width:800px;height:500px;background:yellow;padding-right: 100px"></div>
<script>
function myMap() {
	var locations = new Array();
    var status = new Array();

	<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      locations.push([<?php echo e($proj->siteaddress->latitude); ?>,<?php echo e($proj->siteaddress->longitude); ?>]);
      status.push("<?php echo e($proj->project_status); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 10,
      center: new google.maps.LatLng(locations[0][0], locations[0][1]),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    
  });

  
    var marker, i;
    var positions = [];
    for (i = 0; i < locations.length; i++) { 
	    if(status[i] == "Planning" &&  $name== $mapname){
	      marker = new google.maps.Marker({
	        position: new google.maps.LatLng(locations[i][0], locations[i][1]),
	        map: map,
	      });
	    }else if(status[i] == "Flooring" && status[i] == $mapname){
	      marker = new google.maps.Marker({
	        position: new google.maps.LatLng(locations[i][0], locations[i][1]),
	        map: map,
	        icon: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'
	      });
	    }else{
	      marker = new google.maps.Marker({
	        position: new google.maps.LatLng(locations[i][0], locations[i][1]),
	        map: map,
	        icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
	      });
	    }
	    positions.push(new google.maps.LatLng(locations[i][0],locations[i][1]));
	}
	
	var flightPath = new google.maps.Polygon({
    path:[positions[0],positions[1],positions[2]],
     strokeColor: "#0000FF",
    strokeOpacity: 0.8,
    strokeWeight: 2,
    fillColor: "#0000FF",
    fillOpacity: 0.4
  });
  flightPath.setMap(map); 
}

</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU&callback=myMap"></script>

<!-- //pie chart// -->
<div id="piechart"></div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Hours per Day'],
  ['order initiated',<?php echo e($initiated); ?>],
  ['order canceled', <?php echo e($initiated1); ?>],
  ['order taken', <?php echo e($initiated2); ?>],
  
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'My Average Day', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>


</body>
</html>