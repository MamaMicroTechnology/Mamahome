<?php $__env->startSection('content'); ?>
<div class="col-md-12" >
        <div class="panel panel-primary"  style="overflow-x:scroll">
           <div class="panel-heading text-center">
                    <a href="<?php echo e(URL::to('/')); ?>/inputview" class="btn btn-danger btn-sm pull-left">Add Enquiry</a>
                    <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
                Enquiry Data&nbsp;&nbsp;&nbsp;   COUNT: [<?php echo e(count($projects)); ?>]
            </div>
            <div class="panel-body">
                <table class='table table-responsive table-striped' style="color:black" border="1">
                    <thead>
                        <tr>
                            <th style="text-align:center">Project Id</th>
                            <th style="text-align:center">requirnment Date</th>
                            <th style="text-align:center"> Contact Number</th>
                            <th style="text-align:center">Quantity</th>
                            <th style="text-align:center">status</th>
                            <th style="text-align:center">Remark</th>
                            <th style="text-align:center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="mainPanel">
                       <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                            <td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($project->project_id); ?>&&lename=<?php echo e($project->name); ?>"><?php echo e($project->project_id); ?></a></td>
                            <td><?php echo e($project->requirement_date); ?>  </td> 
                            <td><?php echo e($project->procurement_contact_no); ?></td>
                            <td><?php echo e($project->quantity); ?>  </td>                     
                            <td><?php echo e($project->status); ?>  </td> 
                            <td><?php echo e($project->notes); ?> </td>
                            
                            <td><a href="<?php echo e(URL::to('/')); ?>/editenq?reqId=<?php echo e($project->id); ?>" class="btn btn-xs btn-primary">Edit</a></td>

                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <center><?php echo e($projects->links()); ?></center>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.leheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>