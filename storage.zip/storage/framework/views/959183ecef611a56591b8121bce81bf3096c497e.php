<?php $__env->startSection('content'); ?>
<style type="text/css">
  .dot {
    height: 9px;
    width: 9px;
    background-color:green;
    border-radius: 50%;
    display: inline-block;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <?php if(session('Added')): ?>
                <div class="alert alert-success alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session('Added')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('NotAdded')): ?>
               <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                   <?php echo e(session('NotAdded')); ?>

                </div>
            <?php endif; ?>
            <button class="btn btn-default form-control" data-toggle="modal" data-target="#addEmployee" style="background-color:green;color:white;font-weight:bold">Add Employee </button>
            <br><br>
            <div class="panel panel-default" style="border-color:#f4811f">
                <div class="panel-heading" style="background-color:#f4811f"><b style="font-size:1.3em;color:white">Departments</b></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $content = explode(" ",$department->dept_name);
                            $con = implode("",$content);

                        ?>
                        <a href="#" class="list-group-item" data-toggle="collapse" data-target="#add<?php echo e($depts[$department->dept_name]); ?>"><?php echo e($department->dept_name); ?>(<?php echo e($depts[$department->dept_name]); ?>)</a>
                        <div id="add<?php echo e($depts[$department->dept_name]); ?>" class="collapse">
                        <?php $__currentLoopData = $groupname[$department->dept_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php 
                            $grp = explode(" ",$name->group->id);
                            $group = implode("",$grp);
                          ?>
                            <a href="#" id="<?php echo e($group); ?>" class="list-group-item" style="color:green">
                            <?php if($name->group_id == $name->group->id ): ?>
                            <?php if($name->group->group_name == "Team Lead"): ?>
                              Senior Team Leader
                            <?php else: ?>
                              <?php echo e($name->group->group_name); ?>

                            <?php endif; ?>
                            <?php endif; ?>
                            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a id="FormerEmployees" class="list-group-item" href="#">Former Employees (<?php echo e($depts["FormerEmployees"]); ?>)</a>
                </div>
            </div>
        </div>
   <div class="col-md-10" id="disp">
      <div class="panel panel-default" style="border-color:green">
        <div class="panel-heading" style="background-color:green;font-weight:bold;font-size:1.3em;color:white">Employees
          </div>

        <div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
                      
                                     <img src="http://mamahome360.com/public/android-icon-36x36.png">
                                     MAMA HOME PVT LTD&nbsp;&nbsp;
                                     Total employees &nbsp;&nbsp;<span class="dot" style=" height: 9px;
                          width: 9px;
                          background-color:green;
                          border-radius: 50%;
                          display: inline-block;"></span> <?php echo e($totalcount); ?>

                          <div class="col-md-4 pull-right">
                                    <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search for names and Phone Number" >
                          </div>
                          <br>
                          <br>
                          <br>

                          <div id="name">
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(URL::to('/')); ?>/viewEmployee?UserId=<?php echo e($user->employeeId); ?>" >
                          <div id="" style="overflow: hidden;" class="col-md-3 col-md-offset-1">
                          <center><img class="img1" src="<?php echo e(URL::to('/')); ?>/public/profilePic/<?php echo e($user->profilepic); ?>" width="100" height="100">
                           <p style="text-align: center;"><?php echo e($user->name); ?></p>
                            <p style="text-align: center;"><?php echo e($user->office_phone); ?></p>
                          
                          </center>
                          <?php if($loop->iteration % 3==0): ?>
                              </div>
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <div class="row">
                              <?php endif; ?>
                         </div>
                        </a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
              </div>
                <table  class="table table-hover table-responsive" style="border: 2px solid gray;">
                  <thead>
                    <th style="border: 1px solid gray;">Department</th>
                    <th style="border: 1px solid gray;">Number of Employees</th>
                    <th style="border: 1px solid gray;">Average Age</th>
                  </thead>
                  <tbody>
                  <?php $totalEmp=0; $totalAvg = 0; $i = 0; ?>
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr> 
                          <td style="border: 1px solid gray;"><?php echo e($department->dept_name); ?></td>
                          <td style="border: 1px solid gray;"><?php echo e($depts[$department->dept_name]); ?></td>
                          <?php $totalEmp += $depts[$department->dept_name]; ?>
                          <td style="border: 1px solid gray;"><?php echo e(round($avgAge[$department->dept_name])); ?></td>
                          <?php $totalAvg += round($avgAge[$department->dept_name]); ?>
                          <?php if($avgAge[$department->dept_name] != 0): ?>
                            <?php $i++ ?>
                          <?php endif; ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <tr> 
                          <th style="border: 1px solid gray; text-align:right;"></th>
                          <th style="border: 1px solid gray;"><?php echo e($totalEmp); ?></th>
                          <th style="border: 1px solid gray;"><?php echo e(round($totalAvg / $i)); ?> </th>
                      </tr>
                    </tbody>
                     </table>
                      <table  class="table table-hover table-responsive" style="border: 2px solid gray;">
                          <thead>
                            <th style="border: 1px solid gray;">Qualification</th>
                            <th style="border: 1px solid gray;">Count</th>
                          </thead>
                          <tbody>
                            <tr> 
                                            <td style="border: 1px solid gray;">MBA & MCA</td>
                                            <td style="border: 1px solid gray;">6</td>
                                           
                            </tr>
                             <tr> 
                                            <td style="border: 1px solid gray;">Engineering</td>
                                            <td style="border: 1px solid gray;">37</td>
                                           
                            </tr>
                            <tr> 
                                            <td style="border: 1px solid gray;">Degree</td>
                                            <td style="border: 1px solid gray;">7</td>
                                           
                            </tr>
                          </tbody>
                        </table>   
        </div>
    </div>
</div>
                 
 
<!--Modal-->
<form method="post" action="<?php echo e(URL::to('/')); ?>/amaddEmployee">
    <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="addEmployee" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#f4811f;color:white;fon-weight:bold">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Employee</h4>
        </div>
        <div class="modal-body">
          <table class="table table-hover">
              <tbody>
                  <tr>
                    <td><label>Emp Id</td>
                    <td> <input required type="text" placeholder="Employee Id" class="form-control" name="employeeId"></td>
                  </tr>
                  <tr>
                    <td><label>Name</label></td>
                    <td><input required type="text" placeholder="Name" class="form-control" name="name"></td>
                  </tr>
                  <tr>
                    <td><label>User-Id Of MMT</label></td>
                    <td><input required type="text" placeholder="User-id of MMT" class="form-control" name="email"></td>
                  </tr>
                  <tr>
                    <td><label>Department</label></td>
                      <td><select required class="form-control" name="dept">
                      <option value="">--Select--</option>
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select></td>
                  </tr>
                  <tr>
                    <td><label>Designation</label></td>
                    <td> <select required class="form-control" name="designation">
                      <option value="">--Select--</option>
                      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->group_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select></td>
                  </tr> 
                </tbody>
              </table>
            </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-success">Add</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

</form>

<div class='b'></div>
<div class='bb'></div>
<div class='message'>
  <div class='check'>
    &#10004;
  </div>
  <p>
    Success
  </p>
  <p>
    <?php if(session('Success')): ?>
    <?php echo e(session('Success')); ?>

    <?php endif; ?>
  </p>
  <button id='ok'>
    OK
  </button>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
    $content = explode(" ",$department->dept_name);
    $con = implode("",$content);
?>
<?php $__currentLoopData = $groupname[$department->dept_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php 
                            $grp = explode(" ",$name->group->id);
                            $group = implode("",$grp);                            
 ?>
  
<script type="text/javascript">
$(document).ready(function () {
    $("#<?php echo e($group); ?>").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewmhemployee?count=<?php echo e($depts[$department->dept_name]); ?>&&group="+encodeURIComponent("<?php echo e($group); ?>"), function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
</script>
<script type="text/javascript">
$(document).ready(function () {
    $("#FormerEmployees").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/viewmhemployee?dept=FormerEmployees&&count=<?php echo e($depts["FormerEmployees"]); ?>", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
 
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
  function myFunction()
{
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("name");
    p = ul.getElementsByTagName("a");
    for (i = 0; i < p.length; i++) {
        a = p[i].getElementsByTagName("p")[0];
        b = p[i].getElementsByTagName("p")[1];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1 || b.innerHTML.toUpperCase().indexOf(filter) > -1) {
             p[i].style.display = "";
        } else {
            p[i].style.display = "none";
        }
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>