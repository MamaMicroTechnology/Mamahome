<?php
  $user = Auth::user()->group_id;
  $ext = ($user == 4? "layouts.amheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-12">
    <div class="panel panel-default" style="border-color:rgb(244,129,31);text-align: center;">
                    <div class="panel-heading" style="background-color:rgb(244,129,31);color:white;">Begin adding the products by category and brand followed by sub-category</div>
                               
                <td style=""></td>
     </div>      
</div>
</div>
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-6">
                <div class="panel panel-default" style="border-color:green;">
                    <div class="panel-heading" style="background-color:green;color:white;">Category</div>
                    <div class="panel-body" style="height:400px; max-height: 400px; overflow-y: scroll;">
                     <?php if(Auth::user()->group_id != 23): ?>
                       <form method="post" action="<?php echo e(URL::to('/')); ?>/addCategory" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-3">
                                <input required type="text" placeholder="Category" name="category" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <select class="form-control" required name="measurement">
                                    <option value="" disabled selected>-Select-</option>
                                    <option value="Ton">Ton</option>
                                    <option value="Bags">Bags</option>
                                    <option value="No">No</option>
                                    <option value="Sq.ft">Sq. Ft</option>
                                    <option value="Ltr.">Ltr</option>
                                    <option value="Meter">Meter</option>
                                    <option value="CUM">CUM</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <input required type="file" placeholder="category image" name="catimage" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <input type="submit" value="Save" class="form-control btn btn-primary">
                            </div>
                        </form>
                        <?php endif; ?>
                        <br>
                        <table class="table table-hover">
                            <tr>
                            <td>Category</td>
                            <td>Action</td>
                            </tr>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr id="current<?php echo e($category->id); ?>">
                             <?php if(Auth::user()->group_id != 23): ?>
                                <td><?php echo e($category->category_name); ?></td>
                                <?php else: ?>
                                <?php if($category->id == $sub): ?>
                                 <td><?php echo e($category->category_name); ?></td>
                                <td>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteCategory">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($category->id); ?>" name="id">
                                    <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="editcategory('<?php echo e($category->id); ?>')">Edit</button>
                                </td>
                                 <?php endif; ?>
                              <?php endif; ?> 
                              <?php if(Auth::user()->group_id != 23): ?>   
                              <td>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteCategory">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($category->id); ?>" name="id">
                                    <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="editcategory('<?php echo e($category->id); ?>')">Edit</button>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <tr class="hidden" id="edit<?php echo e($category->id); ?>">
                                
                                <td colspan=3>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/updateCategory" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($category->id); ?>" name="id">
                                    <div class="input-group">
                                        <input type="text" name="name" value="<?php echo e($category->category_name); ?>" class="form-control input-sm">
                                        <input required type="file" placeholder="category image" name="catimage" class="form-control">
                                        <div class="input-group-btn">
                                            <button class="btn btn-sm btn-success" type="submit">Save</button>
                                        </div>
                                    </div>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="panel panel-default" style="border-color:green;">
                    <div class="panel-heading" style="background-color:green;color:white;">Brand</div>
                    <div class="panel-body" style="height:400px; max-height: 400px; overflow-y: scroll;">
                        <form method="post" action="<?php echo e(URL::to('/')); ?>/addBrand" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-3">
                                <select name="cat" class="form-control">
                                    <option value="">--Category--</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Auth::user()->group_id != 23): ?>
                                       <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                       <?php else: ?>
                                          <?php if($category->id == $sub): ?>
                                       <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                           <?php endif; ?>
                                     <?php endif; ?>      
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input required type="text" placeholder="Brand" name="brand" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <input required type="file" placeholder="Brand" name="brandimage" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <input type="submit" value="Save" class="form-control btn btn-primary">
                            </div>
                        </form>
                        <br><br>
                        <table class="table table-hover">
                            <tr>
                            <td>Category</td>
                            <td>Brand</td>
                            <td>Action</td>
                            </tr>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="currentb<?php echo e($brand->id); ?>">
                                <td><?php echo e($brand->category->category_name); ?></td>
                                <td><?php echo e($brand->brand); ?></td>
                                <td>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/deletebrand">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($brand->id); ?>" name="id">
                                    <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                                </td>
                                <td><button class="btn btn-sm btn-primary" onclick="editbrand('<?php echo e($brand->id); ?>')">Edit</button></td>
                            </tr>
                             <tr class="hidden" id="editb<?php echo e($brand->id); ?>">
                                
                                <td colspan=3>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/updateBrand" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($brand->id); ?>" name="id">
                                    <div class="input-group">
                                        <input type="text" name="name" value="<?php echo e($brand->brand); ?>" class="form-control input-sm">
                                        <input required type="file" placeholder="Brand" name="brandimage" class="form-control">
                                        <div class="input-group-btn">
                                            <button class="btn btn-sm btn-success" type="submit">Save</button>
                                        </div>
                                    </div>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-default" style="border-color:green;">
                    <div class="panel-heading" style="background-color:green;color:white;">Sub Category
                        <button style="background-color:black" class="btn btn-xs  pull-right" data-toggle="modal" data-target="#addCategory"><span class="glyphicon glyphicon-plus"></span></button>
                    </div>
                    <div class="panel-body" style="height:400px; max-height: 400px; overflow-y: scroll;">
                        <table class="table table-hover">
                            <tr>
                            <td>Category</td>
                            <td>Brand</td>
                            <td>Sub Category</td>
                             <td>Action</td>
                            </tr>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="currentsub<?php echo e($subcategory->id); ?>">
                                <td><?php echo e($subcategory->category != null ? $subcategory->category->category_name : ''); ?></td>
                                 <td><?php echo e($subcategory->subcategory != null ? $subcategory->brand->brand : ''); ?></td>
                                 <td><?php echo e($subcategory->sub_cat_name); ?></td>
                                <td>
                                    <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteSubCategory">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" value="<?php echo e($subcategory->id); ?>" name="id">
                                        <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                                <td><button class="btn btn-sm btn-primary" onclick="editsubcategory('<?php echo e($subcategory->id); ?>')">Edit</button></td>
                            </tr>
                            <tr id="editsub<?php echo e($subcategory->id); ?>" class="hidden">
                                <td colspan=3>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/updateSubCategory" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($subcategory->id); ?>" name="id">
                                    <div class="input-group">
                                        <input type="text" name="name" value="<?php echo e($subcategory->sub_cat_name); ?>" 
                                        class="form-control input-sm"><br><br>
                                        <input type="text" name="Quantity" value="<?php echo e($subcategory->Quantity); ?>" 
                                        class="form-control input-sm" style="width: 50%">
                                        
             <input required type="file" placeholder="Minimum Quantity" name="subimage" class="form-control">
                                        <div class="input-group-btn">
                                            <button class="btn btn-sm btn-success" type="submit">Save</button>
                                        </div>
                                    </div>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form method="post" action="<?php echo e(URL::to('/')); ?>/addSubCategory" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="addCategory" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#f4811f;color:white;fon-weight:bold">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Category</h4>
        </div>
        <div class="modal-body">
            <select class="form-control" required name="category" onchange="getBrands()" id="category">
                <option value="">-Select-</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if(Auth::user()->group_id != 23): ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                <?php else: ?> 
                     <?php if($category->id == $sub): ?>
                     <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                      <?php endif; ?>
                 <?php endif; ?>     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            <select class="form-control" required name="brand" id="brand">
                
            </select><br>
            <input required type="text" placeholder="Sub Category" name="subcategory" class="form-control"><br>
            <input required type="text" placeholder="Minimum Quantity" name="Quantity" class="form-control" ><br>

             <input required type="file" placeholder="Minimum Quantity" name="subimage" class="form-control">
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-success">Add</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
</form>
<div class='b'></div>
<div class='bb'></div>
<div class='message'>
  <div class='check'>
    &#10004;
  </div>
  <p>
    Success
  </p>
  <p>
    <?php if(session('Success')): ?>
    <?php echo e(session('Success')); ?>

    <?php endif; ?>
  </p>
  <button id='ok'>
    OK
  </button>
</div>
<script>
    function editcategory(arg){
        document.getElementById('current'+arg).className = "hidden";
        document.getElementById('edit'+arg).className = "";
    }
    function editbrand(arg){
        document.getElementById('currentb'+arg).className = "hidden";
        document.getElementById('editb'+arg).className = "";
    }
    function editsubcategory(arg){
        document.getElementById('currentsub'+arg).className = "hidden";
        document.getElementById('editsub'+arg).className = "";
    }
    function getBrands(){
        var e = document.getElementById('category');
        var cat = e.options[e.selectedIndex].value;
        $("html body").css("cursor", "progress");
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/getBrands",
            async:false,
            data:{cat : cat},
            success: function(response)
            {
                console.log(response);
                var ans = "<option value=''>--Select--</option>";
                for(var i=0;i<response[0].length;i++)
                {
                    ans += "<option value='"+response[0][i].id+"'>"+response[0][i].brand+"</option>";
                }
                document.getElementById('brand').innerHTML = ans;
                $("body").css("cursor", "default");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>