<?php $__env->startSection('content'); ?>
<br>
<div class="col-md-8 col-md-offset-2">
<div class="panel panel-success">
    <div class="panel-heading">
        Total No of Projects In Zone 1 : <?php echo e($totalProjects); ?>

    </div>
    <div class="panel-body">
        <div class="col-md-6">
            <center>Ward</center>
            <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojectsize">
                <select required class="form-control" name="ward">
                    <option value="">--Select--</option>
                <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ward->id); ?>" <?php echo e($ward->id == $wardId? 'selected':''); ?>><?php echo e($ward->ward_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <button class="btn btn-primary form-control" type="submit">Fetch</button>
            </form>
            <br>
            <?php if(session('Error')): ?>
                <p class="alert alert-error"><?php echo e(session('Error')); ?></p>
            <?php endif; ?>
            <?php if($planningCount != NULL): ?>
            Total Project sizes under <?php echo e($wardname->ward_name); ?> (based on stages)<br>
            Total No. of Projects : <?php echo e($planningCount + $diggingCount + $foundationCount + $pillarsCount + $completionCount + $fixturesCount + $paintingCount + $carpentryCount + $flooringCount + $plasteringCount + $enpCount + $roofingCount + $wallsCount); ?>

            Total Sizes : <b><?php echo e($planningSize + $diggingSize + $foundationSize + $pillarsSize + $completionSize + $fixturesSize + $paintingSize + $carpentrySize + $flooringSize + $plasteringSize + $enpSize + $roofingSize + $wallsSize); ?></b>
            <table class="table table-hover" border="1">
                <thead>
                    <th class="text-center">Stages</th>
                    <th class="text-center">No. of Projects</th>
                    <th class="text-center">Size<br>(in Sq. Ft.)</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Planning</td>
                        <td class="text-center"> <?php echo e($planningCount); ?> </td>
                        <td> <?php echo e($planningSize); ?></td>
                    </tr>
                    <tr>
                        <td>Digging</td>
                        <td class="text-center"><?php echo e($diggingCount); ?></td>
                        <td><?php echo e($diggingSize); ?></td>
                    </tr>
                    <tr>
                        <td>Foundation</td>
                        <td class="text-center"><?php echo e($foundationCount); ?></td>
                        <td><?php echo e($foundationSize); ?></td>
                    </tr>
                    <tr>
                        <td>Pillars</td>
                        <td class="text-center"><?php echo e($pillarsCount); ?></td>
                        <td><?php echo e($pillarsSize); ?></td>
                    </tr>
                    <tr>
                        <td>Walls</td>
                        <td class="text-center"><?php echo e($wallsCount); ?></td>
                        <td><?php echo e($wallsSize); ?></td>
                    </tr>
                    <tr>
                        <td>Roofing</td>
                        <td class="text-center"><?php echo e($roofingCount); ?></td>
                        <td><?php echo e($roofingSize); ?></td>
                    </tr>
                    <tr>
                        <td>Electrical &amp; Plumbing</td>
                        <td class="text-center"><?php echo e($enpCount); ?></td>
                        <td><?php echo e($enpSize); ?></td>
                    </tr>
                    <tr>
                        <td>Plastering</td>
                        <td class="text-center"><?php echo e($plasteringCount); ?></td>
                        <td><?php echo e($plasteringSize); ?></td>
                    </tr>
                    <tr>
                        <td>Flooring</td>
                        <td class="text-center"><?php echo e($flooringCount); ?></td>
                        <td><?php echo e($flooringSize); ?></td>
                    </tr>
                    <tr>
                        <td>Carpentry</td>
                        <td class="text-center"><?php echo e($carpentryCount); ?></td>
                        <td><?php echo e($carpentrySize); ?></td>
                    </tr>
                    <tr>
                        <td>Paintings</td>
                        <td class="text-center"><?php echo e($paintingCount); ?></td>
                        <td><?php echo e($paintingSize); ?></td>
                    </tr>
                    <tr>
                        <td>Fixtures</td>
                        <td class="text-center"><?php echo e($fixturesCount); ?></td>
                        <td><?php echo e($fixturesSize); ?></td>
                    </tr>
                    <tr>
                        <td>Completion</td>
                        <td class="text-center"><?php echo e($completionCount); ?></td>
                        <td><?php echo e($completionSize); ?></td>
                    </tr>
                </tbody>
            </table> 
            <?php endif; ?>
        </div>

        <?php if($subwards != NULL): ?>
        <div class="col-md-6">
            <center>Sub Ward</center>
            <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojectsize">
                <input type="hidden" name="ward" value=<?php echo e($wardId); ?>>
                <select required class="form-control" name="subward">
                    <option value="">--Select--</option>
                    <?php $__currentLoopData = $subwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ward->id); ?>" <?php echo e($subwardId == $ward->id? 'selected':''); ?>><?php echo e($ward->sub_ward_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <button class="btn btn-primary form-control" type="submit">Fetch</button>
            </form>
            <br>
            <?php if(session('Error')): ?>
                <p class="alert alert-error"><?php echo e(session('Error')); ?></p>
            <?php endif; ?>
            <?php if($planning != NULL): ?>
            
            <!--Counting project size-->
            <?php $planC = 0; ?>
            <?php $__currentLoopData = $planning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $planC += $plan->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $digC = 0; ?>
            <?php $__currentLoopData = $digging; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $digC += $dig->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $foundC = 0; ?>
            <?php $__currentLoopData = $foundation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $found): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $foundC += $found->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $pillarC = 0; ?>
            <?php $__currentLoopData = $pillars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pillar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $pillarC += $pillar->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $wallsC = 0; ?>
            <?php $__currentLoopData = $walls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $wallsC += $wall->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $roofC = 0; ?>
            <?php $__currentLoopData = $roofing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $roofC += $roof->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $enpC = 0; ?>
            <?php $__currentLoopData = $enp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $enpC += $el->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $plasterC = 0; ?>
            <?php $__currentLoopData = $plastering; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $plasterC += $plaster->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $floorC = 0; ?>
            <?php $__currentLoopData = $flooring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $floorC += $floor->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $carpC = 0; ?>
            <?php $__currentLoopData = $carpentry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $carpentryC += $carp->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $paintC = 0; ?>
            <?php $__currentLoopData = $painting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $paintC += $paint->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $fixC = 0; ?>
            <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $fixC += $fix->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $completeC = 0; ?>
            <?php $__currentLoopData = $completion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $completeC += $complete->project_size; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <!--Project size counting ends-->
            
            
            Total Project sizes under <?php echo e($subwardName); ?> (based on stages)<br>
            Total No. of Projects : <?php echo e(count($planning) + count($digging) + count($foundation) + count($pillars) + count($walls) + count($roofing) + count($enp) + count($completion) + count($fixtures) + count($painting) + count($carpentry) + count($flooring) + count($plastering)); ?>

            Total Sizes : <b><?php echo e($planC + $digC + $foundC + $pillarC + $completeC + $fixC + $paintC + $carpC + $floorC + $plasterC + $enpC + $roofC + $wallsC); ?></b>
            <table class="table table-hover" border="1">
                <thead>
                    <th class="text-center">Stages</th>
                    <th class="text-center">No. of Projects</th>
                    <th class="text-center">Size<br>(in Sq. Ft.)</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Planning</td>
                        <td class="text-center"> <?php echo e(count($planning)); ?> </td>
                        <td>
                            <?php echo e($planC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Digging</td>
                        <td class="text-center"><?php echo e(count($digging)); ?></td>
                        <td>
                            <?php echo e($digC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Foundation</td>
                        <td class="text-center"><?php echo e(count($foundation)); ?></td>
                        <td>
                            <?php echo e($foundC); ?>    
                        </td>
                    </tr>
                    <tr>
                        <td>Pillars</td>
                        <td class="text-center"><?php echo e(count($pillars)); ?></td>
                        <td>
                            <?php echo e($pillarC); ?>    
                        </td>
                    </tr>
                    <tr>
                        <td>Walls</td>
                        <td class="text-center"><?php echo e(count($walls)); ?></td>
                        <td>
                            <?php echo e($wallsC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Roofing</td>
                        <td class="text-center"><?php echo e(count($roofing)); ?></td>
                        <td>
                            <?php echo e($roofC); ?>    
                        </td>
                    </tr>
                    <tr>
                        <td>Electrical &amp; Plumbing</td>
                        <td class="text-center"><?php echo e(count($enp)); ?></td>
                        <td>
                            <?php echo e($enpC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Plastering</td>
                        <td class="text-center"><?php echo e(count($plastering)); ?></td>
                        <td>
                            <?php echo e($plasterC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Flooring</td>
                        <td class="text-center"><?php echo e(count($flooring)); ?></td>
                        <td>
                            <?php echo e($floorC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Carpentry</td>
                        <td class="text-center"><?php echo e(count($carpentry)); ?></td>
                        <td>
                            <?php echo e($carpC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Paintings</td>
                        <td class="text-center"><?php echo e(count($painting)); ?></td>
                        <td>
                            <?php echo e($paintC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Fixtures</td>
                        <td class="text-center"><?php echo e(count($fixtures)); ?></td>
                        <td>
                            <?php echo e($fixC); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Completion</td>
                        <td class="text-center"><?php echo e(count($completion)); ?></td>
                        <td>
                            <?php echo e($completeC); ?>

                        </td>
                    </tr>
                </tbody>
            </table> 
        <?php endif; ?>
        </div>
<?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>