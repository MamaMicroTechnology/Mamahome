<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading text-center" >
            <b>
              <?php if(  $name == "Team Lead"): ?>
            Senior <?php echo e($name); ?></b></div>
            <?php else: ?>
            <?php echo e($name); ?></b></div>
            <?php endif; ?>
            <?php if(SESSION('success')): ?>
                <div class="text-center alert alert-success">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <h4 style="font-size:1em"><?php echo e(SESSION('success')); ?></h4>
                </div>
                <?php endif; ?>
            <div class ="panel-body">

                       
                       <table class="table table-hover">
                           <thead>
                               <th>Login Date</th>
                               <th>Name</th>
                               <th>Login Time</th>
                               <th>Logout Time</th>
                               <th>Late Login Remark</th>
                           </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($user->logindate != null ? date('d-m-Y',strTotime($user->logindate)) : " "); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->logintime); ?></td>
                                    <td><?php echo e($user->logout); ?></td> 
                                    <td><?php echo e($user->remark); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                       </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>