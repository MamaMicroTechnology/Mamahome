<?php $__env->startSection('content'); ?>
<?php $count = 1; ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Report of <?php echo e($user->name); ?> for <?php echo e(date('d-m-Y')); ?>

                </div>
                <div class="panel-body">
                    <form method=POST action="<?php echo e(URL::to('/')); ?>/grade">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="userId" value="<?php echo e($user->employeeId); ?>">
                        <input type="hidden" name="date" value="<?php echo e($date); ?>">
                            <div class="col-md-12">
                                <div class="col-md-4">AM Remark:</div>
                                <div class="col-md-8"><input placeholder="AM Remark" type="text" value="<?php echo e($attendance->am_remarks); ?>" name="amremark" class="form-control"></div>
                            </div><br><br>
                            <div class="col-md-12">
                                <div class="col-md-4">Credits earned:</div>
                                <div class="col-md-8"><textarea name="remark" class="form-control" placeholder="Remark" rows="1"><?php echo e($attendance->remarks); ?></textarea></div>
                            </div><br><br><br>
                            <div class="col-md-12">
                                <div class="col-md-4">Grade:</div>
                                <div class="col-md-8">
                                    <select name="grade" class="form-control input-xs">
                                        <option value="">--Select--</option>
                                        <option value="A" <?php echo e($attendance->grade == "A"?'selected':''); ?>>A</option>
                                        <option value="B" <?php echo e($attendance->grade == "B"?'selected':''); ?>>B</option>
                                        <option value="C" <?php echo e($attendance->grade == "C"?'selected':''); ?>>C</option>
                                        <option value="D" <?php echo e($attendance->grade == "D"?'selected':''); ?>>D</option>
                                    </select>
                                </div>
                            </div><br><br>
                            <p><button id="save" class="btn btn-primary form-control">Save</button></p>
                        </form>
                        <p><?php echo e($attendance->am_remark); ?></p>
                    </div>
                    <table class="table">
                        <thead>
                            <th>Sl.No.</th>
                            <th>Report</th>
                            <th>Start</th>
                            <th>End</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($report->report); ?></td>
                                <td><?php echo e($report->start); ?></td>
                                <td><?php echo e($report->end); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>