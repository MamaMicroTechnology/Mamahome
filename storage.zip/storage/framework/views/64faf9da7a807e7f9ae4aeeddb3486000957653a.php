<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading text-center"><b>Follow Up Projects</b></div>
            <div class ="panel-body">
                 <!-- <form method="GET" action="<?php echo e(URL::to('/')); ?>/followupproject">
                        <div class="col-md-12">
                                    <div class="col-md-2">
                                        <label>From (Follow_up  Date)</label>
                                        <input value = "<?php echo e(isset($_GET['from']) ? $_GET['from']: ''); ?>" type="date" class="form-control" name="from">
                                    </div>
                                    <div class="col-md-2">
                                        <label>To (Follow_up Date)</label>
                                        <input  value = "<?php echo e(isset($_GET['to']) ? $_GET['to']: ''); ?>" type="date" class="form-control" name="to">
                                    </div>
                                    <div class="col-md-2">
                                    <label></label>
                                    <input type="submit" value="Fetch" class="form-control btn btn-primary">
                                </div>
                        </div>
                </form> -->
                <!-- <br><br><br><hr> -->
                <table class="table table-responsive" border=1>
                    <thead>
                        <th>Project-Id</th>
                        <th>Project Name</th>
                        <th>Address</th>
                        <th>Contact</th>
                        <th>Required Date</th>
                        <th>Follow Up Date</th>
                        <th>Update Follow Up</th>
                        <th>Enquiry</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td  style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($project->project_id); ?>&&lename=<?php echo e($project->name); ?>" target="_blank"><?php echo e($project->project_id); ?></a></td>
                            <td><?php echo e($project->project_name); ?></td>
                             <td id="projsite-<?php echo e($project->project_id); ?>">
                                     <a target="_blank" href="https://maps.google.co.in?q=<?php echo e($project->siteaddress != null ? $project->siteaddress->address : ''); ?>"><?php echo e($project->siteaddress != null ? $project->siteaddress->address : ''); ?></a>
                                    </td>
                            <td><?php echo e($project->procurementdetails != NULL ? $project->procurementdetails->procurement_contact_no:''); ?></td>
                            <td><?php echo e($project->reqDate ? date('d-m-Y', strtotime($project->reqDate)) : " "); ?></td>
                            <td><?php echo e($project->follow_up_date ? date('d-m-Y', strtotime($project->follow_up_date)) : " "); ?></td>
                            <td><input tabindex="-1" value="<?php echo e($project->note); ?>" id="note-<?php echo e($project->project_id); ?>" name="note-<?php echo e($project->project_id); ?>" class="form-control" onblur="updatenote(<?php echo e($project->project_id); ?>)" /></td>
                            <td><a class="btn btn-sm btn-success" id="addenquiry" onclick="addrequirement(<?php echo e($project->project_id); ?>)" style="color:white;font-weight:bold">Add Enquiry</a></td>
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function updatenote(arg)
    {
        if(document.getElementById('note-'+arg).value)
        {
            var x = document.getElementById('note-'+arg).value;
            $.ajax({
                type: 'GET',
                url: "<?php echo e(URL::to('/')); ?>/updateNoteFollowUp",
                async:false,
                data: {value: x, id: arg},
                success: function(response)
                {
                    console.log(response);
                }
            });
            
        }    
        return false;
    }
</script>
<script type="text/javascript">
        function addrequirement(id){
            window.location.href="<?php echo e(URL::to('/')); ?>/requirements?projectId="+id;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>