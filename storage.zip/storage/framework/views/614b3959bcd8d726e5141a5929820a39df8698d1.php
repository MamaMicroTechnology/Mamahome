<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 2? "layouts.app":"layouts.teamheader");
?>

<?php $__env->startSection('content'); ?>

<!-- Modal -->
<?php if(Auth::user()->group_id != 2): ?>
<form method="POST" action="<?php echo e(URL::to('/')); ?>/addKRA">
    <?php else: ?>
    <form method="POST" action="<?php echo e(URL::to('/')); ?>/teamaddKRA">
    <?php endif; ?>
    <?php echo e(csrf_field()); ?>

    <div id="addKRA" class="modal fade" role="dialog">
      <div class="modal-dialog">
    
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Add KRA</h4>
          </div>
          <div class="modal-body">
            
            <div class="row">
                <div class="col-md-4">Department</div>
                <div class="col-md-8">
                    <select name="department" class="form-control">
                        <option vlaue="">--Select--</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div><br>
            <div class="row">
                <div class="col-md-4">Designation</div>
                <div class="col-md-8">
                    <select name="group" class="form-control">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($group->id); ?>"><?php echo e($group->group_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div><br>
            <div class="row">
                <div class="col-md-4">Role</div>
                <div class="col-md-8"><input name="role" type="text" class="form-control" placeholder="Role"></div>
            </div><br>
            <div class="row">
                <div class="col-md-4">Goal</div>
                <div class="col-md-8"><input name="goal" type="text" class="form-control" placeholder="Goal"></div>
            </div><br>
            <div class="row">
                <div class="col-md-4">Key result area</div>
                <div class="col-md-8"><input name="kra" type="text" class="form-control" placeholder="Key result area"></div>
            </div><br>
            <div class="row">
                <div class="col-md-4">Key performance area</div>
                <div class="col-md-8"><input name="kpa" type="text" class="form-control" placeholder="Key performance area"></div>
            </div>
            
          </div>
          <div class="modal-footer">
             <div class="row">
                <div class="col-md-6"><input type="submit" value="Save" class="form-control btn btn-success"></div>
                <div class="col-md-6"><input type="reset" value="Clear" class="form-control btn btn-danger"></div>
            </div>
          </div>
        </div>
    
      </div>
    </div>
</form>

<div class="col-md-10 col-md-offset-1">
    <div class="panel panel-default" style="border-color:#f4811f">
        <div class="panel-heading" style="background-color:#f4811f"><b style="color:white;font-size:1.3em">KRA List</b> <button class="btn btn-sm btn-success pull-right" data-toggle="modal" data-target="#addKRA">Add</button></div>
        <div class="panel-body">
            <table class="table table-hover" border=1>
                <thead>
                    <th style="text-align: center;width:5%">Department Name</th>
                    <th style="text-align: center;width:5%">Designation</th>
                    <th style="text-align: center;width:20%">Role</th>
                    <th style="text-align: center;width:15%">Goal</th>
                    <th style="text-align: center;width:15%">Key Result Area</th>
                    <th style="text-align: center;width:20%">Key Performance Area</th>
                    <th style="text-align: center;width:20%">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="current<?php echo e($kra->group_id); ?>">
                        <td style="text-align: center;"><?php echo e($kra->dept_name); ?></td>
                        <td style="text-align: center;"><?php echo e($kra->group_name); ?></td>
                        <td><?php echo e($kra->role); ?></td>
                        <td><?php echo e($kra->goal); ?></td>
                        <td><?php echo e($kra->key_result_area); ?></td>
                        <td><?php echo e($kra->key_performance_area); ?></td>
                        <td style="text-align:center" colspan="2">
                           
                            <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#myModal<?php echo e($kra->id); ?>">Edit</button>
                           
                            <?php if(Auth::user()->group_id != 2): ?>
                            <a href="<?php echo e(URL::to('/')); ?>/deletekra?deptid=<?php echo e($kra->department_id); ?>&groupid=<?php echo e($kra->group_id); ?>" class="btn btn-sm btn-danger">Delete</a>
                            <?php else: ?>
                            <a href="<?php echo e(URL::to('/')); ?>/teamdeletekra?deptid=<?php echo e($kra->department_id); ?>&groupid=<?php echo e($kra->group_id); ?>" class="btn btn-sm btn-danger">Delete</a>
                            <?php endif; ?>
                        </td>    
                    </tr>
                   
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php if(Auth::user()->group_id != 2): ?>
<?php $__currentLoopData = $kras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="modal fade" id="myModal<?php echo e($kra->id); ?>" role="dialog">
    <div class="modal-dialog">             
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="background-color: green;color: white;">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Edit KRA List</h4>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(URL::to('/')); ?>/updatekra?deptid=<?php echo e($kra->department_id); ?>&groupid=<?php echo e($kra->group_id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" value="<?php echo e($kra->id); ?>" name="id">
                    <table>
                        <tr>
                        <td>Role</td>
                        <td><input type="text" name="role" value="<?php echo e($kra->role); ?>" class="form-control input-sm"></td>
                        </tr>
                        <tr>
                        <td>Goal</td>
                        <td><input type="text" name="goal" value="<?php echo e($kra->goal); ?>" class="form-control input-sm">
                        </td>
                        </tr>
                        <tr>
                        <td>Key Result Area</td>
                        <td><input type="text" name="kra" value="<?php echo e($kra->key_result_area); ?>" class="form-control input-sm">
                        </td>
                        </tr>  
                        <tr>
                        <td>key performance area</td> 
                             <td><input type="text" name="kpa" value="<?php echo e($kra->key_performance_area); ?>" class="form-control input-sm">
                        </td>
                        </tr>
                    </table>           
                    <div class="modal-footer">
                         <button class="btn btn-sm btn-success" type="submit">Save</button>
                     </div>
                </form>
             </div>              
         </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<?php $__currentLoopData = $kras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="modal fade" id="myModal<?php echo e($kra->id); ?>" role="dialog">
    <div class="modal-dialog">             
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="background-color: green;color: white;">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Edit KRA List</h4>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(URL::to('/')); ?>/teamupdatekra?deptid=<?php echo e($kra->department_id); ?>&groupid=<?php echo e($kra->group_id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" value="<?php echo e($kra->id); ?>" name="id">
                    <table>
                        <tr>
                        <td>Role</td>
                        <td><input type="text" name="role" value="<?php echo e($kra->role); ?>" class="form-control input-sm"></td>
                        </tr>
                        <tr>
                        <td>Goal</td>
                        <td><input type="text" name="goal" value="<?php echo e($kra->goal); ?>" class="form-control input-sm">
                        </td>
                        </tr>
                        <tr>
                        <td>Key Result Area</td>
                        <td><input type="text" name="kra" value="<?php echo e($kra->key_result_area); ?>" class="form-control input-sm">
                        </td>
                        </tr>  
                        <tr>
                        <td>key performance area</td> 
                             <td><input type="text" name="kpa" value="<?php echo e($kra->key_performance_area); ?>" class="form-control input-sm">
                        </td>
                        </tr>
                    </table>           
                    <div class="modal-footer">
                         <button class="btn btn-sm btn-success" type="submit">Save</button>
                     </div>
                </form>
             </div>              
         </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class='b'></div>
<div class='bb'></div>
<div class='message'>
  <div class='check'>
    &#10004;
  </div>
  <p>
    Success
  </p>
  <p>
    <?php if(session('Success')): ?>
    <?php echo e(session('Success')); ?>

    <?php endif; ?>
  </p>
  <button id='ok'>
    OK
  </button>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>