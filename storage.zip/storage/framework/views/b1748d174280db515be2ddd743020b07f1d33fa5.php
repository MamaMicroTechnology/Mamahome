
<div class="panel panel-default" style="border-color:green">
<div class="panel-heading" style="background-color:green;font-weight:bold;font-size:1.3em;color:white" ><?php echo e($asset); ?> Details
<button type="button" class="btn btn-danger pull-right" data-toggle="modal" data-target="#myModal">ADD</button></div>
<div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
	<table class="table table-hover table-bordered" style="width:25%;">
            <tbody>
                <thead>
                    <th colspan="2" style="text-align: center;">Total Count Information</th>
                </thead>
                <tr >
                    <td><label>Assigned <?php echo e($asset); ?> </label></td>
                    <td><?php echo e($rcount); ?></td>
                   

                </tr>
               
                <tr >
                    <td><label>Remaining <?php echo e($asset); ?></label></td>
                    <td><?php echo e($remaining); ?></td>
                   
                </tr>
                 <tr  >
                    <td><label>Total <?php echo e($asset); ?>s </label></td>
                    <td><?php echo e($tcount); ?></td>
                   
                   
                </tr>
            </tbody>
     </table>
    <table class="table table-hover">
    <thead>
        <th>Provider</th>
        <th>SIMCard Number</th>
        <th>Remark</th>
        <th>Action</th>
        <th>Status</th>
       
    </thead>
    <tbody>
    <?php $__currentLoopData = $mh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($mh->provider); ?> </td>
        <td><?php echo e($mh->sim_number); ?> </td>
        <td><?php echo e($mh->sim_remark); ?> </td>
        <td>
              <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteassetsimcard">
	                <?php echo e(csrf_field()); ?>

	                <input type="hidden" name="id" value="<?php echo e($mh->id); ?>">
	                <input type="submit" value="Delete" class="btn btn-xs btn-danger"> 
	           </form>

        </td>
        <td><?php echo e($mh->status); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color: green;color:white;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add <?php echo e($asset); ?> Details</h4>
        </div>
        <form method="POST" name="myform" action="<?php echo e(URL::to('/')); ?>/assetsimcard?asset=<?php echo e($asset); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <table class="table table-responsive table-hover">
                <tbody>
                    <tr>
                        <td ><label>SIMCard Brand/Provider </label></td>
                        <td ><input required type="text" name="sim" id="sim"  placeholder="Provider Name" title="Please enter characters only" class="form-control" pattern="[A-Za-z]+" style="width:60%" /></td>
                    </tr>
                    <tr>
                    	<td><label>SIMCard Number</label></td>
                    	<td><input required type="text" name="number" minlength="10" maxlength="10" id="number" placeholder="+91"  oninput="getnumber()" class="form-control" style="width:60%"></td>
                    </tr>
                    <tr>
                        <td ><label> Remark:</label></td>
                        <td ><textarea required  placeholder="Remark"  required type="type" cols="3" name="sremark"  class="form-control" style="width:60%;resize: none;" /></textarea></td>                
                    </tr>
                   </tbody>
	       </table>
			    <div class="modal-footer">
		          <button type="submit" class="btn btn-success" >Save</button>
		          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        </div>
		    </div>
		</form>
        </div>
      </div>
  	</div>
 </div>
<table class="table table-hover">
<thead>
    
</thead>
<tbody>

</tbody>
</table>
</div>
<script>
    function updateUser(arg)
    {
        var userId = arg;
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/updateUser",
            async:false,
            data:{userId : userId},
            success: function(response)
            {
                alert(response);
            }
        });    
    }
</script>
<script type="text/javascript">
	 function getnumber()
	{
		
		var num=document.myform.number.value;

			if(isNaN(num)){
				document.getElementById('number').value="";
				myform.number.focus();
		     }
	}
</script>