<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
     
      <table class="table">
        <thead>
          <th>Project Name</th>
          <th>Project Id</th>
          <th>Address</th>
          <th>Status</th>
          <th>Procurement Name</th>
          <th>Procurement Contact No.</th>
          <th></th>
          <th>Action</th>
        </thead>
        <tbody>
          <?php $__currentLoopData = $projectlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($project->quality == 'Unverified' || $project->quality == 'Genuine' || $project->quality == 'Fake'): ?>
            <tr>
              <td><?php echo e($project->project_name); ?></td>
              <td>
                <a target="_none" href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($project->project_id); ?>"><?php echo e($project->project_id); ?></a>
              </td>
              <td>
                <a href="https://www.google.com/maps/place/<?php echo e($project->siteaddress != null ? $project->siteaddress->address  : ''); ?>/{{ $project->siteaddress != null ? $project->siteaddress->latitude : '' }},<?php echo e($project->siteaddress != null ? $project->siteaddress->longitude : ''); ?>"><?php echo e($project->siteaddress != null ? $project->siteaddress->address : ''); ?></a>
              </td>
              <td><?php echo e($project->project_status); ?></td>
              <td><?php echo e($project->procurementdetails != null ? $project->procurementdetails->procurement_name : ''); ?></td>
              <td><?php echo e($project->procurementdetails != null ? $project->procurementdetails->procurement_contact_no : ''); ?></td>
              <td><?php echo e($project->room_types); ?></td>
              <td>
              <?php if($pageName == "Update"): ?>
                <a href="<?php echo e(URL::to('/')); ?>/edit?projectId=<?php echo e($project->project_id); ?>" class="btn btn-success input-sm">Edit</a>
              <?php else: ?>
                <a href="<?php echo e(URL::to('/')); ?>/requirements?projectId=<?php echo e($project->project_id); ?>" class="btn btn-primary input-sm">Add Enquiry</a>
              <?php endif; ?>
              </td>
            </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <?php if(isset($_GET['quality'])): ?>
      <?php echo e($projectlist->appends('quality',$_GET['quality'])->links()); ?>

      <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>