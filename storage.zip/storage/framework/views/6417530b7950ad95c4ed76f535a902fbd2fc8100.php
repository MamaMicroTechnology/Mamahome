<?php
  $user = Auth::user()->group_id;
  $ext = ($user == 4? "layouts.amheader":"layouts.app");
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <?php $id = $_GET['projectId']; ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                  <?php if($subwards): ?>
                 
                  <?php else: ?>
                  Update Project
                  <?php endif; ?>
                  <?php if(session('Success')): ?>
                    <p class="alert-success pull-right"><?php echo e(session('Success')); ?></p>
                  <?php endif; ?>
                  <small id="currentTime" class="pull-right">
                    Listed On <?php echo e(date('d-m-Y h:i:s A', strtotime($projectdetails->created_at))); ?>

                  </small><br>
                </div>
                <div class="panel-body">
                    <center>
                      <label id="headingPanel">Project Details</label><br>
                       <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->group_id != 7 && Auth::user()->group_id != 6 && Auth::user()->group_id != 11): ?>
                      <label><?php echo e($username != null ? 'Listed By '.$username : ''); ?></label><br>
                      <?php endif; ?>
                      <?php endif; ?>
                    </center>
                    <?php if($projectdetails->quality == NULL): ?>
                      <form method="POST" action="<?php echo e(URL::to('/')); ?>/markProject">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                      </form>
                      <?php else: ?>
                      <label style="font-size: 14px">Quality:</label>
                      <?php echo e($projectdetails->quality); ?>

                      <?php endif; ?>
                    </center>
                      
                   <form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($projectdetails->project_id); ?>/updateProject" enctype="multipart/form-data">
                    <div id="first">
                    <?php echo e(csrf_field()); ?>

                           <table class="table">
                           <?php if(Auth::user()->group_id != 7 && Auth::user()->group_id != 6): ?>
                            <tr>
                              <td>Update status</td>
                              <td>:</td>
                              <td>
                                <?php if($updater != null): ?>
                                  Last update was on <?php echo e(date('d-m-Y h:i:s A',strtotime($projectdetails->updated_at))); ?> by <?php echo e($updater->name); ?>

                                <?php endif; ?>
                              </td>
                            </tr>
                            <?php endif; ?>
                               <tr>
                                   <td>Project Name</td>
                                   <td>:</td>
                                   <td><input disabled id="pName" value="<?php echo e($projectdetails->project_name); ?>"  type="text" placeholder="Project Name" class="form-control input-sm" name="pName"></td>
                               </tr>
                               <tr>
                                   <td>Location</td>
                                   <td>:</td>
                                   <td id="x">
                                    <div class="col-sm-6">
                                        <label>Longitude:</label>
                                        <input disabled value="<?php echo e($projectdetails->siteaddress->longitude); ?>" placeholder="Longitude" class="form-control input-sm"  type="text" name="longitude" value="" id="longitude">
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Latitude:</label>
                                        <input disabled value="<?php echo e($projectdetails->siteaddress->latitude); ?>" placeholder="Latitude" class="form-control input-sm"  type="text" name="latitude" value="" id="latitude">
                                    </div>
                                   </td>
                               </tr>
                               <tr>
                                   <td>Road Name / Road No.</td>
                                   <td>:</td>
                                   <td><input id="road" value="<?php echo e($projectdetails->road_name); ?>"  type="text" placeholder="Road Name / Road No." class="form-control input-sm" name="rName"></td>
                               </tr>
                               <tr>
                                   <td>Road Width</td>
                                   <td>:</td>
                                   <td><input id="rWidth" value="<?php echo e($projectdetails->road_width); ?>"  type="text" placeholder="Road Width" class="form-control input-sm" name="rWidth"></td>
                               </tr>
                                 <tr>
                                   <td>Full Address</td>
                                   <td>:</td>
                                   <td><input id="road" value="<?php echo e($projectdetails->siteaddress->address); ?>" type="text" placeholder="Full Address" class="form-control input-sm" name="address"></td>
                               </tr>
                               <tr>
                                <?php
                                  $type = explode(", ",$projectdetails->construction_type);
                                ?>
                                 <td>Construction Type</td>
                                 <td>:</td>
                                 <td>
                                    <label required class="checkbox-inline">
                                      <input <?php echo e(in_array('Residential', $type) ? 'checked': ''); ?> id="constructionType1" name="constructionType[]" type="checkbox" value="Residential">Residential
                                    </label>
                                    <label required class="checkbox-inline">
                                      <input <?php echo e(in_array('Commercial', $type) ? 'checked': ''); ?> id="constructionType2" name="constructionType[]" type="checkbox" value="Commercial">Commercial
                                    </label>
                                 </td>
                               </tr>
                               <tr>
                                 <td>Interested In RMC ?</td>
                                 <td>:</td>
                                 <td>
                                     
                                      <label><input id="rmc" <?php echo e($projectdetails->interested_in_rmc == "Yes" ? 'checked' : ''); ?> required value="Yes" type="radio" name="rmcinterest">Yes</label>
                                   <span>&nbsp;&nbsp;&nbsp;  </span>
                                  
                                     <label><input id="rmc2" <?php echo e($projectdetails->interested_in_rmc == "No" ? 'checked' : ''); ?> required value="No" type="radio" name="rmcinterest">No</label> 
                                   <span>&nbsp;&nbsp;&nbsp;  </span>
                                     <label><input id="rmc3" <?php echo e($projectdetails->interested_in_rmc == "None" ? 'checked' : ''); ?> required value="None" type="radio" name="rmcinterest">None</label> 
                                   
                                 </td>
                               </tr>
                               <tr>
                                 <td>Interested In Bank Loans ?</td>
                                 <td>:</td>
                                 <td>
                                    
                                      <label><input id="loan1" <?php echo e($projectdetails->interested_in_loan == "Yes" ? 'checked' : ''); ?> required value="Yes" type="radio" name="loaninterest">Yes</label>
                                    <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="loan2" <?php echo e($projectdetails->interested_in_loan == "No" ? 'checked' : ''); ?> required value="No" type="radio" name="loaninterest">No</label>
                                   <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="loan3" <?php echo e($projectdetails->interested_in_loan == "None" ? 'checked' : ''); ?> required value="None" type="radio" name="loaninterest">None</label>
                                   
                                 </td>
                               </tr>
                               <tr>
                                 <td>Interested In UPVC Doors And Windows ?</td>
                                 <td>:</td>
                                 <td>
                                    
                                      <label><input id="dandw1" <?php echo e($projectdetails->interested_in_doorsandwindows == "Yes" ? 'checked' : ''); ?> required value="Yes" type="radio" name="dandwinterest">Yes</label>
                                   <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="dandw2" <?php echo e($projectdetails->interested_in_doorsandwindows == "No" ? 'checked' : ''); ?> required value="No" type="radio" name="dandwinterest">No</label>
                                   <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="dandw3" <?php echo e($projectdetails->interested_in_doorsandwindows == "None" ? 'checked' : ''); ?> required value="None" type="radio" name="dandwinterest">None</label>
                                 </td>
                               </tr>
                               <tr>
                                 <td>Interested In Home Automation ?</td>
                                 <td>:</td>
                                 <td>
                                    
                                      <label><input id="home1" <?php echo e($projectdetails->automation == "Yes" ? 'checked' : ''); ?> required value="Yes" type="radio" name="automation">Yes</label>
                                    <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="home2" <?php echo e($projectdetails->automation == "No" ? 'checked' : ''); ?> required value="No" type="radio" name="automation">No</label>
                                  <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="home3" <?php echo e($projectdetails->automation == "None" ? 'checked' : ''); ?> required value="None" type="radio" name="automation">None</label>
                                   
                                 </td>
                               </tr>
                               <tr>
                                 <td>Interested In Premium Products ?</td>
                                 <td>:</td>
                                 <td>
                                     
                                      <label><input id="premium1" <?php echo e($projectdetails->interested_in_premium == "Yes" ? 'checked' : ''); ?> required value="Yes" type="radio" name="premium">Yes</label>
                                    <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="premium2" <?php echo e($projectdetails->interested_in_premium == "No" ? 'checked' : ''); ?> required value="No" type="radio" name="premium">No</label>
                                    <span>&nbsp;&nbsp;&nbsp;  </span>
                                      <label><input id="premium3" <?php echo e($projectdetails->interested_in_premium == "None" ? 'checked' : ''); ?> required value="None" type="radio" name="premium">None</label>
                                    
                                 </td>
                               </tr>
                               <tr>
                                 <td>Type Of Contract ? </td>
                                  <td>:</td>
                                  <td>
                                   <select class="form-control" name="contract" id="contract" required>
                                      <option value="" disabled selected>--- Select ---</option>
                                      <option <?php echo e($projectdetails->contract == "Labour Contract" ? 'selected' : ''); ?> value="Labour Contract">Labour Contract</option>
                                      <option <?php echo e($projectdetails->contract == "Material Contract" ? 'selected' : ''); ?> value="Material Contract">Material Contract</option>
                                      <option <?php echo e($projectdetails->contract == "None" ? 'selected' : ''); ?> value="None">None</option>
                                  </select>
                                  </td>
                               </tr>
                               <tr>
                                 <td>Sub Ward</td>
                                 <td>:</td>
                                 <td><?php echo e($projectward); ?></td>
                               </tr>
                               <!-- <tr>
                                   <td>Municipal Approval</td>
                                   <td>:</td>
                                   <td><input type="file" accept="image/*" class="form-control input-sm" name="mApprove"></td>
                               </tr> -->
                               <tr>
                                   <td>Govt. Approvals<br>(Municipal, BBMP, etc)</td>
                                   <td>:</td>
                                   <td>
                                    <input oninput="fileUpload()" id="oApprove" multiple type="file" accept="image/*" class="form-control input-sm" name="oApprove[]">
                                  </td>
                               </tr>
                               <tr>
                                <?php
                                  $statuses = explode(", ", $projectdetails->project_status);
                                ?>
                                   <td>Project Status</td>
                                   <td>:</td>
                                   <td>
                                          <div class="col-md-3" >
                                            <label class="checkbox-inline">
                                              <input <?php echo e(in_array('Planning', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Planning" style="width: 33px;" ><span>&nbsp;&nbsp;&nbsp;</span>Planning
                                            </label>
                                          
                                             <label class="checkbox-inline">
                                              <input <?php echo e(in_array('Digging', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Digging">Digging
                                            </label>
                                         
                                             <label class="checkbox-inline">
                                              <input <?php echo e(in_array('Foundation', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Foundation">Foundation
                                            </label>
                                         
                                             <label class="checkbox-inline">
                                              <input <?php echo e(in_array('Pillars', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Pillars">Pillars
                                            </label>
                                          
                                             <label class="checkbox-inline">
                                              <input <?php echo e(in_array('Walls', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Walls">Walls
                                            </label>
                                          </div>
                                       <div class="col-md-3">
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Roofing', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Roofing" style="width: 33px;"><span>&nbsp;&nbsp;&nbsp;</span>Roofing
                                        </label>
                                       
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Electrical', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Electrical">Electrical
                                        </label>
                                      
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Plumbing', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Plumbing">Plumbing
                                        </label>
                                      
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Plastering', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Plastering">Plastering
                                        </label>
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Flooring', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Flooring">Flooring
                                        </label>
                                      </div>

                                        <div class="col-md-3">
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Carpentry', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Carpentry" style="width: 33px;"><span>&nbsp;&nbsp;&nbsp;</span>Carpentry
                                        </label>
                                       
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Paintings', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Paintings">Paintings
                                        </label>
                                       
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Fixtures', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Fixtures">Fixtures
                                        </label>
                                        
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Completion', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Completion">Completion
                                        </label>
                                        
                                          <label class="checkbox-inline">
                                          <input <?php echo e(in_array('Closed', $statuses) ? 'checked': ''); ?> type="checkbox" onchange="count()" name="status[]" value="Closed">Closed
                                        </label>
                                       </div>
                                   </td>
                               </tr>

                               <tr>
                                   <td>Project Type</td>
                                   <td>:</td>
                                   <td>
                                    <div class="row">
                                        <div class="col-md-3">
                                          <label>Basement</label>
                                          <input value="<?php echo e($projectdetails->basement); ?>" onkeyup="check('basement')" id="basement" name="basement" type="number" autocomplete="off" class="form-control input-sm" placeholder="Basement">
                                        </div>
                                        <div class="col-md-2">
                                          <br>
                                          <b style="font-size: 20px; text-align: center">+</b>
                                        </div>
                                      <div class="col-md-3">
                                        <label>Floor</label>
                                        <input value="<?php echo e($projectdetails->ground); ?>" oninput="check('ground')" autocomplete="off" name="ground" id="ground" type="number" class="form-control input-sm" placeholder="Floor">
                                      </div>
                                      <div class="col-md-3">
                                        <br>
                                        <p id="total">
                                          B(<?php echo e($projectdetails->basement); ?>) + G + <?php echo e($projectdetails->ground); ?> = <?php echo e($projectdetails->basement + $projectdetails->ground + 1); ?>

                                        </p>
                                      </div>
                                    </div>
                                    </td>
                               </tr>
                                <tr>
                                   <td>Plot Size</td>
                                   <td>:</td>
                                   <td>
                                    <div class="row">
                                        <div class="col-md-3">
                                          <label>Length</label>
                                          <input value="<?php echo e($projectdetails->length); ?>" onkeyup="checkthis('length')" id="length" name="length" type="text" autocomplete="off" class="form-control input-sm" placeholder="Length">
                              
                                        </div>
                                        <div class="col-md-2">
                                          <b style="font-size: 20px; text-align: center">*</b>
                                        </div>
                                      <div class="col-md-3">
                                         <label>Breadth</label>
                                        <input value="<?php echo e($projectdetails->breadth); ?>" onkeyup="checkthis('breadth');" autocomplete="off" name="breadth" id="breadth" type="text" class="form-control" placeholder="Breadth">
                                      </div>
                                      <div class="col-md-3">
                                        <p id="totalsize">
                                          L(<?php echo e($projectdetails->length); ?>) * B(<?php echo e($projectdetails->breadth); ?>) = <?php echo e($projectdetails->length * $projectdetails->breadth); ?>

                                        </p>
                                      </div>
                                    </div>
                                    </td>
                               </tr>
                               <tr>
                                   <td>Project Size</td>
                                   <td>:</td>
                                   <td><input id="pSize" value="<?php echo e($projectdetails->project_size); ?>"  placeholder="Project Size" type="text" onkeyup="check('pSize')" class="form-control input-sm" name="pSize"></td>
                               </tr>
                                <tr>
                               
                                 <td>Budget Type</td>
                                 <td>:</td>
                                 <td>
                                    <label required class="checkbox-inline">
                                      <input <?php echo e($projectdetails->budgetType =="Structural" ? 'checked': ''); ?>  id="constructionType3" name="budgetType" type="radio" value="Structural">Structural Budget
                                    </label>
                                    <label required class="checkbox-inline">
                                      <input <?php echo e($projectdetails->budgetType == "Finishing" ? 'checked': ''); ?>  id="constructionType4" name="budgetType" type="radio" value="Finishing">Finishing Budget
                                    </label>
                                 </td>
                               </tr>
                               <tr>
                                   <td>Total Budget (In Cr.)</td>
                                   <td>:</td>
                                   <td>
                                    <div class="col-md-4">
                                      <input id="budget" value="<?php echo e($projectdetails->budget); ?>"  placeholder="Budget In Crores" type="text" class="form-control input-sm" onkeyup="check('budget')" name="budget">
                                    </div>
                                    <div class="col-md-8">
                                      Budget (per sq.ft) :
                                      <?php if($projectdetails->project_size != 0): ?>
                                       <?php echo e(round((10000000 * $projectdetails->budget)/$projectdetails->project_size,3)); ?>

                                      <?php endif; ?>
                                    </div>
                                  </td>
                               </tr>
                              <tr>
                                   <td>Project Image</td>
                                   <td>:</td>
                                    <td> <input id="img" type="file" accept="image/*" class="form-control input-sm" name="pImage[]" multiple><br>
                                       
                                          <?php if($projectdetails->updated_by == Null || $projectdetails->updated_by != Null): ?>
                                          <?php
                                               $images = explode(",", $projectdetails->image);
                                               ?>
                                             
                                             <div class="row">

                                                 <?php for($i = 0; $i < count($images); $i++): ?>
                                                     <div class="col-md-3">
                                                          <img height="350" width="350" id="project_img" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($images[$i]); ?>" class="img img-thumbnail">
                                                     </div>
                                                 <?php endfor; ?>
                                              </div>
                                            <?php endif; ?>
                                            <br>
                                             <?php $__currentLoopData = $projectimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php if($projectimage->project_id != Null ): ?>
                                            
                                                  <?php
                                                     $images = explode(",", $projectimage->image);
                                                    ?>
                                                     Project Status : <?php echo e($projectimage->project_status); ?>

                                                   <div class="row">
                                                       <?php for($i = 0; $i < count($images); $i++): ?>
                                                           <div class="col-md-3">
                                                                <img height="350" width="350" id="project_img" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($images[$i]); ?>" class="img img-thumbnail">
                                                           </div>
                                                       <?php endfor; ?>
                                                    </div>
              
                                                <?php endif; ?>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </td>
                               </tr>
                               <tr>
                                 <td>Updated On</td>
                                 <td>:</td>
                                 <td><?php echo e(date('d-m-Y h:i:s A', strtotime($projectdetails->created_at))); ?></td>
                               </tr>
                               <tr>
                                    <td>Room Types</td>
                                    <td>:</td>
                                    <td>
                                        <table id="bhk" class="table table-responsive">
                                            <tr>
                                              <td>
                                                <select id="floorNo" name="floorNo[]" class="form-control">
                                                  <option value="">--Floor--</option>
                                                  <?php for($i = $projectdetails->basement; $i>0; $i--): ?>
                                                    <option value="<?php echo e($i); ?>">Base <?php echo e($i); ?></option>
                                                  <?php endfor; ?>
                                                    <option value="Ground">Ground</option>
                                                   <?php for($i = 1;$i<=$projectdetails->ground;$i++): ?>
                                                    <option value="<?php echo e($i); ?>">Floor <?php echo e($i); ?></option>
                                                  <?php endfor; ?>
                                                </select>
                                              </td>
                                                <td>
                                                    <?php if($projectdetails->construction_type == "Commercial"): ?>
                                                    <input type="text" name="roomType[]" readonly value="Commercial Floor">
                                                    <?php elseif($projectdetails->construction_type == "Residential"): ?>
                                                    <select name="roomType[]" id="" class="form-control">
                                                        <option value="1RK">1RK</option>
                                                        <option value="1BHK">1BHK</option>
                                                        <option value="2BHK">2BHK</option>
                                                        <option value="3BHK">3BHK</option>
                                                    </select>
                                                    <?php else: ?>
                                                    <select name="roomType[]" id="" class="form-control">
                                                        <option value="">--Select--</option>
                                                        <option value="Commercial Floor">Commercial Floor</option>
                                                        <option value="1RK">1RK</option>
                                                        <option value="1BHK">1BHK</option>
                                                        <option value="2BHK">2BHK</option>
                                                        <option value="3BHK">3BHK</option>
                                                    </select>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="number[]" class="form-control" placeholder="<?php echo e($projectdetails->construction_type == 'Commercial'? "Floor Size" : "No. of House"); ?>" >
                                                </td>
                                                </tr>
                                            <tr>
                                                <td colspan=3>
                                                    <button onclick="addRow();" type="button" class="btn btn-primary form-control">Add more</button>
                                                </td>
                                            </tr>
                                            <?php $__currentLoopData = $roomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                              <td><?php echo e($roomtype->floor_no); ?></td>
                                              <td><?php echo e($roomtype->room_type); ?></td>
                                              <td><?php echo e($roomtype->no_of_rooms); ?></td>
                                              
                                              <td>
                                                <button type="button" data-toggle="modal" data-target="#delete<?php echo e($roomtype->id); ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></button><br><br>
                                          
                                                <!-- Modal -->
                                                <div id="delete<?php echo e($roomtype->id); ?>" class="modal fade" role="dialog">
                                                  <div class="modal-dialog modal-sm">

                                                    <!-- Modal content-->
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">Confirm delete</h4>
                                                      </div>
                                                      <div class="modal-body">
                                                        <p>Are you sure you want to delete?</p>
                                                      </div>
                                                      <div class="modal-footer">
                                                        <a class="pull-left btn btn-danger" href="<?php echo e(URL::to('/')); ?>/deleteRoomType?roomId=<?php echo e($roomtype->id); ?>">Yes</a>
                                                        <button type="button" class="btn btn-default pull-right" data-dismiss="modal">No</button>
                                                      </div>
                                                    </div>

                                                  </div>
                                                </div>
                                              </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </td>
                               </tr>
                           </table>
                       </div>
                      

<button type="button" style="width: 100%;font-size: 20px;" class="btn btn-sm">Customer Details</button>
<div class="tab" style="overflow: hidden;
    border: 1px solid #ccc;
    background-color: #5b6d5c;
   ">
  <button type="button" style="background-color: inherit;
    
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px 16px;
    transition: 0.3s;
    font-size: 17px;
     color:white;"  class="tablinks" onclick="openCity(event, 'owner')">Owner Details</button><br>
  <button type="button" style="background-color: inherit;
    
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px 16px;
    transition: 0.3s;
    font-size: 17px;
     color:white;" class="tablinks" onclick="openCity(event, 'contractor')">Contractor Details </button><br>
  <button type="button" style="background-color: inherit;
    
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px 16px;
    transition: 0.3s;
    font-size: 17px;
     color:white;" class="tablinks" onclick="openCity(event, 'consultant')">Consultant Details</button><br>
  <button type="button" style="background-color: inherit;
    
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px 16px;
    transition: 0.3s;
    font-size: 17px;
     color:white;" class="tablinks" onclick="openCity(event, 'site')">Site Engineer Details</button><br>
  <button type="button" style="background-color: inherit;
    
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px 16px;
    transition: 0.3s;
    font-size: 17px;
     color:white;" class="tablinks" onclick="openCity(event, 'procurement')">Procurement Details</button>
</div>

<div id="owner" class="tabcontent" style="display: none;padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;">
    <br>
  <center><label>Owner Details</label></center>
  <br>
                           <table class="table">
                               <tr>
                                   <td>Owner Name</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->ownerdetails != null ? $projectdetails->ownerdetails->owner_name : ''); ?>" type="text" placeholder="Owner Name" class="form-control input-sm" id="oName" name="oName"></td>
                               </tr>
                               <tr>
                                   <td>Owner Email</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->ownerdetails != null ? $projectdetails->ownerdetails->owner_email : ''); ?>" placeholder="Owner Email" type="email" class="form-control input-sm" onblur="checkmail('oEmail')" id="oEmail" name="oEmail"></td>
                               </tr>
                               <tr>
                                   <td>Owner Contact No.</td>
                                   <td>: <p class="pull-right">+91</p></td>
                                   <td><input value="<?php echo e($projectdetails->ownerdetails != null ? $projectdetails->ownerdetails->owner_contact_no : ''); ?>" onkeyup="check('oContact')" placeholder="Owner Contact No." type="text" class="form-control input-sm" maxlength="10" minlength="10" name="oContact" id="oContact"></td>
                               </tr>
                           </table>
</div>
<div id="contractor" class="tabcontent" style="display: none;padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;"><br>
   <center><label>Contractor Details</label></center>
   <br>
                           <table class="table">
                               <tr>
                                   <td>Contractor Name</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->contractordetails->contractor_name); ?>" id="cName" type="text" placeholder="Contractor Name" class="form-control input-sm" name="cName"></td>
                               </tr>
                               <tr>
                                   <td>Contractor Email</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->contractordetails->contractor_email); ?>" placeholder="Contractor Email" type="email" onblur="checkmail('cEmail')" class="form-control input-sm" name="cEmail" id="cEmail"></td>
                               </tr>
                               <tr>
                                   <td>Contractor Contact No.</td>
                                   <td>: <p class="pull-right">+91</p></td>
                                   <td><input value="<?php echo e($projectdetails->contractordetails->contractor_contact_no); ?>" placeholder="Contractor Contact No." onkeyup="check('cContact')" maxlength="10" minlength="10" type="text" class="form-control input-sm" id="cContact" name="cContact"></td>
                               </tr>
                           </table>
</div>
<div id="consultant" class="tabcontent" style="display: none;padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;"><br>
  <center><label>Consultant Details</label></center><br>
                          <table class="table">
                               <tr>
                                   <td>Consultant Name</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->consultantdetails->consultant_name); ?>" type="text" placeholder="Consultant Name" class="form-control input-sm" id="coName" name="coName"></td>
                               </tr>
                               <tr>
                                   <td>Consultant Email</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->consultantdetails->consultant_email); ?>" placeholder="Consultant Email" onblur="checkmail('coEmail')" type="email" class="form-control input-sm" id="coEmail" name="coEmail"></td>
                               </tr>
                               <tr>
                                   <td>Consultant Contact No.</td>
                                   <td>: <p class="pull-right">+91</p></td>
                                   <td><input value="<?php echo e($projectdetails->consultantdetails->consultant_contact_no); ?>" placeholder="Consultant Contact No." maxlength="10" minlength="10" onkeyup="check('coContact')" type="text" class="form-control input-sm" id="coContact" name="coContact"></td>
                               </tr>
                           </table>

</div>
<div id="site" class="tabcontent" style="display: none;padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;"><br>
   <center><label>Site Engineer Details</label></center><br>
                           <table class="table">
                               <tr>
                                   <td>Site Engineer Name</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->siteengineerdetails != null ? $projectdetails->siteengineerdetails->site_engineer_name:''); ?>" type="text" placeholder="Site Engineer Name" class="form-control input-sm" id="eName" name="eName"></td>
                               </tr>
                               <tr>
                                   <td>Site Engineer Email</td>
                                   <td>:</td>
                                   <td><input value="<?php echo e($projectdetails->siteengineerdetails != null ? $projectdetails->siteengineerdetails->site_engineer_email : ''); ?>" placeholder="Site Engineer Email" type="email" onblur="checkmail('eEmail')" class="form-control input-sm" id="eEmail" name="eEmail"></td>
                               </tr>
                               <tr>
                                   <td>Site Engineer Contact No.</td>
                                   <td>: <p class="pull-right">+91</p></td>
                                   <td><input value="<?php echo e($projectdetails->siteengineerdetails != null ? $projectdetails->siteengineerdetails->site_engineer_contact_no : ''); ?>" placeholder="Site Engineer Contact No." type="text" maxlength="10" onkeyup="check('eContact')" minlength="10" class="form-control input-sm" name="eContact" id="eContact"></td>
                               </tr>
                           </table>
</div>
<div id="procurement" class="tabcontent" style="display: none;padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;"><br>
   <center><label>Procurement Details</label></center><br>
                          <table class="table">
                               <tr>
                                   <td>Procurement Name</td>
                                   <td>:</td>
                                   <td><input id="prName" value="<?php echo e($projectdetails->procurementdetails->procurement_name); ?>"  type="text" placeholder="Procurement Name" class="form-control input-sm" id="pName" name="pName"></td>
                               </tr>
                               <tr>
                                   <td>Procurement Email</td>
                                   <td>:</td>
                                   <td><input id="pEmail" value="<?php echo e($projectdetails->procurementdetails->procurement_email); ?>" placeholder="Procurement Email" type="email" class="form-control input-sm" id="pEmail" name="pEmail"></td>
                               </tr>
                               <tr>
                                   <td>Procurement Contact No.</td>
                                   <td>: <p class="pull-right">+91</p></td>
                                   <td><input id="prPhone" value="<?php echo e($projectdetails->procurementdetails->procurement_contact_no); ?>"  placeholder="Procurement Contact No." maxlength="10" minlength="10" type="text" class="form-control input-sm" name="pContact" id="pContact"></td>
                               </tr>
                           </table>
                      </div>

                      <table class="table">
                        <tr>
                            <td><b>Quality</b></td>
                            <td>:</td>
                            <td>
                                <select id="quality" onchange="fake()" class="form-control" name="quality">
                                    <option value="null" disabled selected>--- Select ---</option>
                                    <option <?php echo e($projectdetails->quality == "Genuine" ? 'selected':''); ?> value="Genuine">Genuine</option>
                                    <option <?php echo e($projectdetails->quality == "Fake" ? 'selected':''); ?> value="Fake">Fake</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><b>Remarks</b></td>
                            <td>:</td>
                            <td>
                         <textarea style="resize: none;" class="form-control" placeholder="Remarks (Optional)" name="remarks"><?php echo e($projectdetails->remarks); ?></textarea>
                          </td>
                        </tr>
                        </table>
                            <button type="submit" id="sub" onclick="pageNext()" class="form-control btn btn-primary">Submit Data</button>
                   </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "None";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}  
</script>  
<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
<!--This line by Siddharth -->
<script type="text/javascript">
  function fake(){
    $check = document.getElementById('quality').value;
    if($check == "Fake"){
      document.getElementById('contract').innerHTML = "<option value='None'>Fake</option>";
    }
  }
  function checklength(arg){
    var a = document.getElementById(arg).value;
    if(a.length !== 10){
      alert("Please Enter 10 digits !!!!");
    }
    return false;
  }

  function checkmail(arg){
    var mail = document.getElementById(arg);
    
    if(mail.value.length > 0 ){
      if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail.value))  {  
        return true;  
      }  
      else{
        alert("Invalid Email Address!");  
        mail.value = '';
       
      }
      return false;
    }
     
  }

function check(arg){
    var input = document.getElementById(arg).value;
    if(isNaN(input)){
      while(isNaN(document.getElementById(arg).value)){
      var str = document.getElementById(arg).value;
      str     = str.substring(0, str.length - 1);
      document.getElementById(arg).value = str;
      }
    }
    else{
      input = input.trim();
      document.getElementById(arg).value = input;
    }
    //For ground and basement generation
    if(arg == 'ground' || arg == 'basement'){
      var basement = parseInt(document.getElementById("basement").value);
      var ground   = parseInt(document.getElementById("ground").value);
      var opts = "<option value=''>--Floor--</option>";
      if(!isNaN(basement) && !isNaN(ground)){
        var floor    = 'B('+basement+')' + ' + G + ('+ground+') = ';
        sum          = basement+ground+1;
        floor       += sum;
      
        if(document.getElementById("total").innerHTML != null)
        {
          document.getElementById("total").innerHTML = floor;
          for(var i = 1; i<=sum; i++){
            opts += "<option value='"+i+"'>Floor "+i+"</option>";
          }
          document.getElementById("floorNo").innerHTML = opts;
        }
        else
          document.getElementById("total").innerHTML = '';
      }
    }

    return false;
  }
 
</script>
<!--This line by Siddharth -->

<script type="text/javascript">
  $(document).ready(function(){
      count();
  });
  $(function(){
  $('#img').change(function(){
    var input = this;
    var url = $(this).val();
    var ext = url.substring(url.lastIndexOf('.') + 1).toLowerCase();
    if (input.files && input.files[0]&& (ext == "gif" || ext == "png" || ext == "jpeg" || ext == "jpg")) 
     {
        var reader = new FileReader();

        reader.onload = function (e) {
           $('#project_img').attr('src', e.target.result);
        }
       reader.readAsDataURL(input.files[0]);
    }
    else
    {
      $('#project_img').attr('src', '/assets/no_preview.png');
    }
  });

});
</script>

<script>
var x = document.getElementById("demo");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
        document.getElementById("getBtn").className = "hidden";
    } else {
        document.getElementById("x").innerHTML = "Please try it later.";
    }
}
function showPosition(position) { 
    document.getElementById("longitude").value = position.coords.longitude;
    document.getElementById("latitude").value = position.coords.latitude;
}
var basement;
var ground;
function sum(){
    basement = parseInt(document.getElementById("basement").value);
    ground = parseInt(document.getElementById("ground").value);
    var floor = basement + ground;
    if(document.getElementById("basement").value != "" && document.getElementById("ground").value != "" && document.getElementById("basement").value != NaN && document.getElementById("ground").value != NaN){
      document.getElementById("total").innerHTML = floor;
    }else{
      document.getElementById("total").innerHTML = "";
    }
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU"></script>

<script type="text/javascript">
    var current = "first";
    var countinput=0;
    document.getElementById('headingPanel').innerHTML = 'Project Details';
    function pageNext(){
        var ctype1 = document.getElementById('constructionType1');
        var ctype2 = document.getElementById('constructionType2');
        var rmc = document.getElementById('rmc');
        var rmc2= document.getElementById('rmc2');
        var rmc3= document.getElementById('rmc3');
        if(current == 'first')
        { 
          if(document.getElementById("pName").value == ""){
            window.alert("You have not entered Project Name");
          }else if(document.getElementById("longitude").value == ""){
            window.alert("Please click on Get Location button");
          }else if(document.getElementById("latitude").value == ""){
            window.alert("Kindly click on Get location button");
          }else if(document.getElementById("road").value == ""){
            window.alert("You have not entered Road Name");
          } else if(document.getElementById('rWidth').value == ""){
            window.alert("You have not entered  Width");
          }else if(ctype1.checked == false && ctype2.checked == false){
            window.alert("Please choose the construction type");
          }else if(rmc.checked == false && rmc2.checked == false && rmc3.checked == false){
            window.alert("Please tell us whether the customer is interested in RMC or not");
          }else if(loan1.checked == false && loan2.checked == false && loan3.checked == false ){
            window.alert("Please tell us whether the customer is interested in taking loan or not");
          }else if(dandw1.checked == false && dandw2.checked == false && dandw3.checked == false ){
            window.alert("Please tell us whether the customer is interested in purchasing UPVC doors and windows");
          }else if(home1.checked == false && home2.checked == false && home3.checked == false ){
            window.alert("Please tell us whether the customer is interested in Home Automation");
          }else if(premium1.checked == false && premium2.checked == false && premium3.checked == false ){
            window.alert("Please tell us whether the customer is interested in premium product");
          }else if(document.getElementById("contract").value == ""){
            alert("Please select contract type");
          }else if(ctype1.checked == true && ctype2.checked == true){
                countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 2;
          }else if(ctype1.checked == true || ctype2.checked == true){
              countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 1;
          }else {
              countinput = document.querySelectorAll('input[type="checkbox"]:checked').length;
          }

          if(countinput == 0){
              window.alert("Select at least one project status");
          } else if(document.getElementById("basement").value == ""){
            window.alert("You have not entered Basement value");
          } else if(document.getElementById("ground").value == ""){
            window.alert("You have not entered Floor value");
          }
          else if(document.getElementById("length").value == ""){
            window.alert("You have not entered length value");
          }else if(document.getElementById("breadth").value == ""){
            window.alert("You have not entered breadth value");
          }else if(document.getElementById("pSize").value == ""){
            window.alert("You have not entered Project Size");
          }
          else if(constructionType3.checked == false && constructionType4.checked == false){
            window.alert("Please choose the Budget type");
          }else if(document.getElementById("budget").value == ""){
            window.alert("You have not entered Budget");
          }else if(document.getElementById('prName').value == ''){
                    alert('Please Enter a Procurement Name');
                    document.getElementById('prName').focus();
          }else if(document.getElementById('prPhone').value== ''){
                    alert('Please Enter Phone Number');
                    document.getElementById('prPhone').focus();
          }
          else{
                         document.getElementById("sub").submit();
           }
        }
    }
</script>

<script type="text/javascript">
 function checkmail(arg){
    var mail = document.getElementById(arg);
    if(mail.value.length > 0 ){
      if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail.value))  {  
        return true;  
      }  
      else{
        alert("Invalid Email Address!");  
        mail.value = ''; 
        mail.focus(); 
      }
    }
     return false;
  }

  function check(arg){
    var input = document.getElementById(arg).value;
    if(isNaN(input)){
      while(isNaN(document.getElementById(arg).value)){
      var str = document.getElementById(arg).value;
      str     = str.substring(0, str.length - 1);
      document.getElementById(arg).value = str;
      }
    }
    else{
      input = input.trim();
      document.getElementById(arg).value = input;
    }
    //For ground and basement generation
    if(arg == 'ground' || arg == 'basement'){
      var basement = parseInt(document.getElementById("basement").value);
      var ground   = parseInt(document.getElementById("ground").value);
      var opts = "<option value=''>--Floor--</option>";
      if(!isNaN(basement) && !isNaN(ground)){
        var floor    = 'B('+basement+')' + ' + G + ('+ground+') = ';
        sum          = basement+ground+1;
         fsum          = ground+1;
        var base         = basement;
        floor       += sum;
        
        if(document.getElementById("total").innerHTML != null)
        {
          document.getElementById("total").innerHTML = floor;
          var ctype1 = document.getElementById('constructionType1');
          var ctype2 = document.getElementById('constructionType2');
          if(ctype1.checked == true && ctype2.checked == true){
            // both residential and commercial
            var sel = "<td><select class=\"form-control\" name=\"floorNo[]\" id=\"floorNo\">"+
                      "</select></td>"+
                      "<td><select name=\"roomType[]\" value='Commercial Floor' id=\"\" class=\"form-control\">"+
                      "<option value='Commercial Floor'>Commercial Floor</option>"+
                      "<option value='1RK'>1RK</option>"+
                      "<option value='1BHK'>1BHK</option>"+
                      "<option value='2BHK'>2BHK</option>"+
                      "<option value='3BHK'>3BHK</option></select>"+
                      "</td><td>"+
                      "<input type=\"text\" name=\"number[]\" class=\"form-control\" placeholder=\"Floor Size / No. of Houses / No. Of Flats\"></td>";
            document.getElementById('selection').innerHTML = sel;
          }else if(ctype1.checked == true && ctype2.checked == false){
            // residential only
            var sel = "<td><select class=\"form-control\" name=\"floorNo[]\" id=\"floorNo\">"+
                      "</select></td>"+
                      "<td><select name=\"roomType[]\" value='Commercial Floor' id=\"\" class=\"form-control\">"+
                      "<option value='1RK'>1RK</option>"+
                      "<option value='1BHK'>1BHK</option>"+
                      "<option value='2BHK'>2BHK</option>"+
                      "<option value='3BHK'>3BHK</option></select>"+
                      "</td><td>"+
                      "<input type=\"text\" name=\"number[]\" class=\"form-control\" placeholder=\"No. of Houses\"></td>";
            document.getElementById('selection').innerHTML = sel;
          }else if(ctype1.checked == false && ctype2.checked == true){
            // commercial only
            var sel = "<td><select class=\"form-control\" name=\"floorNo[]\" id=\"floorNo\">"+
                      "</select></td>"+
                      "<td><input name=\"roomType[]\" readonly value='Commercial Floor' id=\"\" class=\"form-control\">"+
                      "</td><td>"+
                      "<input type=\"text\" name=\"number[]\" class=\"form-control\" placeholder=\"Floor Size\"></td>";
            document.getElementById('selection').innerHTML = sel;
          }
           for(var i = base; i>0; i--){
            opts += "<option value='"+i+"'>Base "+i+"</option>";
          }
          opts += "<option value='Ground'>Ground</option>";
          for(var i = 1; i<fsum; i++){
            opts += "<option value='"+i+"'>Floor "+i+"</option>";
          }
          document.getElementById("floorNo").innerHTML = opts;
        }
        else
          document.getElementById("total").innerHTML = '';
      }
    }

    return false;
  }
  function addRow() {
        var table = document.getElementById("bhk");
        var row = table.insertRow(0);
        var cell3 = row.insertCell(0);
        var cell1 = row.insertCell(1);
        var cell2 = row.insertCell(2);
        var ctype1 = document.getElementById('constructionType1');
        var ctype2 = document.getElementById('constructionType2');
        var existing = document.getElementById('floorNo').innerHTML;
        if(ctype1.checked == true && ctype2.checked == false){
          cell3.innerHTML = "<select name='floorNo[]' class='form-control'>"+existing+"</select>";
          cell1.innerHTML = " <select name=\"roomType[]\" class=\"form-control\">"+
                                                          "<option value=\"1RK\">1RK</option>"+
                                                          "<option value=\"1BHK\">1BHK</option>"+
                                                          "<option value=\"2BHK\">2BHK</option>"+
                                                          "<option value=\"3BHK\">3BHK</option>"+
                                                      "</select>";
          cell2.innerHTML = "<input name=\"number[]\" type=\"text\" class=\"form-control\" placeholder=\"No. of houses\">";
        }
        if(ctype1.checked == false && ctype2.checked == true){
          cell3.innerHTML = "<select name='floorNo[]' class='form-control'>"+existing+"</select>";
          cell1.innerHTML = "<input name=\"roomType[]\" value='Commercial Floor' id=\"\" class=\"form-control\">";
          cell2.innerHTML = "<input type=\"text\" name=\"number[]\" class=\"form-control\" placeholder=\"Floor Size\"></td>";
        }
        if(ctype1.checked == true && ctype2.checked == true){
          // both residential and commercial
          cell3.innerHTML = "<select name='floorNo[]' class='form-control'>"+existing+"</select>";
          cell1.innerHTML = " <select name=\"roomType[]\" class=\"form-control\">"+
                                                          "<option value=\"Commercial Floor\">Commercial Floor</option>"+
                                                          "<option value=\"1RK\">1RK</option>"+
                                                          "<option value=\"1BHK\">1BHK</option>"+
                                                          "<option value=\"2BHK\">2BHK</option>"+
                                                          "<option value=\"3BHK\">3BHK</option>"+
                                                      "</select>";
          cell2.innerHTML = "<input name=\"number[]\" type=\"text\" class=\"form-control\" placeholder=\"No. of houses\">";
        }
    }
    function count(){
      var ctype1 = document.getElementById('constructionType1');
      var ctype2 = document.getElementById('constructionType2');
      var ctype3 = document.getElementById('constructionType3');
      var ctype4 = document.getElementById('constructionType4');
      var countinput;
      if(ctype1.checked == true && ctype2.checked == true && ctype3.checked == false && ctype4.checked == false){
        //   both construction type
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 2;
      }else if(ctype1.checked == true && ctype2.checked == true && ctype3.checked == true && ctype4.checked == true){
        //   all construction type and budget type
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 4;
      }else if(ctype1.checked == true && ctype2.checked == true && (ctype3.checked == true || ctype4.checked == true)){
        //   both construction type and either budget type
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 3;
      }else if((ctype1.checked == true || ctype2.checked == true) && (ctype3.checked == true || ctype4.checked == true)){
        //   
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 2;
      }else if(ctype1.checked == true || ctype2.checked == true){
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length - 1;
      }else{
        countinput = document.querySelectorAll('input[type="checkbox"]:checked').length;
      }
      if(countinput >= 5){
        $('input[type="checkbox"]:not(:checked)').attr('disabled',true);
        $('#constructionType1').attr('disabled',false);
        $('#constructionType2').attr('disabled',false);
        $('#constructionType3').attr('disabled',false);
        $('#constructionType4').attr('disabled',false);
      }else if(countinput == 0){
          return "none";
      }else{
        $('input[type="checkbox"]:not(:checked)').attr('disabled',false);
      }
    }
    function fileUpload(){
      var count = document.getElementById('oApprove').files.length;
      if(count > 5){
        document.getElementById('oApprove').value="";
        alert('You are allowed to upload a maximum of 5 files');
      }
    }
</script>
<script type="text/javascript">
  function checkthis(arg)
  {
    
    
    var x = document.getElementById(arg);
    if(arg == 'length' || arg == 'breadth'){
     
      var breadth = parseInt(document.getElementById("breadth").value);
      var length   = parseInt(document.getElementById("length").value);
      if(!isNaN(breadth) && !isNaN(length)){
        
        var Size    = 'L('+length+')' + '*' + 'B('+breadth+') = ';
        sum          = length*breadth;
        Size    += sum;
        if(document.getElementById("totalsize").innerHTML != null)
          document.getElementById("totalsize").innerHTML = Size;
        else
          document.getElementById("totalsize").innerHTML = '';
      }
    }
    return false;
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>