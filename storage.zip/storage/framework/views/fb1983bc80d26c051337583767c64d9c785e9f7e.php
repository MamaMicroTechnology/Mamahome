<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="col-md-12">
        <div class="panel panel-default" style="border-color:#337ab7">
            <div class="panel-heading text-center" style="background-color:#337ab7">
                <b style="color:white">Sales Mini Report (30 Days)
               </b>
            </div>
            <div class="panel-body">
             <form action="<?php echo e(URL::to('/')); ?>/monthlyreport" method="GET" enctype="multipart/form-data"> 
                    <?php echo e(csrf_field()); ?>

                    <div class="col-md-2">
                   <h4><b>Select Employees</b></h4>
                    <select class="form-control" name="user_id" required>
                      <option value="">--Employees--</option>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                <div class="col-md-2">
                 <h4><b>Select From Date</b></h4>
                    <input class="form-control" value="<?php echo e(isset($_GET['fromdate']) ? $_GET['fromdate'] : ''); ?>" type="date" name="fromdate"  style="width:100%;" required>
                </div>
                   

               <div class="col-md-2">
                   <h4><b>Select To Date</b></h4>
                   <input class="form-control" value="<?php echo e(isset($_GET['todate']) ? $_GET['todate'] : ''); ?>" type="date" name="todate" style="width:100%;" required>
                     
                   </textarea>
                 </div> 
  
                  <div class="col-md-2">
                   
                    <button type="submit"  class="form-control btn btn-primary" value="submi" style="margin-top:40px;">Fetch Report</button> 
                 </div> 

            </div>
            </form>
            
<table  class="table" border="1">
                <thead>
                    <tr>
                        
                        <th>Employee Name</th>
                        <th>Date of Joining</th>
                        <th>Added Projects</th>
                        <th>Added manufactures</th>
                        <th>Updated Projects</th>
                        <th>Enquiries</th> 
                        <th>Confirm  Enquiries</th>
                        <th>Converted  Enquiries</th>
                        <th>Confirm Orders</th>
                        <th>No Of Calls</th>

                    </tr>
                </thead>
          <?php $i=1; ?>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                   <td><?php echo e($user->name); ?></td>
                   <td><?php echo e($user->created_at->format('d-m-y')); ?></td>
                   <td><?php echo e($total[$user->id]['addproject']); ?></td>
                   <td><?php echo e($total[$user->id]['addmanu']); ?></td>
                   <td><?php echo e($total[$user->id]['updateproject']); ?></td>
                   <td><?php echo e($total[$user->id]['addenquiry']); ?></td>
                   <td><?php echo e($total[$user->id]['confirm']); ?></td>
                   <td><?php echo e($total[$user->id]['converted']); ?></td>
                   <td><?php echo e($total[$user->id]['order']); ?></td>
                   <td><?php echo e($total[$user->id]['calls']); ?></td>
                   </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   </table>

        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>