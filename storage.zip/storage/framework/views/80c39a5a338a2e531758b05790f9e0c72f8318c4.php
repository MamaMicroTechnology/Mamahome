<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
               <b style="color:white">Project Details
                <a href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($details->project_id); ?>" class="btn btn-warning btn-sm pull-right">Edit</a>
               </b> 
            </div>
            <div class="panel-body">
                <table class="table table-responsive table-striped table-hover">
                    <tbody>
                        <tr>
                            <td style="width:40%"><b>Project Id</b></td>
                            <td><?php echo e($details->project_id); ?></td>
                        </tr>
                        <tr>
                            <td><b>Project Name</b></td>
                            <td><?php echo e($details->project_name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Status</b></td>
                            <td><?php echo e($details->project_status); ?></td>
                        </tr>
                        <tr>
                            <td><b>Owner Name</b></td>
                            <td><?php echo e($details->ownerdetails->owner_name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Owner Email</b></td>
                            <td><?php echo e($details->ownerdetails->owner_email); ?></td>
                        </tr>
                        <tr>
                            <td><b>Owner Contact</b></td>
                            <td><?php echo e($details->ownerdetails->owner_contact_no); ?></td>
                        </tr>
                        <tr>
                            <td><b>Basement</b></td>
                            <td><?php echo e($details->basement); ?></td>
                        </tr>
                        <tr>
                            <td><b>Ground</b></td>
                            <td><?php echo e($details->ground); ?></td>
                        </tr>
                            <tr>
                            <td><b>Project Type</b></td>
                            <td><?php echo e($details->project_type); ?></td>
                        </tr>
                            <tr>
                            <td><b>Project Size</b></td>
                            <td><?php echo e($details->project_size); ?></td>
                        </tr>
                        <tr>
                            <td><b>Listing Engineer</b></td>
                            <td>
                                <?php echo $_GET['lename']; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><b>Road</b></td>
                            <td><?php echo e($details->road_name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Address</b></td>
                            <td><?php echo e($details->siteaddress->address); ?></td>
                        </tr>
                        <tr>
                            <td><b>Project Image</b></td>
                            <td>
                                <img height="300" width="300" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($details->image); ?>">
                            </td>
                        </tr>
                        <tr>
                            <td><b>Municipality Approval</b></td>
                            <td>
                                <?php if($details->municipality_approval != "N/A"): ?>
                                <img height="300" width="300" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($details->municipality_approval); ?>">
                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><b>Other Approval</b></td>
                            <td>
                                <?php if($details->other_approvals != "N/A"): ?>
                                <img height="300" width="300" class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($details->other_approvals); ?>">
                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><b>Budget (Cr.)</b></td>
                            <td>
                                <?php echo e($details->budget); ?> Cr.
                            </td>
                        </tr>
                        <tr>
                            <td><b>Type of Contractor</b></td>
                            <td>
                                <?php echo e($details->contract); ?>

                            </td>
                        </tr>
                        <tr>
                            <td><b>Remarks</b></td>
                            <td>
                                <?php echo e($details->remarks); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Procurement Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Procurement Name</th>
                        <th>Procurement Contact</th>
                        <th>Procurement Email</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($details->procurementdetails->procurement_name); ?></td>
                            <td><?php echo e($details->procurementdetails->procurement_contact_no); ?></td>
                            <td><?php echo e($details->procurementdetails->procurement_email); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:orange">
            <div class="panel-heading" style="background-color:orange">
               <b style="color:white">Site Engineer Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Site Engineer Name</th>
                        <th>Site Engineer Contact</th>
                        <th>Site Engineer Email</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($details->siteengineerdetails->site_engineer_name); ?></td>
                            <td><?php echo e($details->siteengineerdetails->site_engineer_contact_no); ?></td>
                            <td><?php echo e($details->siteengineerdetails->site_engineer_email); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>   
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Contractor Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Contractor Name</th>
                        <th>Contractor Email</th>
                        <th>Contractor Contact</th>
                    </thead>    
                    <tbody>
                        <tr>
                            <td><?php echo e($details->contractordetails->contractor_name); ?></td>
                            <td><?php echo e($details->contractordetails->contractor_email); ?></td>
                            <td><?php echo e($details->contractordetails->contractor_contact_no); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:orange">
            <div class="panel-heading" style="background-color:orange">
               <b style="color:white">Constultant Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Constultant Name</th>
                        <th>Constultant Email</th>
                        <th>Constultant Contact</th>
                    </thead>    
                    <tbody>
                        <tr>
                            <td><?php echo e($details->consultantdetails->consultant_name); ?></td>
                            <td><?php echo e($details->consultantdetails->consultant_email); ?></td>
                            <td><?php echo e($details->consultantdetails->consultant_contact_no); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
        
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>