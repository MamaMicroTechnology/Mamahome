<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-md-offset-4">
	<div class="panel panel-default">
		<div class="panel-heading">Select Road</div>
		<div class="panel-body">
			<ul class="list-group">
				<?php $__currentLoopData = $roads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $road): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="list-group-item <?php echo e($projectCount[$road]==0?'hidden':''); ?>"><a href="<?php echo e(URL::to('/')); ?>/projectrequirement?road=<?php echo e($road); ?>"><?php echo e($road); ?> (<?php echo e($projectCount[$road]); ?> projects)</a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>