<?php $__env->startSection('content'); ?>
<br>
<div class="col-md-8 col-md-offset-2">
<div class="panel panel-success">
    <div class="panel-heading">
       
    </div>
    <div class="panel-body">
        <div class="col-md-6">
            <center>Ward</center>
            <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojectsize">
                <select required class="form-control" name="ward">
                    <option value="">--Select--</option>
                    <option value="All">All</option>
                <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ward->id); ?>" <?php echo e($ward->id == $wardId? 'selected':''); ?>><?php echo e($ward->ward_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <button class="btn btn-primary form-control" type="submit">Fetch</button>
            </form>
            <br>
            <?php if(session('Error')): ?>
                <p class="alert alert-error"><?php echo e(session('Error')); ?></p>
            <?php endif; ?>
            <?php if($planningCount != NULL): ?>
            Total Project Sizes <?php echo $_GET['ward'] != "All" ? 'Under <b>'.$wardname->ward_name.'</b>' : ''; ?> (Based On Stages)<br>
            Total No. Of Projects : <b><?php echo e(number_format($planningCount + $diggingCount + $foundationCount + $pillarsCount + $completionCount + $fixturesCount + $paintingCount + $carpentryCount + $flooringCount + $plasteringCount + $enpCount + $roofingCount + $wallsCount)); ?></b>
            Total Sizes : <b><?php echo e(number_format($planningSize + $diggingSize + $foundationSize + $pillarsSize + $completionSize + $fixturesSize + $paintingSize + $carpentrySize + $flooringSize + $plasteringSize + $enpSize + $roofingSize + $wallsSize)); ?></b>
            <table class="table table-hover" border="1">
                <thead>
                    <th class="text-center">Stages</th>
                    <th class="text-center">No. of Projects</th>
                    <th class="text-center">Size<br>(in Sq. Ft.)</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Planning</td>
                        <td class="text-center"> <?php echo e($planningCount); ?> </td>
                        <td> <?php echo e(number_format(round($planningSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Digging</td>
                        <td class="text-center"><?php echo e($diggingCount); ?></td>
                        <td><?php echo e(number_format(round($diggingSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Foundation</td>
                        <td class="text-center"><?php echo e($foundationCount); ?></td>
                        <td><?php echo e(number_format(round($foundationSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Pillars</td>
                        <td class="text-center"><?php echo e($pillarsCount); ?></td>
                        <td><?php echo e(number_format(round($pillarsSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Walls</td>
                        <td class="text-center"><?php echo e($wallsCount); ?></td>
                        <td><?php echo e(number_format(round($wallsSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Roofing</td>
                        <td class="text-center"><?php echo e($roofingCount); ?></td>
                        <td><?php echo e(number_format(round($roofingSize))); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Electrical &amp; Plumbing</td>
                        <td class="text-center"><?php echo e($enpCount); ?></td>
                        <td><?php echo e(number_format(round($enpSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Plastering</td>
                        <td class="text-center"><?php echo e($plasteringCount); ?></td>
                        <td><?php echo e(number_format(round($plasteringSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Flooring</td>
                        <td class="text-center"><?php echo e($flooringCount); ?></td>
                        <td><?php echo e(number_format(round($flooringSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Carpentry</td>
                        <td class="text-center"><?php echo e($carpentryCount); ?></td>
                        <td><?php echo e(number_format(round($carpentrySize))); ?></td>
                    </tr>
                    <tr>
                        <td>Paintings</td>
                        <td class="text-center"><?php echo e($paintingCount); ?></td>
                        <td><?php echo e(number_format(round($paintingSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Fixtures</td>
                        <td class="text-center"><?php echo e($fixturesCount); ?></td>
                        <td><?php echo e(number_format(round($fixturesSize))); ?></td>
                    </tr>
                    <tr>
                        <td>Completion</td>
                        <td class="text-center"><?php echo e($completionCount); ?></td>
                        <td><?php echo e(number_format(round($completionSize))); ?></td>
                    </tr>
                </tbody>
            </table> 
            <?php endif; ?>
        </div>

        <?php if($subwards != NULL && $_GET['ward'] != "All"): ?>
        <div class="col-md-6">
            <center>Sub Ward</center>
            <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojectsize">
                <input type="hidden" name="ward" value=<?php echo e($wardId); ?>>
                <select required class="form-control" name="subward">
                    <option value="">--Select--</option>
                    <?php $__currentLoopData = $subwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ward->id); ?>" <?php echo e($subwardId == $ward->id? 'selected':''); ?>><?php echo e($ward->sub_ward_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <button class="btn btn-primary form-control" type="submit">Fetch</button>
            </form>
            <br>
            <?php if(session('Error')): ?>
                <p class="alert alert-error"><?php echo e(session('Error')); ?></p>
            <?php endif; ?>
            <?php if(isset($_GET['subward'])): ?>
            Total Project Sizes Under <b><?php echo e($subwardName); ?></b> (Based On Stages)<br>
            Total No. of Projects : <?php if($total): ?> <b><?php echo e(number_format($total - $Cclosed)); ?></b> <?php endif; ?>
            Total Sizes : <b><?php if($totalsubward): ?> <?php echo e(number_format($totalsubward - $closed)); ?> <?php endif; ?></b>
            <table class="table table-hover" border="1">
                <thead>
                    <th class="text-center">Stages</th>
                    <th class="text-center">No. of Projects</th>
                    <th class="text-center">Size<br>(in Sq. Ft.)</th>
                </thead>
                <tbody>
                    <tr>
                        <td>Planning</td>
                        <td class="text-center"><?php echo e($Cplanning); ?></td>
                        <td>
                             
                              <?php echo e(number_format($planning)); ?> 
                        </td>
                    </tr>
                    <tr>
                        <td>Digging</td>
                        <td class="text-center"><?php echo e($Cdigging); ?></td>
                        <td>
                            
                            <?php echo e(number_format($digging)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Foundation</td>
                        <td class="text-center"><?php echo e($Cfoundation); ?></td>
                        <td>
                            <?php echo e(number_format($foundation)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Pillars</td>
                        <td class="text-center"><?php echo e($Cpillars); ?></td>
                        <td>
                            
                            <?php echo e(number_format($pillars)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Walls</td>
                        <td class="text-center"><?php echo e($Cwalls); ?></td>
                        <td>
                            
                            <?php echo e(number_format($walls)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Roofing</td>
                        <td class="text-center"><?php echo e($Croofing); ?></td>
                        <td>
                            <?php echo e(number_format($roofing)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Electrical &amp; Plumbing</td>
                        <td class="text-center"><?php echo e($Cenp); ?></td>
                        <td>
                            <?php echo e(number_format($enp)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Plastering</td>
                        <td class="text-center"><?php echo e($Cplastering); ?></td>
                        <td>
                            
                            <?php echo e(number_format($plastering)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Flooring</td>
                        <td class="text-center"><?php echo e($Cflooring); ?></td>
                        <td>
                            
                            <?php echo e(number_format($flooring)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Carpentry</td>
                        <td class="text-center"><?php echo e($Ccarpentry); ?></td>
                        <td>
                            
                            <?php echo e(number_format($carpentry)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Paintings</td>
                        <td class="text-center"><?php echo e($Cpainting); ?></td>
                        <td>
                            
                            <?php echo e(number_format($painting)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Fixtures</td>
                        <td class="text-center"><?php echo e($Cfixtures); ?></td>
                        <td>
                            
                            <?php echo e(number_format($fixtures)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>Completion</td>
                        <td class="text-center"><?php echo e($Ccompletion); ?></td>
                        <td>
                            
                            <?php echo e(number_format($completion)); ?>

                        </td>
                    </tr>
                </tbody>
            </table> 
        <?php endif; ?>
        </div>
    <?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>