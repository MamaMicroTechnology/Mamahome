<?php
	$user = Auth::user()->group_id;
	$ext = ($user == 4? "layouts.amheader":"layouts.app");
?>


<?php $__env->startSection('content'); ?>

<div class="">
	<div class="col-md-12">
		<div class="panel panel-primary">
			<div class="panel-heading text-center">
					<a href="<?php echo e(URL::to('/')); ?>/inputview" class="btn btn-danger btn-sm pull-left">Add Enquiry</a>
					<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<p class="pull-left" style="padding-left: 50px;" id="display" >
				</p>
					
				Enquiry Data : <?php echo e(count($enquiries)); ?>

				 <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color: black;"></i></button>
				
					
				
			</div>
			<div class="panel-body" style="overflow-x: auto">
			
					
			<?php if(Auth::user()->group_id == 1): ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/manuenquirysheet">
			<?php elseif(Auth::user()->group_id == 17): ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/manuenquirysheet">
			<?php else: ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/manuenquirysheet">
			<?php endif; ?>
					<div class="col-md-12">
							<div class="col-md-2">
								<label>From (Enquiry Date)</label>
								<input value = "<?php echo e(isset($_GET['from']) ? $_GET['from']: ''); ?>" type="date" class="form-control" name="from">
							</div>
							<div class="col-md-2">
								<label>To (Enquiry Date)</label>
								<input  value = "<?php echo e(isset($_GET['to']) ? $_GET['to']: ''); ?>" type="date" class="form-control" name="to">
							</div>
							<?php if(Auth::user()->group_id != 22): ?>
							<div class="col-md-2">
								<label>Ward</label>
								<select   name="enqward" id="ward" onchange="loadsubwards()" class="form-control ">
									<option value="">--Select--</option>
									<?php $__currentLoopData = $wardwise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wards2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            <option value="<?php echo e($wards2->id); ?>"><?php echo e($wards2->ward_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<?php endif; ?>
							<div class="col-md-2">
								<label>Sub Wards</label>
								<select class="form-control" name="ward" id="subward">
									<!-- <option value="">--Select--</option>
									<option value="">All</option> -->
									<!-- <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option <?php echo e(isset($_GET['ward']) ? $_GET['ward'] == $ward->id ? 'selected' : '' : ''); ?> value="<?php echo e($ward->id); ?>"><?php echo e($ward->sub_ward_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
								</select>
							</div>
						<div class="col-md-2">
							<label>Initiator</label>
							<select class="form-control" name="initiator">
								<option value="">--Select--</option>
								<option value="">All</option>
								<?php $__currentLoopData = $initiators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $initiator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option <?php echo e(isset($_GET['initiator']) ? $_GET['initiator'] == $initiator->id ? 'selected' : '' : ''); ?> value="<?php echo e($initiator->id); ?>"><?php echo e($initiator->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="col-md-2">
							<label>Category:</label>
							<select id="categ" class="form-control" name="category">
								<option value="">--Select--</option>
								<option value="">All</option>
								<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option <?php echo e(isset($_GET['category']) ? $_GET['category'] == $category->category_name ? 'selected' : '' : ''); ?> value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
				
						<div class="col-md-12">
						<div class="col-md-2 col-md-offset-10">
							<input style="margin-top: 20px;margin-left:17px;" type="submit" value="Fetch" class="form-control btn btn-primary">
						</div>
					</div>
				</div>
			</form>
				
				<br><br>
				<div class="col-md-3" style="margin-top: -20px;">
					<div class="col-md-2">
						<label>Status: </label>
					</div>
					<div class="col-md-6">
						<select id="myInput" required name="status" onchange="myFunction()" class="form-control input-sm">
							<option value="">--Select--</option>
							<option value="all">All</option>
							<option value="Enquiry On Process">Enquiry On Process</option>
							<option value="Enquiry Confirmed">Enquiry Confirmed</option>
						</select>
					</div>
                  </div>
               
                <br><br>
				<table id="myTable" class="table table-responsive table-striped table-hover">
					<thead>
						<tr>
							<th style="text-align: center">manufacturer Id</th>
							<th style="text-align: center">SubWard Name</th>
							<th style="text-align: center">Name</th>
							<th style="text-align: center">Requirement Date</th>
							<th style="text-align: center">Enquiry Date</th>
							<th style="text-align: center">Contact</th>
							<th style="text-align: center">Product</th>
							<th style="text-align: center">Old Quantity</th>
							<th style="text-align: center">Enquiry Quantity</th>
							<th style="text-align: center">Total Quantity</th>
							<th style="text-align: center">Initiator</th>
							<th style="text-align: center">Converted by</th>
							<th style="text-align: center">Last Update</th>
							<th style="text-align: center">Status</th>
							<th style="text-align: center">Remarks</th>
							<th style="text-align: center">Update Status</th>
							<th style="text-align: center">Edit</th>
						</tr>
					</thead>
					<tbody>
						<?php $pro=0; $con=0; $total=0; $sum=0; $sum1=0; $sum2=0; ?>
						<?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($enquiry->status == "Enquiry On Process"): ?>
							<?php	$pro++; ?>
								<?php $sum = $sum + $enquiry->total_quantity; 
								 ?>
								
							<?php endif; ?>

							<?php if($enquiry->status == "Enquiry Confirmed"): ?>
							<?php	$con++; 
							 ?>

								
									<?php $sum1 = $sum1 + $enquiry->total_quantity; 
									 ?>
								

							<?php endif; ?>

							<?php if($enquiry->status == "Enquiry Confirmed" || $enquiry->status == "Enquiry On Process"): ?>
							<?php  $total++; 
							?>
								
									<?php $sum2 = $sum2 + $enquiry->total_quantity; 
									 ?>
								
							<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
						<?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($enquiry->status != "Not Processed"): ?>
							<td style="text-align:center;">
								<a target="_blank" href="<?php echo e(URL::to('/')); ?>/updateManufacturerDetails?id=<?php echo e($enquiry->manu_id); ?>">
									 <?php echo e($enquiry->manu_id); ?>

								</a> 
							</td>
							
							<td style="text-align: center">

                               <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($ward->id ==($enquiry->project != null ? $enquiry->project->sub_ward_id : $enquiry->sub_ward_id) ): ?>
					        <?php if($enquiry->manu_id == NULL): ?>
                                <a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($enquiry -> project_id); ?> && subward=<?php echo e($ward->sub_ward_name); ?>" target="_blank">
                                    <?php echo e($ward->sub_ward_name); ?>


                                </a>
                                <?php else: ?>
                                 <a href="<?php echo e(URL::to('/')); ?>/manufacturemap?id=<?php echo e($enquiry->manu_id); ?> && subwardid=<?php echo e($enquiry->sub_ward_id); ?>" data-toggle="tooltip" data-placement="top" title="click here to view map" class="red-tooltip" target="_blank"><?php echo e($ward->sub_ward_name); ?>

                                    </a>
                           <?php endif; ?>
                            </td>

                                  <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<td style="text-align: center"><?php echo e($enquiry->procurementdetails != null ? $enquiry->procurementdetails->procurement_name :''); ?>

                       <?php echo e($enquiry->proc != null ? $enquiry->proc->name :''); ?>

							</td>
							<td style="text-align: center"><?php echo e($newDate = date('d/m/Y', strtotime($enquiry->requirement_date))); ?></td>
							<td style="text-align: center"><?php echo e(date('d/m/Y', strtotime($enquiry->created_at))); ?></td>
							<td style="text-align: center"><?php echo e($enquiry->procurementdetails != null ? $enquiry->procurementdetails->procurement_contact_no : ''); ?>

							 <?php echo e($enquiry->proc != null ? $enquiry->proc->contact :''); ?></td>
							<td style="text-align: center"><b><?php echo e($enquiry->brand); ?></b><br><?php echo e($enquiry -> main_category); ?> (<?php echo e($enquiry->sub_category); ?>), <?php echo e($enquiry->material_spec); ?> <?php echo e($enquiry->product); ?> 
							</td>
							<td style="text-align: center">
								<?php $quantity = explode(", ",$enquiry->quantity); ?>
								<?php for($i = 0; $i<count($quantity); $i++): ?>
								<?php echo e($quantity[$i]); ?><br>
								<?php endfor; ?>
							</td>
							<td style="text-align: center"><?php echo e($enquiry->enquiry_quantity); ?></td>
							<td style="text-align: center"><?php echo e($enquiry->total_quantity); ?></td>
							<td style="text-align: center"><?php echo e($enquiry->user != null ? $enquiry->user->name : ''); ?></td>
							<td style="text-align: center">
							<?php echo e($enquiry->conuser != null ? $enquiry->conuser->name : ''); ?>

							</td>
							<td style="text-align: center">
								<?php echo e(date('d/m/Y', strtotime($enquiry->updated_at))); ?>

								<?php echo e($enquiry->user != null ? $enquiry->user->name : ''); ?>

							</td>
							<td style="text-align: center">
								<?php echo e($enquiry->status); ?>

							</td>
							<td style="text-align: center" onclick="edit('<?php echo e($enquiry->id); ?>')" id="<?php echo e($enquiry->id); ?>">
								<form method="POST" action="<?php echo e(URL::to('/')); ?>/editEnquiry">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($enquiry->id); ?>" name="id">
									<input onblur="this.className='hidden'; document.getElementById('now<?php echo e($enquiry->id); ?>').className='';" name="note" id="next<?php echo e($enquiry->id); ?>" type="text" size="35" class="hidden" value="<?php echo e($enquiry->notes); ?>"> 
									<p id="now<?php echo e($enquiry->id); ?>"><?php echo e($enquiry->notes); ?></p>
								</form>
							</td>
							
							<td>
								<form method="POST" action="<?php echo e(URL::to('/')); ?>/editEnquiry">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($enquiry->id); ?>" name="eid">
									<input type="hidden" value="<?php echo e($enquiry->manu_id); ?>" name="manu_id">

									
									<select required name="status" onchange="this.form.submit();" style="width:100px;">
										<option value="">--Select--</option>
										<option>Enquiry On Process</option>
										<option>Enquiry Confirmed</option>
										<option>Enquiry Cancelled</option>
									</select>
									
								</form>
							</td>
							<td>
								<a href="<?php echo e(URL::to('/')); ?>/editenq?reqId=<?php echo e($enquiry->id); ?>" class="btn btn-xs btn-primary">Edit</a>
							</td>
							
						</tr>

						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
						
					</tbody>
					<!--  <tr>
						<td style="text-align    : center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center">Total</td>
						 	<td style="text-align: center"><?php echo e($totalofenquiry); ?></td>
						 	<td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					        <td style="text-align: center"></td>
					</tr> -->
					
				</table>
				<!-- <table>
					<tbody>
						<tr>total</tr>
					</tbody>
				</table> -->
			</div>
			<div class="panel-footer">
				
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	function edit(arg){
		document.getElementById('now'+arg).className = "hidden";
		document.getElementById('next'+arg).className = "";
		document.getElementById('next'+arg).focus();
	}
	function editm(arg){
		document.getElementById('noww'+arg).className = "hidden";
		document.getElementById('nextt'+arg).className = "form-control";
	}
</script>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script type="text/javascript">
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");

  filter = input.value.toUpperCase();

  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  // Loop through all table rows, and hide those who don't match the search query
  
  if(filter == "ALL"){
  	for (i = 0; i < tr.length; i++) {
        tr[i].style.display = "";
	  }
	}else{
		for (i = 0; i < tr.length; i++) {
	    td = tr[i].getElementsByTagName("td")[13];
	    if (td) {
	      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
	        tr[i].style.display = "";
	      } else {
	        tr[i].style.display = "none";
	      }
	    }
	  }
	}
	if(document.getElementById("myInput").value  == "Enquiry On Process"){
		
		if(document.getElementById("categ").value  != "All"){
		
				document.getElementById("display").innerHTML = "Enquiry On Process  :  <?php echo e($pro); ?>   /  Quantity On Process : <?php echo e($sum); ?> "
		 }
	}
	else if(document.getElementById("myInput").value == "Enquiry Confirmed"){
		if(document.getElementById("categ").value  != "All"){
		document.getElementById("display").innerHTML = "Enquiry Confirmed  :  <?php echo e($con); ?>   /   Quantity On Confirmed : <?php echo e($sum1); ?>"
		}
	}
	else {

		if(document.getElementById("categ").value  != "All"){
		document.getElementById("display").innerHTML = "Total Enquiry Count  :  <?php echo e($total); ?>   /   Total Quantity  :  <?php echo e($sum2); ?>  "
		}
	}


	// if(document.getElementById("myInput").value  == "Enquiry On Process"){

	// 	if(document.getElementById("categ").value  == "All Category"){
			
	// 	document.getElementById("display").innerHTML = "Enquiry On Process  :  <?php echo e($pro); ?>"
	// 	}
	// }
	// else if(document.getElementById("myInput").value == "Enquiry Confirmed"){
		
	// 	if(document.getElementById("categ").value  == "All Category"){
	// 	document.getElementById("display").innerHTML = "Enquiry Confirmed  :  <?php echo e($con); ?>"
	// 	}
	// }
	// else {
	// 	if(document.getElementById("categ").value  == "All Category"){
	// 	document.getElementById("display").innerHTML = "Total Enquiry Count  :  <?php echo e($total); ?>"
	// }
	// }
}
</script>
 <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
     background-color: #00acd6 

});
</script>
<script type="text/javascript">
    function loadsubwards()
    {
        var x = document.getElementById('ward');
        var sel = x.options[x.selectedIndex].value;
        if(sel)
        {
            $.ajax({
                type: "GET",
                url: "<?php echo e(URL::to('/')); ?>/loadsubwards",
                data: { ward_id: sel },
                async: false,
                success: function(response)
                {
                    if(response == 'No Sub Wards Found !!!')
                    {
                        document.getElementById('error').innerHTML = '<h4>No Sub Wards Found !!!</h4>';
                        document.getElementById('error').style,display = 'initial';
                    }
                    else
                    {
                        var html = "<option value='' disabled selected>---Select---</option>"+"<option value='All'>ALL</option>";
                        for(var i=0; i< response.length; i++)
                        {
                            html += "<option value='"+response[i].id+"'>"+response[i].sub_ward_name+"</option>";
                        }
                        document.getElementById('subward').innerHTML = html;
                    }
                    
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>