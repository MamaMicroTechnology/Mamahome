<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-md-offset-2">
	<div class="panel panel-primary">
		<div class="panel-heading text-center">APPROXIMATE MATERIAL ESTIMATION
		<a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>	
		</div>
		<div class="panel-body">
			
			<table class="table table-responsive" border="1">
						<?php echo $table; ?>

			</table>
			<table class="table table-responsive" >
			<tr>
					<td style="text-align: center;">Do You Want To See Material Calculation Cost?</td>
					<td >
					<a href="#" class="btn btn-sm btn-success ">Yes</a>
					<a class=" btn btn-sm btn-danger " href="<?php echo e(url()->previous()); ?>">NO</a>
				</td>
			</tr>
			</table>
			
		</div>
	</div>
</div>
<div class="col-md-8 col-md-offset-2">
	
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>