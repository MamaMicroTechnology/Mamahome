<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 7? "layouts.sales":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <a href="<?php echo e(URL::to('/')); ?>/projectsUpdate" id="updates" class="form-control btn btn-primary <?php echo e(count($assignment) == 0? 'disabled': ''); ?>">Project Updates</a><br><br>
            <a href="<?php echo e(URL::to('/')); ?>/followupproject" class="form-control btn btn-primary <?php echo e(count($assignment) == 0? 'disabled': ''); ?>">Follow up projects</a><br><br>
            <a href="<?php echo e(URL::to('/')); ?>/kra" class="form-control btn btn-primary">KRA</a><br><br>
            <table class="table table-responsive">
                <tr><td>You have attended <?php echo e($calls); ?> calls so far.</td></tr>
                <tr><td>Marked <?php echo e($followups); ?> projects for followups.</td></tr>
                <tr><td><?php echo e($ordersinitiate); ?> orders initiated.</td></tr>
                <tr><td><?php echo e($ordersConfirmed); ?> orders confirmed.</td></tr>
                <tr><td>Genuine Projects : <?php echo e($genuineProjects); ?></td></tr>
                <tr><td>Fake Projects: <?php echo e($fakeProjects); ?></td></tr>
                <tr><td>Total : <?php echo e($genuineProjects + $fakeProjects); ?></td></tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>