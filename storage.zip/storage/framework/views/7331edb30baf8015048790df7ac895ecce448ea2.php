<?php $__env->startSection('content'); ?>

<div style="background-color:white" class="container" >
<h2 ><center>WELCOME TO  SALES OFFICER
<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><BR>
    <SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
    <h3 class="w3-container w3-center w3-animate-bottom" style="animation-duration: 2s;">Your Assigned Category  : <?php echo e($catname); ?>

</center></h2></div><br><br>
<?php if(session('Success')): ?>
<script>
    swal("success","<?php echo e(session('Success')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    swal("success","<?php echo e(session('error')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('earlylogout')): ?>
  <div class="modal fade" id="emplate" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header" style="background-color: #f27d7d;color:white;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Early logout</h4>
        </div>
        <div class="modal-body">
          <p style="text-align:center;"><?php echo session('earlylogout'); ?></p>  
        </div>
        <div class="modal-footer">
          <button type="button" style="background-color: #c9ced6;" class="btn btn-default" data-dismiss="modal" onClick="window.location.reload()">Close</button>
        </div>
      </div>
    </div>
  </div>
<script type="text/javascript">
  $(document).ready(function(){
      $("#emplate").modal('show');
  });
</script>
<?php endif; ?>
<!-- <div class="col-md-2">
                <h4 style="color:rgb(69, 198, 246);"><b>Click Here To Get Your Brands And Sub Categories</b></h4><br>
                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="button" onclick="brands('<?php echo e($category->id); ?>')"><?php echo e($category->category_name); ?></button>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
                <div class="col-md-2">
                  <h4><b></b></h4>
                    <div id="brands2" style="float:bottom;"></div>
                </div><br>
                 <div class="col-md-2">
                   <h4><b></b></h4>
                     <div id="sub2"></div>
                </div> -->
                
            <center>    <div class="col-md-4 col-md-offset-1 w3-container w3-center w3-animate-left" style="animation-duration: 2s;">
                  <h3> INSTRUCTION</h3>
                      <table border="1" class="table">
                        <thead>
                          <th>Total Projects</th>
                          <th>Updated Projects</th>
                          <th>Remaining Projects</th>
                          <th>Enquiry Added</th>
                          <th>Instructions</th>
                        </thead>
                        <tbody>
                          <td style="font-size:40px;width:50%;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate"><?php echo e($projects); ?></a></td>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate?update=updateproject"><?php echo e($updateprojects); ?></a></td>
                          <?php 
                          $x = $projects - $updateprojects;
                          ?>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate?unupdate=unupdate"><?php echo e($x); ?></a></td>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/enquirywise?salesenq=enq"><?php echo e($enq); ?></a></td>
                          <td style="width:50%;"><?php echo e($ins); ?></td>
                        </tbody>
                        
                      </table>

                </div>

  <div class="col-md-4 col-md-offset-1 w3-container w3-center w3-animate-right" style="animation-duration: 2s;">
           <h3>MONTHLY REPORT</h3>
                      <table border="1" class="table">
                        <thead>
                          <th>Total Projects</th>
                          <th>Updated Projects</th>
                          <th>Remaining Projects</th>
                          <th>Enquiry Added</th>
                        </thead>
                        <tbody>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate"><?php echo e($projects); ?></a></td>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate?update1=updateproject1"><?php echo e($updateprojects1); ?></a></td>
                          <?php 
                          $x = $projects - $updateprojects1;
                          ?>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/projectsUpdate?unupdate1=unupdate1"><?php echo e($x); ?></a></td>
                          <td style="font-size:40px;"><a href="<?php echo e(URL::to('/')); ?>/enquirywise?salesenq1=enq1"><?php echo e($enq1); ?></a></td>
                        </tbody>
                        
                      </table>

                </div>





              </center>
                <script type="text/javascript">
  var category;
function brands(arg){
 
        // var e = document.getElementById('category2');
        // var cat = e.options[e.selectedIndex].value;
        var ans = "";
        category = arg;
        $("html body").css("cursor", "progress");
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/getBrands",
            async:false,
            data:{cat : arg },
            success: function(response)
            {
                console.log(response);
               
                for(var i=0;i<response[0].length;i++)
                {
                    var text = "<button class='form-control' btn btn-warning btn-sm' onclick=\"Subs(\'" + response[0][i].id + "\')\">" + response[0][i].brand+"</button><br>";
                    ans += text;
                }
                document.getElementById('brands2').innerHTML = ans;
                $("body").css("cursor", "default");
            }
        });
    }
function Subs(arg)
    {
        var ans = "";

        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/getSubCatPrices",
            async:false,
            data:{brand : arg, cat: category},
            success: function(response)
            {
                var ans = " ";

                for(var i=0;i<response[1].length;i++)
                {
                     ans += "<button class='form-control btn btn-default btn-sm' value='"+response[1][i].id+"'>"+response[1][i].sub_cat_name+"</button><br><br>";
                   
                }

                document.getElementById('sub2').innerHTML = ans;
                $("body").css("cursor", "default");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>