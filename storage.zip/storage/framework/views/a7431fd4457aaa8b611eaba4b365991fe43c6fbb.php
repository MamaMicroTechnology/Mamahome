<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading" style="color:white;font-size: 15px;"> Total Listing Engineers : <?php echo e($totalcount); ?>

                    <?php if(session('Error')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('Error')); ?></div>
                    <?php endif; ?>
                    <a  href="javascript:history.back()" class="btn btn-sm btn-danger pull-right">Back</a>    

                </div>
                <div class="panel-body">
                  
                        <div class="col-md-12">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-1">
                                 <label>Search :</label>
                            </div>
                            <div class="col-md-3">
                                 <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Names and Phone Number Search" >
                            </div>
                        </div>
                            <br><br><br>
                    <table id="myTable" class="table table-responsive table-striped">
                        <thead>
                            <th style="text-align: center;">Employee Id</th>
                            <th style="text-align: center;">Name</th>
                            <th style="text-align: center;">Ward Assigned</th>
                            <th style="text-align: center;">Previous Assigned Ward</th>  
                            <th style="text-align: center;">Ward Images</th>
                            <th style="text-align: center;">Ward Map</th>
                            <th style="text-align: center;">Contact No.</th>
                            <th style="text-align: center;">Action</th>
                        </thead>
                        <tbody  >
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td  style="text-align: center;"><?php echo e($user->employeeId); ?></td>
                               
                                <td  style="text-align: center;"><?php echo e($user->name); ?></td>
                                <!-- Assign Ward Button -->
                                <?php if($user->status == 'Completed'): ?>
                                    <td style="text-align:center;">
                                        <a data-toggle="modal" data-target="#assignWards<?php echo e($user->id); ?>" class="btn btn-sm btn-primary">
                                            <b>Assign Wards</b>
                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td style="text-align:center"><?php echo e($user->sub_ward_name); ?></td>
                                <?php endif; ?>
                                <td style="text-align: center;">
                                    <?php $__currentLoopData = $subwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($subward->id == $user->prev_subward_id): ?>
                                            <?php echo e($subward->sub_ward_name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td style="text-align:center">
                                    <a href="<?php echo e(URL::to('/')); ?>/public/subWardImages/<?php echo e($user->sub_ward_image); ?>" target="_blank">View Image
                                    </a>
                                </td>
                                <td style="text-align:center">
                                    <a href="<?php echo e(URL::to('/')); ?>/viewwardmap?UserId=<?php echo e($user->id); ?> && wardname=<?php echo e($user->sub_ward_name); ?>" target="_blank">View map
                                    </a>                                   
                                </td>
                                <td style="text-align:center">
                                    <?php echo e($user->office_phone); ?>

                                </td>            
                                <!--Completed Button -->
                                <?php if($user->status == 'Completed'): ?>
                                <?php if(Auth::user()->group_id != 17): ?>
                                    <td style="text-align:center;">
                                        <a href="<?php echo e(URL::to('/')); ?>/viewReport?UserId=<?php echo e($user->id); ?>" class="btn btn-sm btn-primary form-control"><b>Report</b></a>
                                    </td>
                                <?php else: ?>
                                <td style="text-align:center;">Assign Wards</td>
                                <?php endif; ?>
                                <?php else: ?>
                                <?php if(Auth::user()->group_id != 17): ?>
                                    <td style="text-align:center">
                                        <div class="btn-group">
                                            <a  class="btn btn-sm btn-success" id="sale" onclick="Subs('<?php echo e($user->id); ?>')"><b>Completed</b></a>
                                            <a href="<?php echo e(URL::to('/')); ?>/viewReport?UserId=<?php echo e($user->id); ?>" class="btn btn-sm btn-primary"><b>Report</b></a>
                                        </div>
                                    </td>
                                <?php else: ?>
                                <td style="text-align:center;">Ward Assigned</td>
                                <?php endif; ?>
                                <?php endif; ?> 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal -->
<?php if(Auth::user()->group_id != 17): ?>
<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($user->id); ?>/assignWards">
<?php echo e(csrf_field()); ?>

<?php else: ?>
<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($user->id); ?>/converterassignWards">
<?php echo e(csrf_field()); ?>

<?php endif; ?>    
    <div id="assignWards<?php echo e($user->id); ?>" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Assign Wards</h4>
          </div>
          <div class="modal-body">
            <label>Choose Ward :</label><br>
                <select name="ward" class="form-control" id="ward<?php echo e($user->id); ?>" onchange="loadsubwards('<?php echo e($user->id); ?>')">
                    <option value="">--Select--</option>
                    <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ward->id); ?>"><?php echo e($ward->ward_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                
                <label>Choose Subward :</label><br>
                <select name="subward" class="form-control" id="subward<?php echo e($user->id); ?>">
                </select>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-success pull-left">Assign</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script type="text/javascript">
    function loadsubwards(arg)
    {
        var x = document.getElementById('ward'+arg);
        var sel = x.options[x.selectedIndex].value;
        if(sel)
        {
            $.ajax({
                type: "GET",
                url: "<?php echo e(URL::to('/')); ?>/loadsubwards",
                data: { ward_id: sel },
                async: false,
                success: function(response)
                {
                    if(response == 'No Sub Wards Found !!!')
                    {
                        document.getElementById('error'+arg).innerHTML = '<h4>No Sub Wards Found !!!</h4>';
                        document.getElementById('error'+arg).style,display = 'initial';
                    }
                    else
                    {
                        var html = "<option value='' disabled selected>---Select---</option>";
                        for(var i=0; i< response.length; i++)
                        {
                            html += "<option value='"+response[i].id+"'>"+response[i].sub_ward_name+"</option>";
                        }
                        document.getElementById('subward'+arg).innerHTML = html;
                    }
                    
                }
            });
        }
    }
</script>
<script>
function Subs(arg)
    {
        var e = arg;
      
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/sales",
            async:false,
            data:{userId: e },
            success: function(response)
            {
                console.log(response);
                  if(response == 0){
                    window.location = "<?php echo e(URL::to('/')); ?>/completedAssignment?id="+arg;
                  }else{
                    alert('Not Completed. '+ response.balance +' projects remaining.');
                  }
                
            }
        });
    }
    function myFunction()
     {
          var input, filter, table, tr, td, i;
          input = document.getElementById("myInput");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");
          for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                td1 = tr[i].getElementsByTagName("td")[6];
                if (td) {
                  if (td.innerHTML.toUpperCase().indexOf(filter) > -1 || td1.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                  } else {
                    tr[i].style.display = "none";
                  }
                }
      }
}
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>