<?php $__env->startSection('content'); ?>
<button id="btn_to_check">Do Something</button>

<div id="btn_confirmation_window" style="display:none">
  <button id="accept" value="true">accept</button>
  <button id="go_back" value="false">go back</button>
</div>

<script>
  $('#btn_to_check').on('click', function(){
    alert();
  confirmationWindow();
});

</script>
<script type="text/javascript">
function confirmationWindow(){
  alert();
    $('#btn_confirmation_window').fadeIn(); //or show() or css('display','block')
   
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>