<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <div class="panel panel-default" style="border-color:green">
                <div class="panel-heading"  style="background-color:green"><b style="color:white;font-size:1.3em">Departments</b></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a id="<?php echo e($department->dept_name); ?>" class="list-group-item" href="#"><?php echo e($department->dept_name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-10" id="disp"></div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function () {
    $("#date").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        var from = document.getElementById('from').value;
        var to = document.getElementById('to').value;
        alert(from);
        $("#disp").load("<?php echo e(URL::to('/')); ?>/amfinanceview?dept=Operation", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
</script>
<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
$(document).ready(function () {
    $("#<?php echo e($department->dept_name); ?>").on('click',function(){
        $(document.body).css({'cursor' : 'wait'});
        $("#disp").load("<?php echo e(URL::to('/')); ?>/amfinanceview?dept=<?php echo e($department->dept_name); ?>", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        $(document.body).css({'cursor' : 'default'});
    });
});
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.amheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>