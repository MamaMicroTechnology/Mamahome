<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 4? "layouts.amheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary" style="overflow-x:scroll">
                <div class="panel-heading text-center">
                    <b style="color:white;font-size:1.4em">Project Details</b>
                    <a href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($rec->project_id); ?>" class="btn btn-warning btn-sm pull-right">Edit</a>
                </div>
                <div class="panel-body">
                    <h3>Project Details</h3>
                    <table class="table table-responsive">
                        <tbody>
                            <tr>
                                <td style="width:40%"><b>Listed On</b></td>
                                <td><?php echo e(date('d-m-Y h:i:s A',strtotime($rec->created_at))); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%"><b>Listed By</b></td>
                                <td><?php echo e($username != null ? $username->name : ''); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%"><b>Updated On</b></td>
                                <td><?php echo e(date('d-m-Y h:i:s A',strtotime($rec->updated_at))); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%"><b>Sub-Ward</b></td>
                                <td><?php echo e($subward); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%"><b>Followup Started</b></td>
                                <td><?php echo e($rec->followup); ?> <?php if($followupby): ?> (marked by <?php echo e($followupby->name); ?>) <?php endif; ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%"><b>Updated By</b></td>
                                <td><?php echo e($callAttendedBy != null ? $callAttendedBy->name: ''); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project ID</b></td>
                                <td><?php echo e($rec->project_id); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project Name</b></td>
                                <td><?php echo e($rec->project_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Address</b></td>
                                <td>
                                    <a target="_blank" href="https://maps.google.com?q=<?php echo e($rec->siteaddress != null ? $rec->siteaddress->address : ''); ?>"><?php echo e($rec->siteaddress != null ? $rec->siteaddress->address : ''); ?></a>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Road Width</b></td>
                                <td><?php echo e($rec->road_width); ?></td>
                            </tr>
                            <tr>
                                <td><b>Construction Type</b></td>
                                <td><?php echo e($rec->construction_type); ?></td>
                            </tr>
                            <tr>
                                <td><b>Interested in RMC</b></td>
                                <td><?php echo e($rec->interested_in_rmc); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project Status</b></td>
                                <td><?php echo e($rec->project_status); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project Size</b></td>
                                <td><?php echo e($rec->project_size); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project Quality</b></td>
                                <td><?php echo e($rec->quality==null?"Unverified":$rec->Quality); ?></td>
                            </tr>
                            <!-- <tr>
                                <td style="width:40%;"><b>Basement</b></td>
                                <td><?php echo e($rec->basement); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Ground</b></td>
                                <td><?php echo e($rec->ground); ?></td>
                            </tr> -->
                            <tr>
                                <td style="width:40%;"><b>Project Type</b></td>
                                <td>
                                    B<?php echo e($rec->basement); ?> + G + <?php echo e($rec->ground); ?>= 
                                    <?php echo e($rec->project_type); ?>

                                </td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Project Image</b></td>
                                <td><img class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($rec->image); ?>" style="height:200px;width:200px" /></td>
                            </tr>
                            <!-- <tr>
                                <td style="width:40%;"><b>Municipality Approval</b></td>
                                <td>
                                    <?php if($rec->municipality_approval != "N/A"): ?>
                                    <img class="img img-responsive" src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($rec->municipality_approval); ?>" style="height:200px;width:200px" />
                                    <?php else: ?>
                                        <?php echo e($rec->municipality_approval); ?>

                                    <?php endif; ?>
                                </td>
                            </tr> -->
                            <tr>
                                <td style="width:40%;"><b>Contract</b></td>
                                    <td>
                                        <?php if($rec->contract == "With Material Contractor"): ?>
                                            Material Contract
                                        <?php elseif($rec->contract == "With Labour Contractor"): ?>
                                            Labour Contract
                                        <?php else: ?>
                                            <?php echo e($rec->contract); ?>

                                        <?php endif; ?>
                                    </td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Total Budget (in Cr.)</b></td>
                                <td><?php echo e($rec->budget); ?> Cr. (<?php echo e($rec->budgetType); ?>)</td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Budget (per sq.ft)</b></td>
                                <td><?php echo e(round((10000000 * $rec->budget)/$rec->project_size,3)); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Remarks</b></td>
                                <td><?php echo e($rec->remarks); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Note</b></td>
                                <td><?php echo e($rec->note); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h3>Room Types</h3>
                    <table class="table table-responsive">
                         <thead>
                            <th>Floor No.</th>
                            <th>Room Types</th>
                            <th>No.of Houses</th>
                         </thead>
                         <tbody>
                         <?php $__currentLoopData = $roomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><b>Floor No:</b><?php echo e($roomtype->floor_no); ?></td>
                                <td><?php echo e($roomtype->room_type); ?></td>
                                <td><?php echo e($roomtype->no_of_rooms); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <h3>Owner Details</h3>
                    <table class="table table-responsive">
                        <tbody>
                            <tr>
                                <td style="width:40%;"><b>Owner Name</b></td>
                                <td><?php echo e($rec->ownerdetails->owner_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Owner Contact No</b></td>
                                <td><?php echo e($rec->ownerdetails->owner_contact_no); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Owner Email</b></td>
                                <td><?php echo e($rec->ownerdetails->owner_email); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h3>Procurement Details</h3>
                    <table class="table table-responsive">
                        <tbody>
                            <tr>
                                <td style="width:40%;"><b>Procurement Name</b></td>
                                <td><?php echo e($rec->procurementdetails->procurement_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Procurement Contact No</b></td>
                                <td><?php echo e($rec->procurementdetails->procurement_contact_no); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Procurement Email</b></td>
                                <td><?php echo e($rec->procurementdetails->procurement_email); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h3>Consultant Details</h3>
                    <table class="table table-responsive">
                        <tbody>
                            <tr>
                                <td style="width:40%;"><b>Consultant Name</b></td>
                                <td><?php echo e($rec->consultantdetails->consultant_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Consultant Contact No</b></td>
                                <td><?php echo e($rec->consultantdetails->consultant_contact_no); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Consultant Email</b></td>
                                <td><?php echo e($rec->consultantdetails->consultant_email); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h3>Contractor Details</h3>
                    <table class="table table-responsive">
                        <tbody>
                            <tr>
                                <td style="width:40%;"><b>Contractor Name</b></td>
                                <td><?php echo e($rec->contractordetails->contractor_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Contractor Contact No</b></td>
                                <td><?php echo e($rec->contractordetails->contractor_contact_no); ?></td>
                            </tr>
                            <tr>
                                <td style="width:40%;"><b>Contractor Email</b></td>
                                <td><?php echo e($rec->contractordetails->contractor_email); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>    

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>