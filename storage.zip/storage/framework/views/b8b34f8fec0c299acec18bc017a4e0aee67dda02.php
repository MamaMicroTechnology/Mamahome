<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mamahome</title>
    <script type="text/javascript" src="<?php echo e(asset('js/gmaps.js')); ?>"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<br>
<form action="<?php echo e(URL::to('/')); ?>/allProjectsWithWards" method="get">
    <div class="col-md-2">
     <label for="wards">Select Zones:</label>
        <select required name="zone" class="form-control" id="wards">
            <?php $__currentLoopData = $zone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zoo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(isset($_GET['zones']) ? $_GET['zones'] == $zone->id ? 'selected' : '' : ''); ?> value="<?php echo e($zoo->id); ?>"><?php echo e($zoo->zone_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="wards">Select Wards:</label>
        <select required name="wards" class="form-control" id="wards">
            <option>---select---</option>
            <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(isset($_GET['wards']) ? $_GET['wards'] == $ward->id ? 'selected' : '' : ''); ?> value="<?php echo e($ward->id); ?>"><?php echo e($ward->ward_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="quality">Select Quality:</label>
        <select required name="quality" class="form-control" id="quality">
           <option>---select---</option> 
            <option <?php echo e(isset($_GET['quality']) ? $_GET['quality'] == "Genuine" ? 'selected' : '' : ''); ?> value="Genuine">Genuine</option>
            <option <?php echo e(isset($_GET['quality']) ? $_GET['quality'] == "Fake" ? 'selected' : '' : ''); ?> value="Fake">Fake</option>
            <option <?php echo e(isset($_GET['quality']) ? $_GET['quality'] == "Unverified" ? 'selected' : '' : ''); ?> value="Unverified">Unverified</option>
        </select>
        <br>
        <input type="submit" value="Fetch" class="btn btn-primary form-control">
        <br><br>
        <?php if(isset($_GET['wards'])): ?>
            Total Projects : <?php echo e(count($projects)); ?><br>
            <br>
            <!-- <button onclick="viewZoneMaps()" type="button" class="btn btn-success form-control">View All Wards Map</button> -->
        <?php endif; ?>
    </div>
</form>
    <div class="col-md-2">
    </div>
    <div class="col-md-10" style="border-style: ridge;">
        <div id="map" style="width:100%;height:600px"></div>
    </div>
    <?php if(isset($_GET['wards'])): ?>
    <script type="text/javascript" scr="https://maps.google.com/maps/api/js?sensor=false"></script>

    <script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    var newpath = [];
    var mysubpath = [];
    var latlng = [];
    var col = [];
    var places = [];
    var quality = [];
    <?php if($wardMaps != "None"): ?>
        var latlng = "<?php echo e($wardMaps->lat); ?>";
        var col = "<?php echo e($wardMaps->color); ?>";
    <?php else: ?>
        var latlng = "";
        var col = "456369"
    <?php endif; ?>
    var places = latlng.split(",");
    for(var i=0;i<places.length;i+=2){
          newpath.push({lat: parseFloat(places[i]), lng: parseFloat(places[i+1])});
    }
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        locations.push(["<a href=\"https://maps.google.com/?q=<?php echo e($project->address); ?>\"><?php echo e($project->project_id); ?>, <?php echo e($project->address); ?></a>",<?php echo e($project->latitude); ?>, <?php echo e($project->longitude); ?>]);
        created.push("<?php echo e($project->created_at); ?>");
        updated.push("<?php echo e($project->updated_at); ?>");
        quality.push("<?php echo e($project->quality); ?>");
        // alert(quality);
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: new google.maps.LatLng(locations[0][1], locations[0][2]),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {
        if(quality[i] == "Genuine"){
            var icon = {
                url: "http://www.free-icons-download.net/images/green-map-marker-icon-50710.png", // url
                scaledSize: new google.maps.Size(50, 50), // scaled size
                origin: new google.maps.Point(0,0), // origin
                anchor: new google.maps.Point(0, 0) // anchor
            };
            marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map,
            icon: icon
            });
        }
        // else{
        //     marker = new google.maps.Marker({
        //     position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        //     map: map,
        //     icon: 'nothing'
        //     });
        // }
        if(quality[i] == "Fake"){
            var icon = {
                url: "https://images.vexels.com/media/users/3/136303/isolated/preview/7dbfd48c913dc03cf834af0525429826-location-marker-icon-by-vexels.png", // url
                scaledSize: new google.maps.Size(50, 50), // scaled size
                origin: new google.maps.Point(0,0), // origin
                anchor: new google.maps.Point(0, 0) // anchor
            };
            marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map,
            icon: icon
            });
        }

        if(quality[i] == "Unverified"){
            var icon = {
                url: "https://cdn2.iconfinder.com/data/icons/IconsLandVistaMapMarkersIconsDemo/256/MapMarker_Flag_Right_Chartreuse.png", // url
                scaledSize: new google.maps.Size(50, 50), // scaled size
                origin: new google.maps.Point(0,0), // origin
                anchor: new google.maps.Point(0, 0) // anchor
            };
            marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map,
            icon: icon
            });
        }

        google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
            infowindow.setContent(locations[i][0]);
            infowindow.open(map, marker);
        }
        })(marker, i));
    }
    var subward = new google.maps.Polygon({
        paths: newpath,
        strokeColor: '#'+col,
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#'+col,
        fillOpacity: 0.35
      });
  subward.setMap(map);
    }
    </script>
    <?php endif; ?>

    <script>
        function viewZoneMaps(){
            // map = new GMaps({
            //     el: '#map',
            //     lat: 12.9716,
            //     lng: 77.5946,
            // });
            <?php $__currentLoopData = $zoneMap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                latlng = "<?php echo e($zone-> lat); ?>";
                places = latlng.split(",");
                path = [];
                newpath = [];
                latt = 0;
                lngg = 0;
                // for marking maps
                for(var i=0;i<places.length;i+=2){
                    newpath.push([parseFloat(places[i]), parseFloat(places[i+1])]);
                    latt += parseFloat(places[i]);
                    lngg += parseFloat(places[i+1]);
                }
                latt = latt/newpath.length;
                lngg = lngg/newpath.length;
                var line = parseInt('<?php echo e($zone->color); ?>') + 12345;
                var mypoly = new google.maps.Polygon({
                    paths: newpath,
                    strokeColor: '#'+line,
                    strokeOpacity: 0.6,
                    fillColor: '#<?php echo e($zone->color); ?>',
                    strokeWeight: 2
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        };
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU&callback=myMap"></script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>