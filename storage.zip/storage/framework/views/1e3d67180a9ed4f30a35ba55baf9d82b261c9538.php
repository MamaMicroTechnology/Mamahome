<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 1? "layouts.teamheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-3">
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading text-center">
                <b style="color:white">Custom Project Update Report</b>
            </div>
            <div class="panel-body">
                <form action="<?php echo e(URL::to('/')); ?>/newActivityLog" method="GET">
                     <?php echo e(csrf_field()); ?>

                <table class="table table-responsive">
                    <tbody >
                        <tr>
                            <td>Select Employees</td>
                        </tr>
                        <tr>
                            <td>
                                <select class="form-control" name="list" required>
                                    <option disabled selected value="">-- SELECT LE --</option>
                                    <?php if(Auth::user()->group_id != 22): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Select From Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date" placeholder= "From Date" class="form-control" id="fromdate" name="fromdate" required />
                            </td>
                        </tr>
                        <tr>
                            <td>Select To Date</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date"  placeholder= "To Date" class="form-control" id="todate" name="todate" required />
                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <button type="submit" class="btn bn-md btn-success" style="width:100">Get Date Range Details</button>
                            </td>
                        </tr>
                        <!--<tr class="text-center">-->
                        <!--    <td>-->
                        <!--        <a class="btn bn-md btn-primary" style="width:100%" onclick="showtodayrecordsle()">Get Date Details</a>-->
                        <!--    </td>-->
                        <!--</tr>-->
                    </tbody>
                </table>
            </form>
            </div>
        </div>
        <div class="panel panel-default" styke="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report (Today)</b>
            </div>
            <div class="panel-body" style="overflow-x:scroll;">
                <table class="table table-striped" border="1">
                    <thead>
                        <th style="font-size: 10px;">Name</th>
                        <th style="font-size: 10px;">Updated Projects</th>
                        <th style="font-size: 10px;">Called Projects</th>
                        <th style="font-size: 10px;">With Out Called Projects</th>
                    </thead>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px;"><?php echo e($noOfCall[$user->id]['count']); ?></td>
                        <td style="font-size: 10px;"><?php echo e($noOf[$user->id]['history']); ?></td>
                      <?php 
                      $x = $noOfCall[$user->id]['count'] - $noOf[$user->id]['history'];
                       ?>
                        <td style="font-size: 10px;"><?php echo e($x); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-9" >
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading" id="panelhead" style="padding:25px;">
                <div id="counts" class="pull-left"></div>
                 <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button> 
            </div>
            <div class="panel-body">
                <table class='table table-responsive table-striped' style="color:black" border="1">
                    <thead>
                        <tr>
                            <!-- <th style="text-align:center">Activity Id</th>  -->
                            <th style="text-align:center">Name</th> 
                            <th style="text-align:center">SubWard Name</th>
                            <th style="text-align:center">Project-ID</th>
                            <th style="text-align:center">Previous Values </th>
                            <th style="text-align:center">Updated Values</th>
                            <th style="text-align:center">Called Status</th>
                        </tr>
                    </thead>
                    <?php $noOfCalledCount = 0; $unCalledCount = 0; ?>
                    <tbody id="mainPanel">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $noOfCalls[$user->id]['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                               <!-- <td style="text-align:center" ><?php echo e($activities->id); ?></td> -->
                            <td style="text-align:center" ><?php echo e($user->name); ?></td>
                            <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($activities->subject->sub_ward_id == $subward->id): ?>
                               <td style="text-align:center" >
                                <a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($activities->subject->project_id); ?> && subward=<?php echo e($subward->sub_ward_name != null ? $subward->sub_ward_name :''); ?>" target="_blank">
                                <?php echo e($subward->sub_ward_name != null ? $subward->sub_ward_name :''); ?>

                               </a></td>
                               <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($activities->subject->project_id); ?>&&lename=<?php echo e($activities->causer->name); ?>" target="_blank"><?php echo e($activities->subject->project_id); ?></a></td>
                            <?php
                            $data =json_decode($activities->changes(), TRUE);
                          
                            ?>
                 <td>
                     <table class="table" border="1">
               <?php $__currentLoopData = $data['old']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $old): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <td><?php echo e($key); ?></td>
                             <td>:</td>
                             <td>
                                <?php if($key == "updated_by"): ?>
                                    <?php $__currentLoopData = $userChecks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($old == $userCheck->id): ?>
                                        <?php echo e($userCheck->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                     <?php echo e($old); ?>

                                <?php endif; ?>
                             </td>
                         </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </table>
                </td>
                <td>  
                     <table class="table" border="1">
                   <?php $__currentLoopData = $data['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                             <td><?php echo e($key); ?></td>
                             <td>:</td>
                             <td>
                                <?php if($key == "updated_by"): ?>
                                     <?php $__currentLoopData = $userChecks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($attributes == $userCheck->id): ?>
                                        <?php echo e($userCheck->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                     <?php echo e($attributes); ?>

                                <?php endif; ?>
                             </td>
                         </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
              </td>     
               
                              <td style="text-align:center">
                                 <?php if($activities->called == 1): ?>
                                 Yes
                                 <?php $noOfCalledCount++ ?>
                                 <?php else: ?>
                                 <?php $unCalledCount++ ?>
                                 No
                                 <?php endif; ?>      
                              </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    
    <script>
$(document).ready(function(){
    document.getElementById('counts').innerHTML = "<h4 style='margin-top:-10px;'>Total Projects : " + <?php echo e($noOfCalledCount + $unCalledCount); ?>+"&nbsp;&nbsp" + 
                                                    " Total Called : " + <?php echo e($noOfCalledCount); ?> +"&nbsp;&nbsp;"+
                                                    " Total Uncalled : " + <?php echo e($unCalledCount); ?> +"&nbsp;&nbsp;"+ "</h4>";
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>