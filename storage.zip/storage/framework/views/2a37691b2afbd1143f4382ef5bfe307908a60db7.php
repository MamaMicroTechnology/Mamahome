<?php $__env->startSection('content'); ?>

<div class="col-md-6 col-md-offset-3">
    <div class="panel panel-default">
        <div class="panel-heading" style="background-color: green;color: white;padding-bottom: 20px;">Edit Asset Details
        <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
        </div>
        <div class="panel-body">
        	 <?php if(session('Success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('Success')); ?>

                        </div>
               <?php endif; ?>
        	<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	 <form method="POST" action="<?php echo e(URL::to('/')); ?>/saveasset?Id=<?php echo e($post->id); ?>"  enctype="multipart/form-data">
        	 	<?php echo e(csrf_field()); ?>

		        	
		            <table class="table table-responsive">
		            	<tbody>
		            		<tr>
		            			<td><label>Name</label></td>
		            			<td><input type="text" class="form-control" value="<?php echo e($post->name); ?>" name="ename" style="width: 50%;"></td>
		            		</tr>
		            		<tr>
		            			<td><label>Serial No.</label></td>
		            			<td><input type="text" class="form-control" value="<?php echo e($post->sl_no); ?>" name="serialno" style="width: 50%;"></td>
		            		</tr>
		            		<tr>
		            			<td><label>Asset Image</label></td>
		            			 <td><input  type="file" name="upload"  class="form-control" accept="image/*" style="width:60%" /></td>
		            		</tr>
		            		<tr>
		            			<td><label>Description</label></td>
		            			<td><input type="text" class="form-control" value="<?php echo e($post->description); ?>" name="desc" style="width: 50%;"></td>
		            		</tr>
		            		<tr>
		            			<td><label>Company</label></td>
		            			<td><input type="text" class="form-control" value="<?php echo e($post->company); ?>" name="cmp" style="width: 50%;"></td>
		            		</tr>
		            		<tr>
                                <td ><label>Purchased Date:</label></td>
                                <td ><input required type="date" name="tdate"  value="<?php echo e($post->date); ?>" class="form-control" style="width:60%" /></td>
                            </tr>
                            <tr>
                                <td ><label> Bill:</label></td>
                                <td ><input type="file" name="bill"  class="form-control" accept="image/*" style="width:60%" /></td>
                            </tr>
		            		<tr>
		            			<td><label>Remark</label></td>
		            			<td><input type="text" class="form-control" value="<?php echo e($post->remark); ?>" name="remark" style="width: 50%;"></td>
		            		</tr>
		            		<tr>
		            			<td ></td>
		            			<td ><button type="submit" class="btn btn-sm btn-success">Save</button></td>
		            		</tr>
		            	</tbody>
		            </table>
		           
		         </form>
		          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
     </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>