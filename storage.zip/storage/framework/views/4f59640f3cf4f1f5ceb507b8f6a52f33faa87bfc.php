<?php $__env->startSection('content'); ?>

<div class="col-sm-6 col-sm-offset-3">
	<div class="panel panel-primary">
		<div class="panel-heading">Contractors
			<?php if(isset($_GET['phone'])): ?>
			<div class="alert-success pull-right">&nbsp;&nbsp;Search Result&nbsp;&nbsp;</div>
			<?php endif; ?>
		</div>
		<div class="panel-body">
			<form method="GET" action="<?php echo e(URL::to('/')); ?>/contractor_with_no_of_projects">
				<div class="input-group col-md-6 pull-right">
					<input type="text" name="phone" class="form-control" placeholder="Phone No.">
					<div class="input-group-btn">
						<input type="submit" value="Seaarch" class="btn btn-success">
					</div>
				</div>
			</form>
			<table class="table table-hover">
				<thead>
					<th>Contractor Name</th>
					<th>Contact No.</th>
					<th>No of projects</th>
					<th>View</th>
				</thead>
				<tbody>
					<?php if(!isset($_GET['phone'])): ?>
					<?php $__currentLoopData = $conName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($contractor->contractor_name); ?></td>
						<td><?php echo e($contractor->contractor_contact_no); ?></td>
						<td><?php echo e($projects[$contractor->contractor_contact_no]); ?></td>
						<td><a href="<?php echo e(URL::to('/')); ?>/viewProjects?no=<?php echo e($contractor->contractor_contact_no); ?>">View Projects</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<tr>
						<td><a href="<?php echo e(URL::to('/')); ?>/viewProjects?no=<?php echo e($_GET['phone']); ?>">View Projects</a></td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<div class="panel-footer">
			<center>
				<?php if(!isset($_GET['phone'])): ?>
				<?php echo e($conName->links()); ?>

				<?php endif; ?>
			</center>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>