<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="panel panel-warning">
            <div class="panel-heading text-center"><b>Follow Up Projects</b></div>
            <div class ="panel-body">
                <table class="table table-responsive" border=1>
                    <thead>
                        <th>Sl No</th>
                        <th>Required Date</th>
                        <th>Project Name</th>
                        <th>Owner contact</th>
                        <th>Procurement contact</th>
                        <th>Consultant Contact</th>
                        <th>Site Engineer Contact</th>
                        <th>Contractor Contact</th>
                        <th>Update Follow Up</th>
                        <th>Enquiry</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($project->project_id); ?></td>
                            <td><?php echo e($project->reqDate); ?></td>
                            <td><?php echo e($project->project_name); ?></td>
                            <td><?php echo e($project->ownerdetails != NULL ? $project->ownerdetails->owner_contact_no:''); ?></td>
                            <td><?php echo e($project->procurementdetails != NULL ? $project->procurementdetails->procurement_contact_no:''); ?></td>
                            <td><?php echo e($project->consultantdetails != NULL ? $project->consultantdetails->consultant_contact_no:''); ?></td>
                            <td><?php echo e($project->siteengineerdetails != NULL ? $project->siteengineerdetails->site_engineer_contact_no:''); ?></td>
                            <td><?php echo e($project->contractordetails != NULL ? $project->contractordetails->contractor_contact_no: ''); ?></td>
                            <td><input tabindex="-1" value="<?php echo e($project->note); ?>" id="note-<?php echo e($project->project_id); ?>" name="note-<?php echo e($project->project_id); ?>" class="form-control" onblur="updatenote(<?php echo e($project->project_id); ?>)" /></td>
                            <td><?php echo e($project->remarks); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <center><?php echo e($projects->links()); ?></center>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function updatenote(arg)
    {
        if(document.getElementById('note-'+arg).value)
        {
            var x = document.getElementById('note-'+arg).value;
            $.ajax({
                type: 'GET',
                url: "<?php echo e(URL::to('/')); ?>/updateNoteFollowUp",
                async:false,
                data: {value: x, id: arg},
                success: function(response)
                {
                    console.log(response);
                }
            });
            
        }    
        return false;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>