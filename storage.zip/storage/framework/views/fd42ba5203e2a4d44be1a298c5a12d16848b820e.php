<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <div class="col-md-8 col-md-offset-4">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Products Prices </b>
              <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;"></i></button>
             
            </div>
        <table  class="table table-responsive table-striped" border="1">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Sub Category</th>
                        <!-- <th>Designation</th> -->
                        <th>Quantity</th>
                         <?php if(Auth::user()->group_id == 2): ?>
                        <th> Price</th>
                        <?php endif; ?>
                       <!--  <th>Asst-TLs Price</th> -->
                        <?php if(Auth::user()->group_id == 6 || Auth::user()->group_id == 7 || Auth::user()->group_id == 17 ): ?>
                       <th> Price</th>
                        <?php endif; ?>
                    </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $myPrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myPrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($myPrice->category_name); ?></td>
                    <td><?php echo e($myPrice->brand); ?></td>
                    <td><?php echo e($myPrice->sub_cat_name); ?></td>
                    <td><?php echo e($myPrice->quantity); ?></td>
                         <?php if(Auth::user()->group_id == 2): ?>

                    <td><?php echo e($myPrice->stl); ?></td>
                    <?php endif; ?>
                    <!-- <td><?php echo e($myPrice->asstl); ?></td> -->
                        <?php if(Auth::user()->group_id == 6 || Auth::user()->group_id == 7 || Auth::user()->group_id == 17 ): ?>
                        <td><?php echo e($myPrice->leandse); ?>

                       </td>
                        <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                   </table>

        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>