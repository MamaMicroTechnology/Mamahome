<?php $__env->startSection('title','Logistics Orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12">
	<div class="panel panel-primary" style="overflow-x: scroll;">
		<div class="panel-heading text-center">
			<b style="color:white;font-size:1.4em">Confirmed Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Total Count : <?php echo e($count); ?></b>
			<a class="pull-right btn btn-sm btn-danger" href="<?php echo e(URL::to('/')); ?>/home" id="btn1" style="color:white;"><b>Back</b></a>
		</div>
		<div id="orders" class="panel-body">
			<table class="table table-responsive table-striped">
				<thead>
				    <th style="text-align:center">Project ID</th>
                    <th style="text-align: center;">Order Id</th>
					<th style="text-align:center">Product</th>
					<th style="text-align:center">Quantity</th>					
					<th style="text-align:center">Dispatch Status</th>
					<th style="text-align:center">Payment Status</th>
					<th style="text-align:center">Delivery Status</th>
                    <th style="text-align:center">Action</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr id="row-<?php echo e($rec->id); ?>">
						<td style="text-align:center"><a href="<?php echo e(URL::to('/')); ?>/showProjectDetails?id=<?php echo e($rec->project_id); ?>"><?php echo e($rec -> project_id); ?></a></td>
                        <td style="text-align:center"><?php echo e($rec->orderid); ?></td>
						<td>
							<?php echo e($rec->main_category); ?><br>
							(<?php echo e($rec->sub_category); ?>)
						</td>
						<td style="text-align:center"><?php echo e($rec->quantity); ?> <?php echo e($rec->measurement_unit); ?></td>
						<!-- <td style="text-align:center"></td> -->
						<td style="text-align:center">
						<?php if($rec->dispatch_status=='Yes'): ?>
						    Dispatched
						<?php else: ?>
						    <button onclick="updateDispatch('<?php echo e($rec->orderid); ?>')" class="btn btn-success btn-sm">Dispatch</button>
						<?php endif; ?>    
						</td>
				        <td style="text-align: center;">
				      
				             
                            <?php if($rec->paymentStatus != "Payment Received" && $rec->dispatch_status == 'Yes'): ?>
							<button data-toggle="modal" data-target="#PaymentModal<?php echo e($rec->orderid); ?>" class="btn btn-success btn-sm">Payment Details</button>
                                <form method="POST" action="<?php echo e(URL::to('/')); ?>/payment" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

									<div id="PaymentModal<?php echo e($rec->orderid); ?>" class="modal fade" role="dialog">
										<div class="modal-dialog modal-sm">
											<!-- Modal content-->
											<div class="modal-content">
											<div class="modal-header">
												Payment<br>
												<?php if($rec->status="Advance Received"): ?>
												<span class="pull-left" style="color:green;">Advance Amount:<?php echo e($rec->advance_amount); ?></span>
												<input type="hidden" name="advanceAmount" value="<?php echo e($rec->paymentId); ?>">
												<?php endif; ?>
											</div>
											<div class="modal-body">
											<label for="PaymentDoneBy">Customer Name</label>
											<input type="text" name="c_name" class="form-control input-sm">
												<label for="paymentMethod">Payment Mode:</label>
												<select name="payment_method"  class="form-control input-sm" id="ad" onchange="changeValue(this.value, '<?php echo e($rec->project_id); ?>')">
													<option value="">--Select--</option>
													<option value="RTGS">RTGS(Online Payment)</option>
													<option  value="Cheque">Cheque</option>
													<option   value="Advanced">Advance</option>
												</select>
												<label for="amount">Amount Received:</label>
												<input required type="text" name="amount" id="amount" placeholder="Amount Received" class="form-control input-sm">
												<label for="sign">Signature:</label>
												<input required type="file" name="signature" id="sign" class="form-control input-sm" accept="image/*">
												<div id="show<?php echo e($rec->project_id); ?>" class="hidden">
													<label for="amount">Payment Picture</label>
													<input id="adv"  type="file" name="signature1" id="sign" class="form-control input-sm" accept="image/*">
												</div>
												
												<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">
												<input type="hidden" name="project_id" value="<?php echo e($rec->project_id); ?>">
												<input type="hidden" name="log_name" value="<?php echo e($rec->delivery_boy); ?>">
												
											</div>
											<div class="modal-footer">
												<button type="submit" class="btn btn-success pull-left">Save</button>
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(URL::to('/')); ?>/public/signatures/<?php echo e($rec->signature); ?>"><?php echo e($rec->paymentStatus); ?></a>
                            <?php endif; ?>
                           
                        </td>
                        <td style="text-align:center">
                            <?php if($rec->delivery_status == "Not Delivered"): ?>
								<!-- Trigger the modal with a button -->
							<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal<?php echo e($rec->orderid); ?>">Deliver</button>

							<!-- Modal -->
							<form action="<?php echo e(URL::to('/')); ?>/saveDeliveryDetails" method="post" enctype="multipart/form-data">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="orderId" value="<?php echo e($rec->orderid); ?>">
								<div id="myModal<?php echo e($rec->orderid); ?>" class="modal fade" role="dialog">
								<div class="modal-dialog">

									<!-- Modal content-->
									<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Order Delivery Form</h4>
									</div>
									<div class="modal-body">
										<table class="table table-hover" border=1>
											<tr>
												<td colspan=2><label for="Images">Images</label></td>
											</tr>
											<tr>
												<td>Vehicle No.</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="vno" id="vno" class="form-control"></td>
											</tr>
											<tr>
												<td>Location Picture</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="lp" id="lp" class="form-control"></td>
											</tr>
											<tr>
												<td>Quality of Material</td>
												<td><input required accept="image/*" oninput="inputcheck()" type="file" name="qm" id="qm" class="form-control"></td>
											</tr>
											<tr>
												<td colspan="2"><center><label for="Video">Video</label></center></td>
											</tr>
											<tr>
												<td>
													Delivery Video
													<br>(Video should cover all the<br>necessary fields as in images)
												</td>
												<td><input accept="video/*" oninput="inputcheck()" type="file" name="vid" id="vid" class="form-control"></td>
											</tr>
										</table>
									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-success pull-left">Save</button>
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									</div>
									</div>
								</div>
								</div>
							</form>
                                <!-- <button onclick="deliverOrder('<?php echo e($rec->orderid); ?>')" class="btn btn-success btn-sm">Deliver</button> -->
                            <?php else: ?>
							<?php
								$images = "<a target='_blank' class='".($rec->vehicle_no == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->vehicle_no."'>Vehicle No</a><br>"
											."<a target='_blank' class='".($rec->location_picture == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->location_picture."'>Location Picture</a><br>"
											."<a target='_blank' class='".($rec->quality_of_material == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->quality_of_material."'>Quality Of Material</a><br>"
											."<a target='_blank' class='".($rec->delivery_video == null ? 'hidden':'')."' href='http://".$_SERVER['HTTP_HOST']."/"."public/delivery_details/".$rec->delivery_video."'>Video</a>";
							?>
								<a href="#" data-toggle="popover" title="Delivery Images" data-content="<?php echo $images; ?>">
									<?php echo e($rec->delivery_status); ?>

								</a>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                            <?php if($rec->paymentStatus == "Payment Received"): ?>
                                <?php echo e($rec->paymentStatus); ?>

                              <?php elseif($rec->paymentStatus == "Advance Received"): ?>
                                <?php echo e($rec->paymentStatus); ?>

                            <?php elseif($rec->delivery_status != "Delivered"): ?>
    				            <a onclick="cancelOrder('<?php echo e($rec->orderid); ?>')" class="btn btn-sm btn-danger" style="width:99%" >
    				                <b>Cancel Order</b>
    				            </a>

                            <?php else: ?>
                                Order Delivered
                            <?php endif; ?>
				        </td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>	
			</table>
			<br>
			<center><?php echo e($view->links()); ?></center>	
		</div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover({html:true});   
});
</script>
<script type="text/javascript">
	
	function pay(arg)
	{
		var ans = confirm('Are You Sure ? Note: Changes Made Once CANNOT Be Undone');
		if(ans){
			$.ajax({
				type: 'GET',
				url: "<?php echo e(URL::to('/')); ?>/updateampay",
				data: {id: arg},
				async: false,
				success: function(response){
					console.log(response);
				}
			});
		}
		return false;
	}

	function updateDispatch(arg)
	{
		var ans = confirm('Are You Sure ? Note: Changes Made Once CANNOT Be Undone');
		if(ans){
    		$.ajax({
    			type: 'GET',
    			url: "<?php echo e(URL::to('/')); ?>/updateamdispatch",
    			data: {id: arg},
    			async: false,
    			success: function(response){
    				console.log(response);
                     $("#orders").load(location.href + " #orders>*", "");
    			}
    		});
		}
		return false;	
	}
	
	function deliverOrder(arg)
	{
	    var ans = confirm('Are You Sure To Confirm This Order ?');
	    if(ans)
	    {
    	    $.ajax({
    	       type:'GET',
    	       url: "<?php echo e(URL::to('/')); ?>/deliverOrder",
    	       data: {id : arg},
    	       async: false,
    	       success: function(response)
    	       {
    	           console.log(response);
    	           $("#orders").load(location.href + " #orders>*", "");
    	       }
    	    });
	    }    
	}
	
	function cancelOrder(arg)
	{
	    var ans = confirm('Are You Sure To Cancel This Order ?');
	    if(ans)
	    {
    	    $.ajax({
    	       type:'GET',
    	       url: "<?php echo e(URL::to('/')); ?>/cancelOrder",
    	       data: {id : arg},
    	       async: false,
    	       success: function(response)
    	       {
    	           console.log(response);
    	           $("#orders").load(location.href + " #orders>*", "");
    	       }
    	    });
	    }
	 }
function changeValue(val, id){
//use comparison operator   
if(val=="Cheque")
     document.getElementById('show'+id).className = "";
 else{
 	 document.getElementById('show'+id).className="hidden";
 }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logisticslayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>