<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="row">
                <?php if(Auth::user()->group_id != 22): ?>
        <div class="col-md-6">
            <div class="panel panel-default" style="border-color:green">
                <div class="panel-heading" style="color:white;background-color:green">Zones
                    <?php if(session('ErrorZone')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorZone' )); ?></div>
                    <?php endif; ?> 
                </div>
                <div class="panel-body" style=" height: 500px; max-height: 500px; overflow-y:scroll; overflow-x: hidden;">
        
                        <table class="table">
                            <thead>       
                                    <th style="padding-left: 50px;">Zone Name</th>
                                    <th style="padding-right: 50px;">Zone No</th>
                                    <th  >Zone Map</th>   
                            </thead>
                            <tbody>
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                           <td style="text-align: left;padding-left:70px"><?php echo e($zone->zone_name); ?></td>
                                            <td ><?php echo e($zone->zone_number); ?></td>
                                            <td ><a href="<?php echo e(URL::to('/')); ?>/viewMap?zoneId=<?php echo e($zone->id); ?>"  target="_blank">View image</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                              
                        </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-6">
            
            <div class="panel panel-default" style="border-color: green">
                <div class="panel-heading" style="color:white;background-color: green">Main Wards</div>
                <div class="panel-body" style=" height: 500px; max-height: 500px; overflow-y:scroll; overflow-x: hidden;">
                    <table class="table">
                        <thead>
                            <th style="text-align: center;">Ward Name</th>
                            <th style="text-align: center;">Ward Image and Map</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align: center;"><?php echo e($ward->ward_name); ?></td>
                                <td style="text-align: center;"><a href="<?php echo e(URL::to('/')); ?>/public/wardImages/<?php echo e($ward->ward_image); ?>"> click here to Image</a></td>
                            </tr>
                             <td>
                                
                                <td style="text-align: center;"><a href="<?php echo e(URL::to('/')); ?>/viewMap?wardId=<?php echo e($ward->id); ?>" class="btn btn-sm btn-primary" target="_blank"> click here to View Map</a></td>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>