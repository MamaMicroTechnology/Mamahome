<?php
        $user = Auth::user()->group_id;
        $ext = ($user == 2? "layouts.app":"layouts.teamheader");
?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->group_id == 2 || Auth::user()->group_id == 1): ?>
<br><br>
<h2><center>WELCOME TO <b>SENIOR TEAM LEADER </b>
<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><br>
<?php else: ?>
<br><br>
<h2><center>WELCOME TO <b>TEAM LEADER </b>
<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><br>
<?php endif; ?>
<?php if(Auth::user()->group_id == 22): ?>
<table class="table" style="width:50%;">
  <tr>
    <th>Team Members</th>
    <th>Designation</th>
  </tr>

 <h2>Assigned Wards<br>
  <?php $__currentLoopData = $newwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($newward['tl_id'] == Auth::user()->id): ?>
                                            <?php $__currentLoopData = $newward['wardtl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wardstl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php echo e($wardstl['ward_name']); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                       <?php endif; ?>
                                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h2>
       
</table>
<?php endif; ?>
</table>
    <SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
</center></h2>
<center class="countdownContainer">
    <h1>Operation <i style="color:yellow; font-size: 50px;" class="fa fa-bolt"></i> Lightning</h1>
    <div id="clockdiv">
        <div>
            <span class="days"></span>
            <div class="smalltext">Days</div>
        </div>
        <div>
            <span class="hours"></span>
            <div class="smalltext">Hours</div>

        </div>
        <div>
            <span class="minutes"></span>
            <div class="smalltext">Minutes</div>
        </div>
        <div>
            <span class="seconds"></span>
            <div class="smalltext">Seconds</div>
        </div>
    </div>
</center>
<?php if(Auth::user()->group_id != 22): ?>
<div class="col-md-5 col-md-offset-3">
    <div class="panel panel-default">
        <div class="panel-heading"><center><b>MINI ATTENDANCE (<?php echo e(date('d-m-Y')); ?>)</b></center></div>
        <div class="panel-body">
        <table class="table table-hover">
        <thead>
            <tr>
                <th>Employee-Id</th>
                <th>Name</th>
                <th>Login Time</th>
                <th>Logout Time</th>
            </tr>
           </thead>
            <?php $__currentLoopData = $loggedInUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loggedInUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loggedInUser->id = 1|| $loggedInUser->id = 2): ?>
                <tr>
                    <td><?php echo e($loggedInUser->employeeId); ?></td>
                    <td><?php echo e($loggedInUser->name); ?></td>
                    <td><?php echo e($loggedInUser->logintime); ?></td>
                    <td><?php echo e($loggedInUser->logout); ?></td>
               </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>