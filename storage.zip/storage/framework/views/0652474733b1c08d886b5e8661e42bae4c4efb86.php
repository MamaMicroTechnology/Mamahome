<div class="panel panel-default" style="border-color:green">
<div class="panel-heading" style="background-color:green;font-weight:bold;font-size:1.3em;color:white">Employees On <?php echo e($dept); ?></div>
<div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
<table class="table table-hover">
<thead>
    <th>Emp Id</th>
    <th>Name</th>
    <th>Designation</th>
    <th>Assign Assets</th>
   
</thead>
<tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->employeeId); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->group->group_name); ?></td>
       <td>
            <a class="btn btn-primary" href="<?php echo e(URL::to('/')); ?>/assignEmployee?UserId=<?php echo e($user->employeeId); ?>" >Assign</a>
        </td>
       
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>