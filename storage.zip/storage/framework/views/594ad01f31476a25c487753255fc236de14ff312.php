<?php $__env->startSection('content'); ?>
<div class="container">
<div class="col-md-12">
    <div class="panel panel-default" style="border-color:green;"> 
                <div class="panel-heading" style="background-color: green;color:white;">  Projects To Be Updated
                <?php if($totalproject != 0): ?>
                 From <span>&nbsp;&nbsp;&nbsp;</span><b style="color: white;"><?php echo e(date('d-m-Y', strtotime($previous))); ?></b> : <?php echo e($totalproject); ?> 
                	
                <?php endif; ?>

                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                </div>
                <div class="panel-body">
               	    <div class="col-md-12">
               	    <form method="GET" action="<?php echo e(URL::to('/')); ?>/Unupdated">
               	    	 	<div class="col-md-2">
								<label>Choose Ward :</label><br>
					                <select name="ward" class="form-control" id="ward" onchange="loadsubwards()">
					                    <option value="">--Select--</option>
					                    <option value="All">All</option>
					                    <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    <option value="<?php echo e($ward->id); ?>"><?php echo e($ward->ward_name); ?></option>
					                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                </select>
							</div>
							<div class="col-md-2">
								<label>Choose Subward :</label><br>
					                <select name="subward" class="form-control" id="subward">
					                </select>
							</div>
                			
							<div class="col-md-2">
								<label></label>
								<input type="submit" value="Fetch" class="form-control btn btn-primary">
							</div>
					</form>
					</div>
				<br><br>
					<table class="table table-hover">
					<thead>
						<th>Project Id</th>
						<th>Project Name</th>
						
						<th>Project Status</th>
						<th>Quality</th>
						<th>Address</th>
						<th>Update </th>
						<th>Remarks</th>
					</thead>
					
					<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tbody>
						<td><?php echo e($project->project_id); ?></td>
						<td><?php echo e($project->project_name); ?></td>
						
						<td><?php echo e($project->project_status); ?></td>
						<td><?php echo e($project->quality); ?></td>
						<td>
						<?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sites): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($sites->project_id == $project->project_id): ?>
							<a href="#" ><?php echo e($sites->address); ?></a>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
						<td style="width:10%;"><?php echo e(date('d-m-Y', strtotime($project->updated_at))); ?></td>
						<td><?php echo e($project->remarks); ?></td>
					</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</table>
				<?php if(count($projects) != 0): ?>
                <?php echo e($projects->appends($_GET)->links()); ?>

                <?php endif; ?>
                </div>
             
               
    </div>
   </div>
</div>
<script type="text/javascript">
    function loadsubwards()
    {
        var x = document.getElementById('ward');
        var sel = x.options[x.selectedIndex].value;
        if(sel)
        {
            $.ajax({
                type: "GET",
                url: "<?php echo e(URL::to('/')); ?>/loadsubwards",
                data: { ward_id: sel },
                async: false,
                success: function(response)
                {
                    if(response == 'No Sub Wards Found !!!')
                    {
                        document.getElementById('error').innerHTML = '<h4>No Sub Wards Found !!!</h4>';
                        document.getElementById('error').style,display = 'initial';
                    }
                    else
                    {
                        var html = "<option value='' disabled selected>---Select---</option>";
                        for(var i=0; i< response.length; i++)
                        {
                            html += "<option value='"+response[i].id+"'>"+response[i].sub_ward_name+"</option>";
                        }
                        document.getElementById('subward').innerHTML = html;
                    }
                    
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>