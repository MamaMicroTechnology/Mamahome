<?php $__env->startSection('content'); ?>

<div class="col-md-10 col-md-offset-1">
    <div class="panel panel-default">
        <div class="panel-heading" style="background-color: green;color: white;padding-bottom: 20px;">Asset Info
      <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
        <span class="pull-right">&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <a href="<?php echo e(URL::to('/')); ?>/signature" type="button" class="btn btn-sm btn-primary pull-right" >Take Signature</a>
           <span class="pull-right">&nbsp;&nbsp;&nbsp;&nbsp;</span>
         <button type="button" class="btn btn-sm btn-primary pull-right" data-toggle="modal" data-target="#modelsim">Assign SIM</button>
          <span class="pull-right">&nbsp;&nbsp;&nbsp;&nbsp;</span>
         <input type="button" class="btn btn-sm btn-primary pull-right" data-toggle="modal" data-target="#myaddModal" value="Assign">

        </div>
        <div class="panel-body" style="overflow-x: hidden;overflow-y: scroll;overflow-x: scroll;max-height: 500px;height: 500px;">
            <table class="table table-responsive">
                <tr>
                    <td>Name</td>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <td>Designation</td>
                    <td><?php echo e($user->group->group_name); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <td>Assets</td>
                    <td>
                        <?php if($assetInfos != NULL ): ?>
                        <table class="table table-responsive">
                            <thead>
                                <th>Type</th>
                                 <th>Model Name</th>
                                <th>Serial No.</th>
                                <th>Description</th>
                                <th>Assign Date</th>
                                <th>Remark</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $assetInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($assetInfo->asset_type != "SIMCard"): ?>
                                    <td><?php echo e($assetInfo->asset_type); ?></td>
                                    <td><?php echo e($assetInfo->name); ?>

                                    <td><?php echo e($assetInfo->serial_no); ?></td>
                                    <!-- <td><a href="<?php echo e(URL::to('/')); ?>/public/assettype/<?php echo e($assetInfo->image); ?>"  target="_blank"> image</a></td> -->
                                    <td style="width: 20%;"><?php echo e($assetInfo->description); ?></td>
                                    <td><?php echo e(date( 'd-m-Y' , strtotime($assetInfo->assign_date))); ?></td>
                                    <td><?php echo e($assetInfo->remark); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(URL::to('/')); ?>/deleteAsset">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($assetInfo->id); ?>">
                                            <input type="submit" value="Delete" class="btn btn-xs btn-danger"> 
                                        </form>

                                    </td>
                                    <!-- <td> <input type="submit" value="Edit" style="width: 80%" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myModal<?php echo e($assetInfo->id); ?>"></td> -->
                                    <td>
                                        <a class="btn btn-xs btn-success" href="<?php echo e(URL::to('/')); ?>/preview?Id=<?php echo e($assetInfo->employeeId); ?> && id=<?php echo e($assetInfo->id); ?>">Preview</a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                       
                    </td>
                <tr>
                    <td>Asset SIM</td>
                    <td>
                        <?php if($assetInfos != NULL ): ?>
                        <table class="table table-responsive">
                            <thead>
                                <th>Type</th>
                                <th>SIMCard Brand/Provider </th>
                                <th>Simcard Number</th>
                                <th>Remark</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $assetInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($assetInfo->asset_type == "SIMCard"): ?>
                                    <td><?php echo e($assetInfo->asset_type); ?></td>
                                    <td><?php echo e($assetInfo->provider); ?></td>
                                    <td><?php echo e($assetInfo->sim_number); ?></td>
                                    <td><?php echo e($assetInfo->sim_remark); ?></td>
                                    <td><form method="POST" action="<?php echo e(URL::to('/')); ?>/deletesim">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="id" value="<?php echo e($assetInfo->id); ?>">
                                                <input type="submit" value="Delete" class="btn btn-xs btn-danger"> 
                                        </form></td>
                                    <td>
                                        <a class="btn btn-xs btn-success" href="<?php echo e(URL::to('/')); ?>/preview?Id=<?php echo e($assetInfo->employeeId); ?>&& id=<?php echo e($assetInfo->id); ?>">Preview</a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        </td>
                </tr>
            </table>
        </div>
    </div>
</div>
<div id="myaddModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background-color:rgb(244, 129, 31);color:white;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Assign</h4>
      </div>
      <div class="modal-body">
             <form method="POST" action="<?php echo e(URL::to('/')); ?>/amedit/saveAssetInfo" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="userId" value="<?php echo e($user->employeeId); ?>">
                <table id="asset" class="table table-responsive">
                    
                    <tbody>
                        <tr>
                            <td><label>Asset Type:</label></td>
                            <td>
                                <select required class="form-control" name="type[]" id="type" onchange="getname()">
                                    <option value="">--Select--</option>
                                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($asset->id); ?>"><?php echo e($asset->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Model Name<label></td>
                            <td> <select name="mname" id="mname" required class="form-control" onchange="getserial()" ></select></td>

                        </tr>

                        <tr>
                            <td><label>Serial No:</label></td>
                           <td> <select name="number" id="number" required class="form-control" ></select></td>
                        </tr>
                       
                       <tr>
                            <td><label>Description:</label></td>
                                <td> <input  name="details" id="desc" required class="form-control" onclick="getdesc()"></td>
                            </td>
                        </tr>
                         <tr>
                            <td><label>Employee Signature:</label></td>
                            <td><input required type="file" name="emp_image"  class="form-control" accept="image/*" ></td>
                        </tr>
                        <tr>
                            <td><label>Asset Manager Signature:</label></td>
                            <td><input required type="file" name="manager_image"  class="form-control" accept="image/*" ></td>
                        </tr>
                        <tr>
                            <td><label>Remark:</label></td>
                             <td><textarea required class="form-control" placeholder="Remark" name="remark[]" style="resize: none;" ></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Assign_Date:</label></td>
                             <td><input required type="date" name="tdate"  class="form-control"  /></td>

                        </tr>
                    </tbody>
                </table>
                <center><input type="submit" class=" btn btn-md btn-success" value="Save"></center>
            </form>
      </div>
      <div class="modal-footer">
      </div>
    </div>

  </div>
</div>


<!-- Modal -->
<div id="modelsim" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
     <div class="modal-content">
      <div class="modal-header" style="background-color:rgb(244, 129, 31);color:white;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Assign</h4>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(URL::to('/')); ?>/savesiminfo" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="userId" value="<?php echo e($user->employeeId); ?>">
                <table id="asset" class="table table-responsive">
                    
                    <tbody>
                    
                    <tr>
                        <td><label>SIMCard Number</label></td>
                        <td><select required class="form-control" name="number" id="num" onchange="getbrand()" style="width:60%">
                                    <option value="">--Select--</option>
                                    <?php $__currentLoopData = $sim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sim->id); ?>"><?php echo e($sim->sim_number); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select></td>
                    </tr>
                    <tr>
                        <td ><label>SIMCard Brand/Provider </label></td>
                        <td ><input required type="text" name="sim" id="sim" class="form-control" style="width:60%" /></td>
                    </tr>
                    <tr>
                            <td><label>Employee Signature:</label></td>
                            <td><input required type="file" name="emp_image"  class="form-control" accept="image/*" style="width:60%"></td>
                    </tr>
                    <tr>
                        <td><label>Asset Manager Signature:</label></td>
                        <td><input required type="file" name="manager_image"  class="form-control" accept="image/*" style="width:60%"></td>
                    </tr>
                    <tr>
                        <td ><label> Remark:</label></td>
                        <td ><textarea required placeholder="Remark"  required type="type" cols="3" name="sremark"  class="form-control" style="width:60%;resize: none;" /></textarea></td>                
                    </tr>
                    </tbody>
                </table>
                <center><input type="submit" class=" btn btn-md btn-success" value="Save"></center>
            </form>
      </div>
    </div>

  </div>
</div>


<!-- Modal -->
   <?php $__currentLoopData = $assetInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assetInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="myModal<?php echo e($assetInfo->id); ?>" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:rgb(244, 129, 31);color: white;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Asset Info</h4>
        </div>
          <form method="POST" action="<?php echo e(URL::to('/')); ?>/saveassetinfo?Id=<?php echo e($assetInfo->id); ?>">
                <?php echo e(csrf_field()); ?>

                    <input type="hidden" value="<?php echo e($assetInfo->id); ?>" name="id">
                    <div class="modal-body"> 
                                <table class="table table-responsive">
                                    <tbody>
                                         <tr>
                                            <td><label>Serial No.</label></td>
                                            <td><input type="text" class="form-control" value="<?php echo e($assetInfo->serial_no); ?>" name="serial_no" style="width: 50%;"></td>
                                        </tr>
                                        <tr>
                                            <td><label>Description</label></td>
                                            <td><input type="text" class="form-control" value="<?php echo e($assetInfo->description); ?>" name="desc" style="width: 50%;resize: none;"></td>
                                        </tr>
                                        <tr>
                                            <td><label>Remark</label></td>
                                            <td><input type="text" class="form-control" value="<?php echo e($assetInfo->remark); ?>" name="remark" style="width: 50%;resize: none;"></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td><button type="submit" class="btn btn-success" >save</button></td>
                                    </tbody>
                                </table>
                    </div>
            </form>
            <div class="modal-footer">
            </div>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
function getbrand(){
     var x = document.getElementById('num');
     var name = x.options[x.selectedIndex].value;
   
     $.ajax({
                    type:'GET',
                    url:"<?php echo e(URL::to('/')); ?>/getbrand",
                    async:false,
                    data:{name : name},
                    success: function(response)
                    {
                       
                         console.log(response);
                         for(var i=0;i<response.length;i++)
                        {
                           var text = response[i].provider;
                          
                         
                        }
                         document.getElementById('sim').value = text;   
                    }
                });
            }
function getname(){
        var x = document.getElementById('type');
        var name = x.options[x.selectedIndex].value;
                $.ajax({
                    type:'GET',
                    url:"<?php echo e(URL::to('/')); ?>/getname",
                    async:false,
                    data:{name : name},
                    success: function(response)
                    {
                        console.log(response);
                        
                        var ans = "<option value=''>--Select--</option>";
                        for(var i=0;i<response.length;i++)
                        {
                            ans += "<option value='"+response[i].id+"'>"+response[i].name+"</option>";
                        }
                        document.getElementById('mname').innerHTML = ans;
                    }
                });

            }
function getserial()
    {
        var y = document.getElementById("type");
        var serial = y.options[y.selectedIndex].value;
        var z = document.getElementById("mname").value;
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/getserial",
            async:false,
            data:{serial : serial, z: z},
            success: function(response)
            {

                
                 console.log(response);
                 
                 for(var i=0;i<response.length;i++)
                        {
                          var  text = "<option value='"+response[i].id+"'>"+response[i].sl_no+"</option>";
                        }
                  document.getElementById('number').innerHTML = text;

               
            }
        });    
    }
function getdesc(){

       var x = document.getElementById("type");
        var desc = x.options[x.selectedIndex].value;
        var z = document.getElementById("number").value;
       
                $.ajax({
                    type:'GET',
                    url:"<?php echo e(URL::to('/')); ?>/getdesc",
                    async:false,
                    data:{desc : desc,z: z},
                    success: function(response)
                    {

                         console.log(response);
                         
                         for(var i=0;i<response.length;i++)
                        {
                           var text = response[i].description;
                         
                        }
                         document.getElementById('desc').value = text;
                        
                    }
                });
            }
</script>       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>