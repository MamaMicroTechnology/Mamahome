<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-md-offset-4">
    <form method="POST" action="<?php echo e(URL::to('/')); ?>/postchangepassword">
        <?php echo e(csrf_field()); ?>

    <div class="panel panel-success">
        <div class="panel-heading">Please fill up the form
        <?php if(session('Error')): ?>
        <p class="alert-danger pull-right"> <?php echo e(session('Error')); ?></p>
        <?php endif; ?>
        </div>
        <div class="panel-body">
            <input type="password" name="oldPwd" required class="form-control" placeholder="Enter old password"><br>
            <input id="newPwd" type="password" name="newPwd" required class="form-control" placeholder="Enter new password"><br>
            <input id="reenter" name="newPwd2" oninput="pwdcheck()" type="password" required class="form-control" placeholder="Re-enter new password"><br>
            <div id="err"></div>
        </div>
        <div class="panel-footer">
            <input type="submit" value="Change Password" class="form-control btn btn-warning">
        </div>
    </div>
    </form>
</div>

<script type="text/javascript">
    function pwdcheck(){
        var newp = document.getElementById('newPwd').value;
        var repwd = document.getElementById('reenter').value;
        if(repwd == ""){
            document.getElementById('err').innerHTML = "";
        }
        if(newp != repwd){
            document.getElementById('err').innerHTML = "<p class=\"alert-danger\">Password didn't match</p>";
        }else{
            document.getElementById('err').innerHTML = "";
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.leheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>