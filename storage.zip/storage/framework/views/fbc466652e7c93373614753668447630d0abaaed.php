<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-md-offset-4">
	<div class="panel panel-default">
		<div class="panel-heading">Select Road</div>
	</br>
		<div class="container">
		<form method="get" action="<?php echo e(URL::to('/')); ?>/projectlist1">
		<div class="col-md-3">
		<input type="text" placeholder="phone number" class="form-control" name="phoneno" id="phoneno" maxlength="10"  minlength="10"></div>
		<div class="col-md-3"><button type="submit" class="btn btn-primary">fetch</button></div>
	</form>
	</div>


		
		<div class="panel-body">
			<ul class="list-group">
				<?php $__currentLoopData = $roads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $road): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($projectCount[$road] > 0 ): ?>
				<li class="list-group-item"><a href="<?php echo e(URL::to('/')); ?>/projectlist?road=<?php echo e($road); ?>"><?php echo e($road); ?> (<?php echo e($projectCount[$road]); ?> projects)</a></li>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>