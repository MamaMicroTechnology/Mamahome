<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 ">
             
            <div class="panel panel-default" style="border-color:#0e877f">
                <div class="panel-heading" style="background-color:#0e877f">Team Leader</div>
                <div class="panel-body">
                    
                     <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php 
                            $content = explode(" ",$team->name);
                          
                            $con = implode("",$content);
                        ?>
                        <a id="<?php echo e($con); ?>" class="list-group-item" href="#"><?php echo e($team->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <iframe class="col-md-9 img img-thumbnail" style="height: 600px;border-color: #0e877f" id="disp"></iframe>
        <!-- <div class="col-md-10" id="disp">

        </div> -->
    </div>
</div>

<script src="phoneno-all-numeric-validation.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php 
                            $content = explode(" ",$team->name);
                            $con = implode("",$content);
                        ?>
<script type="text/javascript">            
$(document).ready(function () {
	
    $("#<?php echo e($con); ?>").on('click',function(){
        // $(document.body).css({'cursor' : 'wait'});
        var url = 
        $('#disp').attr('src',"<?php echo e(URL::to('/')); ?>/ateam/"+encodeURIComponent("<?php echo e($team->name); ?>"));
        $("#disp2").load("<?php echo e(URL::to('/')); ?>/ateam/"+encodeURIComponent("<?php echo e($team->name); ?>"), function(responseTxt, statusTxt, xhr){
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
        // $(document.body).css({'cursor' : 'default'});
    });
});



</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>