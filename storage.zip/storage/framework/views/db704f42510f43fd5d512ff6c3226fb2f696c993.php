<?php $__env->startSection('content'); ?>

<div class="col-md-4" style="overflow-y:scroll; height:570px; max-height:570px">
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading text-center">
                <b style="color:white">Sales Report</b>
            </div>
            <div class="panel-body">
				<?php if(Auth::user()->department_id != 1): ?>
            	<form method="GET" action="<?php echo e(URL::to('/')); ?>/salesreports">
				<?php else: ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/tlsalesreports">
				<?php endif; ?>
                    <table class="table table-responsive">
	                    <tbody>
	                        <tr>
	                            <td>Select Sales Employee</td>
	                        </tr>
                            <tr>
                                <td>
                                    <select required name="se" class="form-control" id="selectle">
                                        <option disabled selected value="">(-- SELECT SE --)</option>
                                        <option value="ALL">All Sales Engineers</option>
                                        <?php if(Auth::user()->group_id != 22): ?>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(isset($_GET['se']) ? $_GET['se'] == $list->employeeId ? 'selected' : '' : ''); ?>  value="<?php echo e($list->employeeId); ?>"><?php echo e($list->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(isset($_GET['se']) ? $_GET['se'] == $user->employeeId ? 'selected' : '' : ''); ?>  value="<?php echo e($user->employeeId); ?>"><?php echo e($user->name); ?></option>
    	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
	                                </select>
	                            </td>
	                        </tr>
	                        <tr>
	                            <td>Select From Date</td>
	                        </tr>
	                        <tr>
	                            <td>
	                                <input value="<?php echo e(isset($_GET['fromdate']) ? $_GET['fromdate'] : ''); ?>" type="date" placeholder= "From Date" class="form-control" id="fromdate" name="fromdate" />
	                            </td>
	                        </tr>
	                        <tr>
	                            <td>Select To Date</td>
	                        </tr>
	                        <tr>
	                            <td>
	                                <input value="<?php echo e(isset($_GET['todate']) ? $_GET['todate'] : ''); ?>" type="date"  placeholder= "To Date" class="form-control" id="todate" name="todate" />
	                            </td>
	                        </tr>
	                        <tr class="text-center">
	                            <td>
	                                <button class="btn bn-md btn-success" style="width:100%">Get Date Range Details</button>
	                            </td>
	                        </tr>
	                    </tbody>
	                </table>
            	</form>
            </div>
        </div>
        <div class="panel panel-default" styke="border-color:green">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report (Today)</b>
            </div>
            <div class="panel-body" style="overflow-x: scroll;">
                <table class="table table-striped" border="1">
                	<tr>
                		<th>Name</th>
                    <?php if(Auth::user()->group_id != 22): ?>
                		<!-- <th>Ward</th> -->
                    <?php endif; ?>
                		<th>Calls</th>
                		<th>Fake</th>
                		<th>Genuine</th>
                		<th>Initiated</th>
                	</tr>
                       <?php if(Auth::user()->group_id != 22): ?>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td style="font-size: 10px; text-align: center;"><?php echo e($user->name); ?></td>
                       <!--  <td style="font-size: 10px; text-align: center;"><?php echo e($user->sub_ward_name); ?></td> -->
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['calls']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['fake']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['genuine']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['initiated']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                     <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['calls']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['fake']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['genuine']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['initiated']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

<div class="col-md-8">
    <div class="panel panel-primary" style="overflow-x:scroll">
        <div class="panel-heading" id="panelhead">
            <label>
            	Daily Updating For The Date : <b><?php echo e(date('d-m-Y',strtotime($date))); ?> <?php echo e(isset($_GET['todate']) && $_GET['todate'] != null ? " to ".date('d-m-Y',strtotime($_GET['todate'])) : ''); ?></b>
            	&nbsp;&nbsp;&nbsp;&nbsp;
            	No Of Udated Projects: <b><?php echo e($projectsCount); ?></b>
            	&nbsp;&nbsp;&nbsp;&nbsp;
            	Sales Engineer :
            		
            </label>
            <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button>
        </div>
        <div class="panel-body" style="overflow-y:scroll; height:500px; max-height:500px">
            <table class='table table-responsive table-striped' style="color:black" border="1">
                <thead>
                    <tr>
                        <th style="text-align:center">Subward Number</th>
                        <th style="text-align:center">Project-ID</th>
                        <th style="text-align:center">Quality</th>
                        <th style="text-align:center" >Updater</th>
                        <th style="text-align:center">Followup</th>
                       
                    </tr>
                </thead>
                <tbody id="mainPanel">
                	<?php for($i = 0; $i<count($projectIds);$i++): ?>
                     
                       <tr>
                        <td style="text-align:center">
                        <a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($projectIds[$i]['projectId']); ?> && subward=<?php echo e($projectIds[$i]['sub_ward_name']); ?>" data-toggle="tooltip" data-placement="top" title="click here to view map" class="red-tooltip" target="_blank"><?php echo e($projectIds[$i]['sub_ward_name'] != null ? $projectIds[$i]['sub_ward_name'] : ''); ?>

                                    </a></td>
                        <td style="text-align:center">
                        	<a href="<?php echo e(URL::to('/')); ?>/admindailyslots?projectId=<?php echo e($projectIds[$i]['projectId']); ?>&&lename=<?php echo e($projectIds[$i]['updater']); ?>"><?php echo e($projectIds[$i]['projectId']); ?></a>
                        </td>
                        <td style="text-align:center" class="<?php echo e(isset($_GET['se']) ? 'hidden' : ''); ?>"><?php echo e($projectIds[$i]['updater']); ?></td>
                        <td style="text-align:center"><?php echo e($projectIds[$i]['quality']); ?></td>
                        <td style="text-align:center"><?php echo e($projectIds[$i]['caller']); ?></td>
                        
                    </tr>
                 
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>