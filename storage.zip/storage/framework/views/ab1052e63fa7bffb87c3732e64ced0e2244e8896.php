<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-9 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading text-center" ><b>Late Logins</b></div>
            <div class ="panel-body">

                       
                       <table class="table table-hover">
                           <thead>
                               <th>Name</th>
                               <th>Login Time</th>
                               <th>Logout Time</th>
                               <th>Late Login Remark</th>
                               <th>Action</th>
                           </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                    <td><?php echo e($user->name); ?></td>
           
                                    <td><?php echo e($user->logintime); ?></td>
                                    <td><?php echo e($user->logout != null ? $user->logout : " "); ?></td>
                                    <td><?php echo e($user->remark); ?></td>
                                    
                                        <?php if( $user->tlapproval == "Pending" ): ?>
                                        <td>
                                        <div class="btn-group">
                                            <form action="<?php echo e(URL::to('/')); ?>/approve" method="post">
                                                 <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($user->user_id); ?>">
                                            <button type="submit" class="btn btn-success btn-sm" style="width:90%;">
                                                Approve
                                            </button>
                                            </form>
                                            <form action="<?php echo e(URL::to('/')); ?>/reject" method="post">
                                                 <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($user->user_id); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" style="width:90%;margin-top:-81%;margin-left:90%;">
                                                Reject
                                            </button>
                                        </form>
                                        </div>
                                        </td>
                                        <?php else: ?>
                                        <td style="padding-right :60px;"><?php echo e($user->tlapproval); ?></td>
                                        <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                       </table>
            </div>
        </div>
    </div>
</div>

<?php if(session('Success')): ?>
<script>
    swal("success","<?php echo e(session('Success')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('Success')): ?>
<script>
    swal("error","<?php echo e(session('error')); ?>","error");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>