<?php
    $user = Auth::user()->group_id;
    $ext = ($user == 6? "layouts.leheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
     
      <table class="table" style="width:100%;"><center><span style="background-color:#9e9e9e;width:60%; color:white;border: 1px solid gray;padding:5px;border-radius: 5px;">No Of project :&nbsp;&nbsp;<?php echo e($projectlist1); ?></span></center>
        <thead>
          <th>Project Name</th>
          <th>Project Id</th>
          <th>Address</th>
          <th>Status</th>
          <th>Procurement Name</th>
          <th>Procurement Contact No.</th>
          <th>Material Calculation</th>
          <th>Action</th>
          

        </thead>
        <tbody>

          <?php $__currentLoopData = $projectlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($project->quality == 'Unverified' || $project->quality == 'Genuine' || $project->quality == 'Fake' || $project->created_at >= $today ): ?>
            <tr>
              <td><?php echo e($project->project_name); ?></td>
              <td>
                <a target="_none" href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($project->project_id); ?>"><?php echo e($project->project_id); ?></a>
              </td>
              <td style="width:40%;">
                <a href="https://www.google.com/maps/place/<?php echo e($project->siteaddress != null ? $project->siteaddress->address  : ''); ?>/{{ $project->siteaddress != null ? $project->siteaddress->latitude : '' }},<?php echo e($project->siteaddress != null ? $project->siteaddress->longitude : ''); ?>"><?php echo e($project->siteaddress != null ? $project->siteaddress->address : ''); ?></a>
              </td>
              <td><?php echo e($project->project_status); ?></td>
              <td><?php echo e($project->procurementdetails != null ? $project->procurementdetails->procurement_name : ''); ?></td>
              <td><?php echo e($project->procurementdetails != null ? $project->procurementdetails->procurement_contact_no : ''); ?></td>
              <td>
                <a style="background-color:#9e9e9e;color:white;" href="<?php echo e(URL::to('/')); ?>/viewProjects?id=<?php echo e($project->project_id); ?> && no=<?php echo e($project->procurementdetails != null ? $project->procurementdetails->procurement_contact_no : ''); ?>" class="btn btn-success btn-xs" >View</a>
              </td>
              <td>
                <table class="table-group">
               <a href="<?php echo e(URL::to('/')); ?>/edit?projectId=<?php echo e($project->project_id); ?>" class="btn btn-primary btn-xs">Edit</a>
               <a href="<?php echo e(URL::to('/')); ?>/requirements?projectId=<?php echo e($project->project_id); ?>" class="btn btn-success btn-xs" style="margin-top:-49%;margin-left:50%;" >Add Enquiry</a>
             </table>
              </td>
            </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <?php if(isset($_GET['quality'])): ?>
      <?php echo e($projectlist->appends('quality',$_GET['quality'])->links()); ?>

      <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>