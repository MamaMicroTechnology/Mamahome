<h1>
    <center>
        <b>403 ACCESS DENIED</b><br>
        <small><a href="<?php echo e(URL()->previous()); ?>">Click here to go back</a></small>
    </center>
</h1>