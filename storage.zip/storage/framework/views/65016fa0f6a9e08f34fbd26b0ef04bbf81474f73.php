<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading " style="background-color: #3097d1;text-align: center;"><p style="color: white">
               Get Quotation For Manufacturers and Project
                 </p>
                  <a onclick="history.back(-1)" class="btn btn-default pull-right btn-xs" style="margin-top:-30px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;"></i></a>
            </div>
            <div class="panel-body" >
                
                <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojects">
                    <div class="col-md-12">
                        <div class="col-md-2">
                        <label>Project Type :</label>
                            <select required name="quot" onchange="getSubwards()" id="ward" class="form-control">
                                <option value="">--Select--</option>
                            <option value="Project">Project</option>
                            <option value="Manufacturer">Manufacturer</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                        <label>Search for Project ID/Manufacturere ID</label>
                            <input required type="text" name="id" placeholder="Enter Confirmed Project Id/Manufacturer Id" class="form-control">
                        </div>
                        <div class="col-md-2">
                        <label>Category</label>
                            <select id="categ" class="form-control" name="category">
                                <option value="">--Select--</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(isset($_GET['category']) ? $_GET['category'] == $category->category_name ? 'selected' : '' : ''); ?> value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                           
                            <button style="margin-top: 25px;" type="submit" class="btn btn-success" >Fetch</button>
                        </div>
                    </div>
                </form>
                 <div class="col-md-12 col-md-offset-9" style="margin-top: -35px;">
                <form method="GET" action="<?php echo e(URL::to('/')); ?>/getprojects">
                <div  class="col-md-2">    
                  <input required class="form-control" type="text" placeholder="Search Quotation Id" name="quotid">
                </div>
                  <button class="btn btn-success" type="submit"><i class="fa fa-search"></i></button>
                </form>
                </div><br>
                <table class="table table-hover" border="1"> 
                    <br><br><br><br>
                    <thead>
                   <?php if($id ): ?>
                    <tr  bgcolor="#c7e2de">
                       <td colspan="12" style="text-align: center">  <a target="_blank" href="<?php echo e(URL::to('/')); ?>/showThisProject?id=<?php echo e($id); ?>">
                                    <b>Project ID : <?php echo e($id); ?></b>
                                </a></td>
                    </tr>
                   <?php elseif($manu_id): ?>
                   <tr  bgcolor="#c7e2de">
                       <td colspan="12" style="text-align: center">  <a href="<?php echo e(URL::to('/')); ?>/updateManufacturerDetails?id=<?php echo e($manu_id); ?>">Manufacturer ID : <?php echo e($manu_id); ?>&nbsp;(<?php echo e($manu); ?>)
                       </a></td>
                   </tr>
                    <?php else: ?>

                   <?php endif; ?>
                    <?php if($enquiries != null): ?>
                        <tr>
                            <th style="text-align: center">Enquiry ID</th>
                            <th style="text-align: center">Requirement Date</th>
                            <!-- <th style="text-align: center">Enquiry Date</th> -->
                            <th style="text-align: center">Contact</th>
                            <th style="text-align: center">Product</th>
                            <th style="text-align: center">Quantity</th>
                            <th style="text-align: center">Total Quantity</th>
                            <th style="text-align: center">Initiator</th>
                            <th style="text-align: center">Status</th>
                            <th style="text-align: center">Remarks</th>
                            <th style="text-align: center">Quotation ID</th>
                            <th style="text-align: center">Quotation</th>
                            <th style="text-align: center">Action</th>
                        </tr>
                    </thead>
                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td style="text-align: center"><b><?php echo e($enquiry->id); ?></b>
                               </td>  
                            <td style="text-align: center"><?php echo e($newDate = date('d/m/Y', strtotime($enquiry->requirement_date))); ?></td>
                            <td style="text-align: center"><?php echo e($enquiry->procurementdetails != null ? $enquiry->procurementdetails->procurement_contact_no : ''); ?>

                             <?php echo e($enquiry->proc != null ? $enquiry->proc->contact :''); ?></td>
                            <td style="text-align: center;width: 30px;" ><b><?php echo e($enquiry->brand); ?></b><br><?php echo e($enquiry -> main_category); ?> (<?php echo e($enquiry->sub_category); ?>), <?php echo e($enquiry->material_spec); ?> <?php echo e($enquiry->product); ?> 
                            </td>
                            <td style="text-align: center">
                                <?php $quantity = explode(", ",$enquiry->quantity); ?>
                                <?php for($i = 0; $i<count($quantity); $i++): ?>
                                <?php echo e($quantity[$i]); ?><br>
                                <?php endfor; ?>
                            </td>
                            <td style="text-align: center"><?php echo e($enquiry->total_quantity); ?></td>
                            <td style="text-align: center"><?php echo e($enquiry->user != null ? $enquiry->user->name : ''); ?></td>
                            <td style="text-align: center">
                                <?php echo e($enquiry->status); ?>

                            </td>
                            <td style="text-align: center">
                                <?php echo e($enquiry->notes); ?>

                            </td>
                            <?php if($enquiry->quotation == null): ?>
                            <td>
                                Generate Quotation
                            </td>
                            <td><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#quotation<?php echo e($enquiry->id); ?><?php echo e($enquiry->manu_id); ?>">Get Quotation</button></td>
                            <?php else: ?>
                            <td>
                               <?php echo e($enquiry->quot != null ? $enquiry->quot->quotation_id : ""); ?></td>
                            <td><a type="button" href="<?php echo e(route('downloadquotation',['id'=>$enquiry->id,'manu_id'=>$enquiry->manu_id])); ?>" style="background-color: #42413b;color:white" class="btn btn-sm">QUOTATION</a></td>
                            <?php endif; ?>
                            <?php if($enquiry->quotation != null): ?>
                                <td><button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#quotation<?php echo e($enquiry->id); ?><?php echo e($enquiry->manu_id); ?>">Edit</button></td>
                            <?php else: ?>
                            <td>
                                <div>
                                 <a disabled type="button" class="btn btn-warning btn-sm" href="#">Edit</a>
                            </div>
                            </td>
                            <?php endif; ?>
                        </tr>   
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Modal -->
                        <div id="quotation<?php echo e($enquiry->id); ?><?php echo e($enquiry->manu_id); ?>" class="modal fade" role="dialog">
                          <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Quotation</h4>
                              </div>
                              <div class="modal-body">
                                    
                             <form action="<?php echo e(URL::to('/')); ?>/generatequotation?id=<?php echo e($enquiry->id); ?>&&manu_id=<?php echo e($enquiry->manu_id); ?>&&pid=<?php echo e($enquiry->project_id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($enq->id == $enquiry->id): ?>
                            <input type="hidden"  name="dtow1" id="dtow1<?php echo e($enq->id); ?>" value="">
                            <input type="hidden" name="dtow2" id="dtow2<?php echo e($enq->id); ?>" value="">
                            <input type="hidden" name="dtow3" id="dtow3<?php echo e($enq->id); ?>" value="">
                            <table class="table table-responsive table-striped" border="1">
                            <?php 
                                     $rec =count($enq->quotation);
                             ?>
                             <?php if($rec == 0): ?> 
                             <tr>
                                <td>Select Category : </td>
                                <td>
                                <select id="cat<?php echo e($enquiry->id); ?>" onchange="getsuppliername('<?php echo e($enquiry->id); ?>')" class="form-control" >
                                        <option>--Select Category--</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option <?php echo e(isset($_GET['category']) ? $_GET['category'] == $category->category_name ? 'selected' : '' : ''); ?> value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>  
                                CGST : <label id="g1<?php echo e($enquiry->id); ?>" class="alert-success"></label>%
                                SGST : <label id="g2<?php echo e($enquiry->id); ?>" class="alert-success"></label>%
                                </td> 
                            </tr>
                                <tr>
                                    <td>Description Of Goods : </td>
                                    <td><input type="text" name="description" value="<?php echo e($enq->brand); ?>" class="form-control"></td>
                                </tr>
                                <tr>
                                    <td>Ship Address : </td>
                                    <td><textarea required type="text" name="ship" class="form-control" style="resize: none;" rows="5">
                                        <?php if($enq->project_id == null): ?>
                                        <?php echo e($enq->manu != null ? $enq->manu->address : ''); ?>

                                        <?php else: ?>
                                        <?php echo e($enq->siteaddress != null ? $enq->siteaddress->address : ''); ?>

                                        <?php endif; ?>
                                    </textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Bill Address : </td>
                                    <td><textarea required type="text" class="form-control" name="bill" style="resize: none;" rows="5"><?php echo e($enq->billadress); ?>

                                    </textarea></td>
                                </tr>
                                <tr>
                                    <td> Total Quantity :</td>
                                    <td><input required type="number" class="form-control" name="quantity" placeholder="quantity" id="quan<?php echo e($enq->id); ?>"  value="<?php echo e($enq->total_quantity); ?>"></td>
                                </tr>
                                <tr>
                                    <td>Unit :</td>
                                    <td>
                                        <input type="radio" name="unit" value="tons" >Tons
                                        <input type="radio" name="unit" value="Bags" checked> Bags
                                    </td>
                                </tr>
                            <?php else: ?>
                            <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($quot->req_id == $enquiry->id): ?>
                                <tr>
                                    <td>Description Of Goods : </td>
                                    <td><input type="text" name="description" value="<?php echo e($quot->description); ?>" class="form-control"></td>
                                </tr>
                                <tr>
                                    <td>Ship Address: </td>
                                    <td><textarea required type="text" name="ship" class="form-control" style="resize: none;" rows="5">
                                        <?php echo e($quot->shipaddress); ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Bill Address : </td>
                                    <td><textarea required type="text" class="form-control" name="bill" style="resize: none;" rows="5"><?php echo e($quot->billaddress); ?>

                                    </textarea></td>
                                </tr>
                                <tr>
                                    <td> Total Quantity :</td>
                                    <td><input required type="number" class="form-control" name="quantity" placeholder="quantity" id="quan<?php echo e($enq->id); ?>"  value="<?php echo e($quot->quantity); ?>"></td>
                                </tr>
                           <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?> 
                                <tr>
                                    <td>Price(Per Unit) :</td>
                                    <td>
                                        <label class="alert-success pull-left">Enquiry Price : <?php echo e($enq->price != null ? $enq->price : ""); ?></label>
                                        <input required type="number" id="unit<?php echo e($enq->id); ?>"  class="form-control" name="price" placeholder="Unit Price" onkeyup="getcalculation('<?php echo e($enquiry->id); ?>')">
                                    </td>
                                </tr> 
                                <tr>
                                        <td>Unit Price without GST :</td>
                                        <td>&nbsp;&nbsp;&nbsp;RS.<label class=" alert-success pull-left" id="withoutgst<?php echo e($enq->id); ?>"></label>/-
                                           <input class="hidden" id="withoutgst1<?php echo e($enq->id); ?>" type="text"  name="withoutgst"  value="">
                                       </td>
                                 </tr>
                                 <tr>
                                        <td>Total Amount : </td>
                                        <td>
                                              &nbsp;&nbsp;&nbsp;RS .<label class=" alert-success pull-left" id="display<?php echo e($enq->id); ?>"></label>/-
                                              <input class="hidden" id="display1<?php echo e($enq->id); ?>" value="" name="display">
                                              <label class=" alert-success pull-right" id="lblWord<?php echo e($enq->id); ?>"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>CGST(14%) : </td>
                                        <td>
                                              &nbsp;&nbsp;&nbsp;CGST <label class=" alert-success pull-left" id="cgst<?php echo e($enq->id); ?>"></label>/-
                                              <input class="hidden" id="cgst1<?php echo e($enq->id); ?>" value="" name="cgst">

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>SGST(14%) : </td>
                                        <td>
                                             &nbsp;&nbsp;&nbsp;SGST <label class=" alert-success pull-left" id="sgst<?php echo e($enq->id); ?>"></label>/-
                                              <input class="hidden" id="sgst1<?php echo e($enq->id); ?>" value="" name="sgst">
                                        </td>
                                    </tr>
                                    <tr>
                                      <td>Total Tax :</td>
                                      <td>&nbsp;&nbsp;&nbsp;<label class=" alert-success pull-left" id="totaltax<?php echo e($enq->id); ?>"></label>Total
                                        <input class="hidden" id="totaltax1<?php echo e($enq->id); ?>" value="" name="totaltax">
                                        <label class=" alert-success pull-right" id="lblWord1<?php echo e($enq->id); ?>"></label>
                                      </td>
                                    </tr>
                                    <tr>
                                        <td>Amount (Including GST) :</td>
                                        <td>
                                              &nbsp;&nbsp;&nbsp;RS .<label class=" alert-success pull-left" id="withgst<?php echo e($enq->id); ?>"></label>/-
                                              <input class="hidden" type="text" id="withgst1<?php echo e($enq->id); ?>" name="withgst" value="">
                                              <label class=" alert-success pull-right" id="lblWord2<?php echo e($enq->id); ?>"></label>
                                        </td>
                                    </tr>         
                            </table>
                                <center><button type="submit" class="btn btn-sm btn-success" onclick="finalsubmit('<?php echo e($enq->id); ?>')">Confirm</button>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </form>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<script type="text/javascript">
    function NumToWord(inputNumber, outputControl,arg){
    var str = new String(inputNumber)
    var splt = str.split("");
    var rev = splt.reverse();
    var once = ['Zero', ' One', ' Two', ' Three', ' Four', ' Five', ' Six', ' Seven', ' Eight', ' Nine'];
    var twos = ['Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen'];
    var tens = ['', 'Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety'];

    numLength = rev.length;
    var word = new Array();
    var j = 0;

    for (i = 0; i < numLength; i++) {
        switch (i) {

            case 0:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = '' + once[rev[i]];
                }
                word[j] = word[j];
                break;

            case 1:
                aboveTens();
                break;

            case 2:
                if (rev[i] == 0) {
                    word[j] = '';
                }
                else if ((rev[i - 1] == 0) || (rev[i - 2] == 0)) {
                    word[j] = once[rev[i]] + " Hundred ";
                }
                else {
                    word[j] = once[rev[i]] + " Hundred and";
                }
                break;

            case 3:
                if (rev[i] == 0 || rev[i + 1] == 1) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if ((rev[i + 1] != 0) || (rev[i] > 0)) {
                    word[j] = word[j] + " Thousand";
                }
                break;

                
            case 4:
                aboveTens();
                break;

            case 5:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Lakh";
                }
                 
                break;

            case 6:
                aboveTens();
                break;

            case 7:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Crore";
                }                
                break;

            case 8:
                aboveTens();
                break;

            //            This is optional. 

            //            case 9:
            //                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
            //                    word[j] = '';
            //                }
            //                else {
            //                    word[j] = once[rev[i]];
            //                }
            //                if (rev[i + 1] !== '0' || rev[i] > '0') {
            //                    word[j] = word[j] + " Arab";
            //                }
            //                break;

            //            case 10:
            //                aboveTens();
            //                break;

            default: break;
        }
        j++;
    }

    function aboveTens() {
        if (rev[i] == 0) { word[j] = ''; }
        else if (rev[i] == 1) { word[j] = twos[rev[i - 1]]; }
        else { word[j] = tens[rev[i]]; }
    }

    word.reverse();
    var finalOutput = '';
    for (i = 0; i < numLength; i++) {
        finalOutput = finalOutput + word[i];
    }
    document.getElementById("dtow1"+arg).value = finalOutput;
    document.getElementById(outputControl).innerHTML = finalOutput;
}
function NumToWord1(inputNumber, outputControl,arg) {
    var str = new String(inputNumber)
    var splt = str.split("");
    var rev = splt.reverse();
    var once = ['Zero', ' One', ' Two', ' Three', ' Four', ' Five', ' Six', ' Seven', ' Eight', ' Nine'];
    var twos = ['Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen'];
    var tens = ['', 'Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety'];

    numLength = rev.length;
    var word = new Array();
    var j = 0;

    for (i = 0; i < numLength; i++) {
        switch (i) {

            case 0:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = '' + once[rev[i]];
                }
                word[j] = word[j];
                break;

            case 1:
                aboveTens();
                break;

            case 2:
                if (rev[i] == 0) {
                    word[j] = '';
                }
                else if ((rev[i - 1] == 0) || (rev[i - 2] == 0)) {
                    word[j] = once[rev[i]] + " Hundred ";
                }
                else {
                    word[j] = once[rev[i]] + " Hundred and";
                }
                break;

            case 3:
                if (rev[i] == 0 || rev[i + 1] == 1) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if ((rev[i + 1] != 0) || (rev[i] > 0)) {
                    word[j] = word[j] + " Thousand";
                }
                break;

                
            case 4:
                aboveTens();
                break;

            case 5:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Lakh";
                }
                 
                break;

            case 6:
                aboveTens();
                break;

            case 7:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Crore";
                }                
                break;

            case 8:
                aboveTens();
                break;

            //            This is optional. 

            //            case 9:
            //                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
            //                    word[j] = '';
            //                }
            //                else {
            //                    word[j] = once[rev[i]];
            //                }
            //                if (rev[i + 1] !== '0' || rev[i] > '0') {
            //                    word[j] = word[j] + " Arab";
            //                }
            //                break;

            //            case 10:
            //                aboveTens();
            //                break;

            default: break;
        }
        j++;
    }

    function aboveTens() {
        if (rev[i] == 0) { word[j] = ''; }
        else if (rev[i] == 1) { word[j] = twos[rev[i - 1]]; }
        else { word[j] = tens[rev[i]]; }
    }

    word.reverse();
    var finalOutput = '';
    for (i = 0; i < numLength; i++) {
        finalOutput = finalOutput + word[i];
    }
    document.getElementById("dtow2"+arg).value = finalOutput;
    document.getElementById(outputControl).innerHTML = finalOutput;
}
function NumToWord2(inputNumber, outputControl,arg){
    var str = new String(inputNumber)
    var splt = str.split("");
    var rev = splt.reverse();
    var once = ['Zero', ' One', ' Two', ' Three', ' Four', ' Five', ' Six', ' Seven', ' Eight', ' Nine'];
    var twos = ['Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen'];
    var tens = ['', 'Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety'];

    numLength = rev.length;
    var word = new Array();
    var j = 0;

    for (i = 0; i < numLength; i++) {
        switch (i) {

            case 0:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = '' + once[rev[i]];
                }
                word[j] = word[j];
                break;

            case 1:
                aboveTens();
                break;

            case 2:
                if (rev[i] == 0) {
                    word[j] = '';
                }
                else if ((rev[i - 1] == 0) || (rev[i - 2] == 0)) {
                    word[j] = once[rev[i]] + " Hundred ";
                }
                else {
                    word[j] = once[rev[i]] + " Hundred and";
                }
                break;

            case 3:
                if (rev[i] == 0 || rev[i + 1] == 1) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if ((rev[i + 1] != 0) || (rev[i] > 0)) {
                    word[j] = word[j] + " Thousand";
                }
                break;

                
            case 4:
                aboveTens();
                break;

            case 5:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Lakh";
                }
                 
                break;

            case 6:
                aboveTens();
                break;

            case 7:
                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
                    word[j] = '';
                }
                else {
                    word[j] = once[rev[i]];
                }
                if (rev[i + 1] !== '0' || rev[i] > '0') {
                    word[j] = word[j] + " Crore";
                }                
                break;

            case 8:
                aboveTens();
                break;

            //            This is optional. 

            //            case 9:
            //                if ((rev[i] == 0) || (rev[i + 1] == 1)) {
            //                    word[j] = '';
            //                }
            //                else {
            //                    word[j] = once[rev[i]];
            //                }
            //                if (rev[i + 1] !== '0' || rev[i] > '0') {
            //                    word[j] = word[j] + " Arab";
            //                }
            //                break;

            //            case 10:
            //                aboveTens();
            //                break;

            default: break;
        }
        j++;
    }

    function aboveTens() {
        if (rev[i] == 0) { word[j] = ''; }
        else if (rev[i] == 1) { word[j] = twos[rev[i - 1]]; }
        else { word[j] = tens[rev[i]]; }
    }

    word.reverse();
    var finalOutput = '';
    for (i = 0; i < numLength; i++) {
        finalOutput = finalOutput + word[i];
    }
    document.getElementById('dtow3'+arg).value = finalOutput;
    document.getElementById(outputControl).innerHTML = finalOutput;
}
function getcalculation(arg){
var x =document.getElementById('unit'+arg).value;
var y = document.getElementById('quan'+arg).value;
var withoutgst = (x /1.28);
var t = (withoutgst * y);
var f = Math.round(t);
var gst = (t * 14)/100;
var sgt = (t * 14)/100;
var withgst = (gst + sgt + t);
var final = Math.round(withgst);
var tt = (gst + sgt);
var totaltax = Math.round(tt);
document.getElementById('display'+arg).innerHTML = t;
document.getElementById('display1'+arg).value = f;
document.getElementById('cgst'+arg).innerHTML = gst;
document.getElementById('sgst'+arg).innerHTML = sgt;
document.getElementById('cgst1'+arg).value = gst;
document.getElementById('sgst1'+arg).value = sgt;
document.getElementById('withgst'+arg).innerHTML = withgst;
document.getElementById('withgst1'+arg).value = final;
document.getElementById('withoutgst'+arg).innerHTML = withoutgst;
document.getElementById('withoutgst1'+arg).value = withoutgst;
document.getElementById('totaltax'+arg).innerHTML = tt;
document.getElementById('totaltax1'+arg).value = totaltax;

}
function finalsubmit(arg){
  var input =  document.getElementById('display1'+arg).value;
  var output = document.getElementById('totaltax1'+arg).value;
  var inout = document.getElementById('withgst1'+arg).value;
  document.getElementById('display1'+arg).addEventListener("click", NumToWord(input,'lblWord'+arg,arg));
  document.getElementById('totaltax1'+arg).addEventListener("click", NumToWord1(output,'lblWord1'+arg,arg));
  document.getElementById('withgst1'+arg).addEventListener("click", NumToWord2(inout,'lblWord2'+arg,arg));
}
</script>
<script type="text/javascript">
function getsuppliername(arg) {
  var x = document.getElementById('cat'+arg);
  var name = x.options[x.selectedIndex].value;
  var x = arg;
  $.ajax({
                    type:'GET',
                    url:"<?php echo e(URL::to('/')); ?>/getgstvalue",
                    async:false,
                    data:{name : name , x : x},
                    success: function(response)
                    {    
                        var id = response[0]['id'];
                        var cgst = response[0]['gstvalue'][0]['cgst'];
                        var sgst = response[0]['gstvalue'][0]['sgst'];
                        document.getElementById('g1'+id).innerHTML = cgst;
                        document.getElementById('g2'+id).innerHTML = sgst;

                    }
                });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>