<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
<div class="panel panel-default" style="border-color:green">
<div class="panel-heading" style="background-color:green;font-weight:bold;font-size:1.3em;color:white;text-align: center;">Asset Acknowledgement Form</div>
<div class="panel-body">
	
		<center></center>
		<center>This form is an acknowledgement for MAMA HOME equipment use for Employees.</center>
		<br>
			 <table class="table table-responsive table-bordered"  align="center" style="width:45%;">
			 	<tbody>
			 		<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 		<tr>
                    <td><label>Name</label></td>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <td><label>Designation</label></td>
                    <td><?php echo e($user->group->group_name); ?></td>
                </tr>
                <tr>
                    <td><label>User-Id Of MMT</label></td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
			 		<tr>
			 			<td><label>Date of Joining</label></td>
			 			<td><?php echo e(date('d-m-Y' , strtotime($user->date_of_joining))); ?></td>
			 		</tr>
			 		<tr>
			 			<td><label>Contact Number</label></td>
			 			<td><?php echo e($user->contactNo); ?></td>
			 		</tr>
			 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 		<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 		<tr>
			 			<td><label>Asset</label></td>
			 			<td> <?php echo e($info->asset_type); ?></td>
			 		</tr>
			 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 	</tbody>
			 </table>
			 	
			 <p style="text-align: justify;">I, <?php echo e($user->name); ?>, understand the guidelines and policies for MAMA HOME equipment use.  I will only be using MAMA HOME assets for business purposes only.  Any software or hardware installed is required to have prior approval before installation.  Upon my termination with MAMA HOME (whether voluntary or involuntary), I will return all above-mentioned assets within 24 hours.  Failure to do so will result in a penalty. In addition, I acknowledge that I will not receive my last pay check, unless I return the above-mentioned assets.  Should final pay check not cover expenses, MAMA HOME retains the right to file for reimbursement through court proceedings.</p>
			 
			 <br>
			 <br>
			<table class="table table-responsive">
			<tbody>
			 		
			 		
			 		<tr>
			 			<td><img style=" height:50px; width:100px;" src="public/empsignature/<?php echo e($info->emp_signature); ?>" ></td>
			 			<td style="text-align: right;"><img style=" height:50px; width:100px;" src="public/managersignature/<?php echo e($info->manager_signature); ?>" ></td>
			 		</tr>
			 	
				 	<tr>
				 		<td>Employee Signature:</td>
				 		<td style="text-align: right;">Signature Aproved By:</td>

			 		</tr>
			 </tbody>
			 </table>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>