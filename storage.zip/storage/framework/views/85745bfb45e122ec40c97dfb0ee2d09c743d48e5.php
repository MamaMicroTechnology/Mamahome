<?php $__env->startSection('content'); ?>
<div class="col-md-6 col-md-offset-3">
	<div class="panel panel-default">
		<div class="panel-heading">
			<?php if($loginTimes): ?>
			Report of <?php echo e($username->name); ?> (<?php echo e(date('d-M-Y',strtotime($loginTimes->logindate))); ?>)
			<?php else: ?>
			User may have failed to log in today
			<?php endif; ?>
			<?php if(session('Error')): ?>
			<div class="alert-danger pull-right"><?php echo e(session('Error')); ?> </div>
			<?php endif; ?>
		</div>
		<div class="panel-body">
			<div class="row">
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/viewReport">
				    <input type="hidden" name="UserId" value="<?php echo e($username->id); ?>">
					<div class="col-md-3">
						Choose Date:
					</div>
					<div class="col-md-4">
						<input required type="date" name="date" class="form-control input-sm">
					</div>
					<div>
						<button type="submit">Submit</button>
					</div>
				</form>
			</div>
			<br>
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<form method="POST" action="<?php echo e(URL::to('/')); ?>/markLeave">
						<?php echo e(csrf_field()); ?>

						<input required type="date" name="date" class="form-control input-sm">
						<input type="hidden" name="id" value="<?php echo e($username->id); ?>">
						<div class="radio">
							<label><input name="leave" type="radio" value="Leave">Leave</label>
						</div><div class="radio">
							<label><input name="leave" type="radio" value="Half Day">Half Day</label>
						</div>
						<input type="submit" value="Save" class="form-control btn btn-success">
					</form>
				</div>
			</div>
			<br>
			<?php if($loginTimes): ?>
			<label>Morning</label>
			<table class="table">
				<tr>
					<td>Login Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->loginTime); ?></td>
				</tr>
				<tr>
					<td>Login Time to ward</td>
					<td>:</td>
					<td>
						<?php if($loginTimes->login_time_in_ward != NULL): ?>
						<?php echo e($loginTimes->login_time_in_ward); ?>

						<?php else: ?>
						<form method="post" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addComment">
							<?php echo e(csrf_field()); ?>

						  <div class="input-group">
						    <input type="time" class="form-control" name="loginTimeInWard">
						    <div class="input-group-btn">
						      <button class="btn btn-default" type="submit">Submit</button>
						    </div>
						  </div>
						</form>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Logout Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->logoutTime); ?></td>
				</tr>
				<tr>
					<td>Allocated Ward</td>
					<td>:</td>
					<td><?php echo e($loginTimes->allocatedWard); ?></td>
				</tr>
				<tr>
					<td>First Listing Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->firstListingTime); ?></td>
				</tr>
				<tr>
					<td>First Update Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->firstUpdateTime); ?></td>
				</tr>
				<tr>
					<td>No. of projects listed <br> in the morning</td>
					<td>:</td>
					<td><?php echo e($loginTimes->noOfProjectsListedInMorning); ?></td>
				</tr>
				<tr>
					<td>No. of projects updated <br> in the morning</td>
					<td>:</td>
					<td><?php echo e($loginTimes->noOfProjectsUpdatedInMorning); ?></td>
				</tr>
				<tr>
					<td>Morning Remarks</td>
					<td>:</td>
					<td>
					<?php if($loginTimes->morningRemarks == NULL): ?>
					<form method="post" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/morningRemark">
						<?php echo e(csrf_field()); ?>

						<textarea required class="form-control" name="mRemark"></textarea><br>
						<button class="form-control" type="submit">Save</button>
					</form>
					<?php else: ?>
					    <form method="post" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/editMorningRemarks">
					        <?php echo e(csrf_field()); ?>

					    <textarea name="remark" id="mEdit" class="hidden"><?php echo nl2br($loginTimes->morningRemarks); ?></textarea>
						<p id="mCurrent"><?php echo nl2br($loginTimes->morningRemarks); ?></p>
					    <input id="mSaveBtn" type="submit" value="Save" class="hidden">
					    </form>
						<!--<button id="mEditBtn" class="btn btn-primary" onclick="editMorning()">Edit</button>-->
					<?php endif; ?>
					</td>

				</tr>
				<tr>
					<td>Morning Meter Image</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->morningMeter != NULL): ?>
						<img src="<?php echo e(URL::to('/')); ?>/public/meters/<?php echo e($loginTimes->morningMeter); ?>" height="100" width="200" class="img img-thumbnail">
						<a href="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/deleteReportImage" class="btn btn-danger">Delete</a>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Morning Meter Reading</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->morningMeter != NULL): ?>
					    <?php echo e($loginTimes->gtracing); ?>

						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Morning Data Image</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->morningData != NULL): ?>
					    <img src="<?php echo e(URL::to('/')); ?>/public/data/<?php echo e($loginTimes->morningData); ?>" height="100" width="200" class="img img-thumbnail">
					    <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/deleteReportImage2" class="btn btn-danger">Delete</a>
					    <?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Morning Data Image</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->morningData != NULL): ?>
					    <?php echo e($loginTimes->afternoonData); ?>

					    <?php endif; ?>
					</td>
				</tr>
				<!--<tr>-->
				<!--	<td>Morning Google tracing image</td>-->
				<!--	<td>:</td>-->
				<!--	<td>-->
				<!--		<?php if($loginTimes->gtracing == NULL): ?>-->
				<!--		<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addTracing" enctype="multipart/form-data">-->
				<!--			<input type="file" class="form-control" accept="image/*" onchange="this.form.submit()" name="gTracing">-->
				<!--			<?php echo e(csrf_field()); ?>-->
				<!--		</form>-->
				<!--		<?php else: ?>-->
				<!--		<img src="<?php echo e(URL::to('/')); ?>/public/uploads/<?php echo e($loginTimes->gtracing); ?>" height="100" width="200" class="img img-thumbnail">-->
				<!--		<?php endif; ?>-->
				<!--	</td>-->
				<!--</tr>-->
				<tr>
					<td>Morning KM from google Home to Ward</td>
					<td>:</td>
					<td>
						<?php if($loginTimes->kmfromhtw == NULL): ?>
						<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addComment">
							<?php echo e(csrf_field()); ?>

						  <div class="input-group">
						    <input type="text" class="form-control" name="googleKm" placeholder="KM from google">
						    <div class="input-group-btn">
						      <button class="btn btn-default" type="submit">Submit</button>
						    </div>
						  </div>
						</form>
						<?php else: ?>
						<?php echo e($loginTimes->kmfromhtw); ?>

						<?php endif; ?>
					</td>
				</tr>
			</table>
			<label>Evening</label>
			<table class="table">
				<tr>
					<td>Evening Meter Image</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->eveningMeter != NULL): ?>
					    <img src="<?php echo e(URL::to('/')); ?>/public/meters/<?php echo e($loginTimes->eveningMeter); ?>" height="100" width="200" class="img img-thumbnail">
					<a href="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/deleteReportImage5" class="btn btn-danger">Delete</a>
					<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Evening Data Image</td>
					<td>:</td>
					<td>
					    <?php if($loginTimes->eveningData != NULL): ?>
					    <img src="<?php echo e(URL::to('/')); ?>/public/data/<?php echo e($loginTimes->eveningData); ?>" height="100" width="200" class="img img-thumbnail">
					<a href="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/deleteReportImage6" class="btn btn-danger">Delete</a>
					    <?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Evening Ward Tracing Image (Hello Tracks)</td>
					<td>:</td>
					<td>
						<?php if($loginTimes->evening_ward_tracing_image == NULL): ?>
						<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addTracing" enctype="multipart/form-data">
							<input type="file" class="form-control" accept="image/*" onchange="this.form.submit()" name="ewTracingI">
							<?php echo e(csrf_field()); ?>

						</form>
						<?php else: ?>
						<img src="<?php echo e(URL::to('/')); ?>/public/uploads/<?php echo e($loginTimes->evening_ward_tracing_image); ?>" height="100" width="200" class="img img-thumbnail">
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Evening Km From tracking software</td>
					<td>:</td>
					<td>
						<?php if($loginTimes->evening_km_from_tracking == NULL): ?>
						<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addComment">
							<?php echo e(csrf_field()); ?>

						  <div class="input-group">
						    <input type="text" class="form-control" name="ekmfromts" placeholder="KM from google">
						    <div class="input-group-btn">
						      <button class="btn btn-default" type="submit">Submit</button>
						    </div>
						  </div>
						</form>
						<?php else: ?>
						<?php echo e($loginTimes->evening_km_from_tracking); ?>

						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td>Evening Tracking image from ward to home</td>
					<td>:</td>
					<td><?php if($loginTimes->tracing_image_w_to_h == NULL): ?>
						<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addTracing" enctype="multipart/form-data">
							<input type="file" class="form-control" accept="image/*" onchange="this.form.submit()" name="TracingIWtH">
							<?php echo e(csrf_field()); ?>

						</form>
						<?php else: ?>
						<img src="<?php echo e(URL::to('/')); ?>/public/uploads/<?php echo e($loginTimes->tracing_image_w_to_h); ?>" height="100" width="200" class="img img-thumbnail">
						<?php endif; ?></td>
				</tr>
				<tr>
					<td>Evening Km from ward to home</td>
					<td>:</td>
					<td>
						<?php if($loginTimes->km_from_w_to_h == NULL): ?>
						<form method="POST" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/addComment">
							<?php echo e(csrf_field()); ?>

						  <div class="input-group">
						    <input type="text" class="form-control" name="ekmwth" placeholder="KM from google">
						    <div class="input-group-btn">
						      <button class="btn btn-default" type="submit">Submit</button>
						    </div>
						  </div>
						</form>
						<?php else: ?>
						<?php echo e($loginTimes->km_from_w_to_h); ?>

						<?php endif; ?>	
					</td>
				</tr>
				<tr>
					<td>Last Listing Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->lastListingTime); ?></td>
				</tr>
				<tr>
					<td>Last Update Time</td>
					<td>:</td>
					<td><?php echo e($loginTimes->lastUpdateTime); ?></td>
				</tr>
				<tr>
					<td>Total Projects Listed today</td>
					<td>:</td>
					<td><?php echo e($loginTimes->TotalProjectsListed); ?></td>
				</tr>
				<tr>
					<td>Total Projects Updated today</td>
					<td>:</td>
					<td><?php echo e($loginTimes->totalProjectsUpdated); ?></td>
				</tr>
					<tr>
						<td>Logout Time</td>
						<td>:</td>
						<td>
							<?php if($loginTimes->logoutTime != 'N/A'): ?>
								<?php echo e($loginTimes->logoutTime); ?>

							<?php else: ?>
								<form method="POST" action="<?php echo e(URL::to('/')); ?>/updateLogoutTime">
									<?php echo e(csrf_field()); ?>								
									<input type="hidden" value="<?php echo e($loginTimes->id); ?>" name="id">
									<div class="input-group">
									<input type="time" name="logoutTime" class="form-control">
									<div class="input-group-btn">
									<input type="submit" value="save" class="btn btn-primary">
									</div></div>
								</form>
							<?php endif; ?>
						</td>
					</tr>
				</table>
				<?php if($loginTimes->eveningRemarks == NULL): ?>
    				<form method="post" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/eveningRemark">
				<?php else: ?>
					<form method="post" action="<?php echo e(URL::to('/')); ?>/<?php echo e($loginTimes->id); ?>/editEveningRemarks">
				<?php endif; ?>
				<table class="table table-hover">
    				<tr>
    					<td>Total Kilometers By LE</td>
    					<td>:</td>
    					<td>
    					    <?php if( $loginTimes->afternoonMeter - $loginTimes->gtracing <= 0): ?>
    					        <?php echo e($total = ($loginTimes->afternoonMeter - $loginTimes->gtracing) * -1); ?>

    					    <?php else: ?>
    					        <?php echo e($total = $loginTimes->afternoonMeter - $loginTimes->gtracing); ?>

    					    <?php endif; ?>
    					</td>
    				</tr>
    				<tr>
    					<td>Total Kilometers From TL</td>
    					<td>:</td>
    					<td>
    					    <?php if($loginTimes->total_kilometers != NULL): ?>
    					    <?php echo e($loginTimes->total_kilometers); ?>

    					    <input id="total" type="text" name="totalKm" value="<?php echo e($loginTimes->total_kilometers); ?>" class="hidden">
    					    <?php else: ?>
					        <input id="total" type="text" name="totalKm" value="<?php echo e($loginTimes->total_kilometers); ?>" class="form-control">
					        <?php endif; ?>
    					</td>
    				</tr>
    				<tr>
    					<td>Evening Remarks</td>
    					<td>:</td>
    					<td>
					        <?php echo e(csrf_field()); ?>

					        <?php if($loginTimes->eveningRemarks != NULL): ?>
					        <p id="eCurrent"><?php echo nl2br($loginTimes->eveningRemarks); ?></p>
					         <textarea name="eRemark" rows="3" id="eEdit" class="hidden"><?php echo nl2br($loginTimes->eveningRemarks); ?></textarea>
					        <?php else: ?>
    					    <textarea name="eRemark" rows="3" id="eEdit" class="form-control"><?php echo nl2br($loginTimes->eveningRemarks); ?></textarea>
    					    <?php endif; ?>
    					</td>
    				</tr>
    			</table>
    		    <!--<button type="button" id="eEditBtn" onclick="editEvening()" class="<?php echo e($loginTimes->eveningRemarks != NULL ? 'form-control': 'hidden'); ?>">Edit</button><br>-->
				<input id="eSaveBtn" type="submit" value="Save" class="btn btn-primary form-control">
		    </form>
		</div>
		<?php endif; ?>
	</div>
</div>

<script>
    function editMorning(){
        if(document.getElementById("mEdit").className == "form-control"){
            document.getElementById("mEdit").className = "hidden";
            document.getElementById("mCurrent").className = "";
            document.getElementById("mEditBtn").innerHTML = "Edit";
            document.getElementById("mSaveBtn").className = "hidden";
        }else{
            document.getElementById("mEdit").className = "form-control";
            document.getElementById("mCurrent").className = "hidden";
            document.getElementById("mEditBtn").innerHTML = "Cancel";
            document.getElementById("mSaveBtn").className = "form-control";
        }
    }
    function editEvening(){
        if(document.getElementById("eEdit").className == "form-control"){
            document.getElementById("eEdit").className = "hidden";
            document.getElementById("eCurrent").className = "";
            document.getElementById("eEditBtn").innerHTML = "Edit";
        }else{
            document.getElementById("eEdit").className = "form-control";
            document.getElementById("eCurrent").className = "hidden";
            document.getElementById("eEditBtn").innerHTML = "Cancel";
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>