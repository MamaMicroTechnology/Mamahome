<?php $__env->startSection('content'); ?>
 <div class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading" style="color:white;font-size: 15px;"> Ward Map
                    <?php if(session('Error')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('Error')); ?></div>
                    <?php endif; ?>
                    <a  href="javascript:history.back()" class="btn btn-sm btn-danger pull-right">Back</a>    

                </div>
                <div class="panel-body">
                	   <div id="map" style="width:1000px;height:500px"></div>
                </div>
               </div>
             </div>
          </div>
       </div>
<script type="text/javascript" scr="https://maps.google.com/maps/api/js?sensor=false"></script>
<?php if(count($projects) == 0): ?>
<script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    var newpath = [];
    <?php if($subwardMap != "None"): ?>
    var latlng = "<?php echo e($subwardMap->lat); ?>";
    var col = "<?php echo e($subwardMap->color); ?>";
    <?php else: ?>
    var latlng = "";
    var col = "456369"
    <?php endif; ?>
    var places = latlng.split(",");
    for(var i=0;i<places.length;i+=2){
          newpath.push({lat: parseFloat(places[i]), lng: parseFloat(places[i+1])});
    }

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 16,
      center: new google.maps.LatLng(12.9716, 77.5946),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();
   
    var marker, i;
    var subward = new google.maps.Polygon({
        paths:  newpath,
        strokeColor: '#'+col,
        strokeOpacity: 1,
        strokeWeight: 2,
        fillColor: '#'+col,
        fillOpacity: 0.9
      });
  subward.setMap(map);
  }
  </script>
<?php else: ?>
  <script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    var newpath = [];
    <?php if($subwardMap != "None"): ?>
    var latlng = "<?php echo e($subwardMap->lat); ?>";
    var col = "<?php echo e($subwardMap->color); ?>";
    <?php else: ?>
    var latlng = "";
    var col = "456369"
    <?php endif; ?>
    var places = latlng.split(",");
    for(var i=0;i<places.length;i+=2){
          newpath.push({lat: parseFloat(places[i]), lng: parseFloat(places[i+1])});
    }
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      locations.push(["<a href=\"https://maps.google.com/?q=<?php echo e($project->address); ?>\"><?php echo e($project->project_id); ?> <?php echo e($project->project_name); ?>,<?php echo e($project->address); ?></a>",<?php echo e($project->latitude); ?>, <?php echo e($project->longitude); ?>]);
      created.push("<?php echo e($project->created_at); ?>");
      updated.push("<?php echo e($project->updated_at); ?>");
      status.push("<?php echo e($project->status); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15.5,
      center: new google.maps.LatLng(locations[0][1], locations[0][2]),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) { 
    if(created[i] == updated[i]){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
      });
    }else if(status[i] == "Order Confirmed"){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'
      });
    }else{
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
      });
    }

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
    if(newpath.length > 1){
    
      var subward = new google.maps.Polygon({
          paths: newpath,
          strokeColor: '#'+col,
          strokeOpacity: 1,
          strokeWeight: 2,
          fillColor: '#'+col,
          fillOpacity: 0.4
        });
    subward.setMap(map);
    }
  }
  </script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU&callback=myMap"></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>