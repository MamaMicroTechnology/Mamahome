
<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
  
  <link rel="stylesheet" href="alert/dist/sweetalert.css">
 <script src="alert/dist/sweetalert-dev.js"></script>
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<title></title>
</head>
<body>
<div class="topnav">
  <a class="active" href="<?php echo e(URL::to('/')); ?>/home" style="font-size:1.1em;font-family:Times New Roman;margin-left:15%;">Home</a>
</div><br><br>
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color:#e7e7e7;
  margin-right: 0;
margin-left: 0;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  
  color: black;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media  screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
<div class="container-fluid">
        <div class="col-md-12">
            <div class="panel panel-default" style="border-color:#f4811f">
                <div class="panel-heading text-center" style="background-color:#f4811f"><b style="color:white;font-size:1.3em">Assign Ward To Team Leaders Of Sales And Operation </b>
                    <?php if(session('Error')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('Error')); ?></div>
                    <?php endif; ?>
                  
                 

                <a  href="javascript:history.back()" class="btn btn-sm btn-danger pull-right">Back</a>    
                </div>
                <div class="panel-body">  
    <form method="POST" id="assign" action="<?php echo e(url('/tlward')); ?>" >
    <?php echo e(csrf_field()); ?>

    <input type="hidden" id="username" name="user_id">
    <input type="hidden" id="username1" name="group_id">

    <select  name="ward_id[]" id="dateassigned" class="hidden" required >
                              <option value="select">----------Select Ward------</option>
                            <?php $__currentLoopData = $ward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option <?php echo e($wards->id  ? 'selected' : ''); ?> value="<?php echo e($wards->id); ?>">      <?php echo e($wards->ward_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                            <select id="dateassigned1" name="framework[]" multiple class="form-control hidden" >
                             <?php $__currentLoopData = $user1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($users2->id); ?>"> <?php echo e($users2->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
    </form>
         <?php $i=1 ?>
         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <form method="POST" id="assign" action="<?php echo e(url('/tlward')); ?>" >
          <?php echo e(csrf_field()); ?>

               <div class="panel-body">
                <table class="table table-responsive table-striped table-hover">
                        <thead>
                             <th>No.</th>
                            <th>Team Leader Name</th>
                            <th>Assigned Ward </th>
                            <th>Assign Ward </th>
                            <th>Select Users</th>
                            <th>Assigned Users</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                           <tr>
                           <td><?php echo e($i++); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td >
                                <input type="hidden" id= "user<?php echo e($user->id); ?>" name="user_id" value="<?php echo e($user->id); ?>">
                                <input type="hidden" id= "user1<?php echo e($user->id); ?>" name="group_id" value="<?php echo e($user->group_id); ?>">
                                  <?php $__currentLoopData = $newwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($newward['tl_id'] == $user->id): ?>
                                            <?php $__currentLoopData = $newward['wardtl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wardstl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php echo e($wardstl['ward_name']); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                       <?php endif; ?>
                                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </td>
                            <td>
                            <select name="ward_id[]" id="date<?php echo e($user->id); ?>" class="form-control" multiple>
                              <option value="">----Select Ward----</option>
                            <?php $__currentLoopData = $ward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($wards->id); ?>"> <?php echo e($wards->ward_name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                             
                            </td>
                            
                          <td>
                            <div class="form-group">
                             <select id="menu<?php echo e($user->id); ?>" name="framework[]" multiple class="form-control"  required>
                             <?php $__currentLoopData = $user1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option  value="<?php echo e($users2->id); ?>"> <?php echo e($users2->name); ?> [<?php echo e($users2->dept_name); ?>]</option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                             </div>
                            </td>
                            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal<?php echo e($user->id); ?>">
                                       Assigned Users
                            </button></td>
                            <td>
                              <input id="this" type="button" class="btn btn-success pull-left" onclick="assigntl('<?php echo e($user->id); ?>')" value="Assign">
                              
                            </td>
                          </tr>         
                       </tbody>
                </table>
            </div>
    </form>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__currentLoopData = $newUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal" id="myModal<?php echo e($newUser['tl_id']); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header" style="background-color:#f4811f">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style="color:white;">Assigned Users</h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
          <table class="table table-responsive table-striped table-hover">
                        <thead>
                          <tr>
                            <th style="color:#337ab7;size:20px;">Name</th>
                            <th style="color:#337ab7;size:20px;">Department</th>
                          </tr>
                        </thead>
                        <tbody>

                <?php $__currentLoopData = $newUser['employees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                           <th><?php echo e($employees['name']); ?></th>
                            <?php $__currentLoopData = $user1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($employees['id'] == $users2->id): ?>
                            <th><?php echo e($users2->dept_name); ?></th>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                 </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
                 </table>

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
      <button class="btn btn-danger pull-left" onclick="confirmthis('<?php echo e($newUser['tl_id']); ?>')">Reset</button>
        <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
      </div>

    </div>
  </div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo e($users->links()); ?>


                  </div>
              </div>
          </div>
    
</div>
 </nav>
  
<script>
    function save(arg){
        document.getElementById('username').value = document.getElementById('user'+arg).value;
        document.getElementById('username1').value = document.getElementById('user1'+arg).value;

        document.getElementById('dateassigned').value = document.getElementById('date'+arg).value;
        document.getElementById('dateassigned1').value = document.getElementById('menu'+arg).value;
        var selected = document.getElementById('menu'+arg);
        alert(selected.selectedIndex);

        document.getElementById('assign').submit();
    }
</script>
<script>
  function confirmthis(arg)
    {
        var ans = confirm('Are You Sure You Want To Reset?');
        var id = arg;
        if(ans)
        {
                $.ajax({
                type: 'GET',
                url: "<?php echo e(URL::to('/')); ?>/deleteward",
                async: false,
                data:{id : id},
                success: function(response){
                    window.location.reload()
                }
            })
        }
    }
    function assigntl(arg){

        var input = document.getElementById('date'+arg).value;
        var input1 = document.getElementById('menu'+arg).value;
       
        if(input == ""){
         
          alert("You Have Not Selected Ward");
        }
        else if(input1 == ""){
          alert("You Have Not Selected Users");
        }
        else{
        
          document.getElementById('this').form.submit();
        }
    }
</script>
<script>
$(document).ready(function(){
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   $('#menu<?php echo e($user->id); ?>').multiselect({
      nonSelectedText: 'Select Users',
      enableFiltering: true,
      enableCaseInsensitiveFiltering: true,
      buttonWidth:'200px'
   });
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 });

$(document).ready(function(){
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   $('#date<?php echo e($user->id); ?>').multiselect({
      nonSelectedText: 'Select Ward',
      enableFiltering: true,
      enableCaseInsensitiveFiltering: true,
      buttonWidth:'200px'
   });
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 });
$(document).ready(function(){
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   $('#date3<?php echo e($user->id); ?>').multiselect({
      nonSelectedText: 'Select Ward',
      enableFiltering: true,
      enableCaseInsensitiveFiltering: true,
      buttonWidth:'200px'
   });
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 });
</script>

<script>
function checkall(arg){
var clist = document.getElementById('ward'+arg).getElementsByTagName('input');
  if(document.getElementById('check'+arg).checked == true){
    for (var i = 0; i < clist.length; ++i) 
    { 
      clist[i].checked = true; 
    }
  }else{
    for (var i = 0; i < clist.length; ++i) 
    { 
      clist[i].checked = false; 
    }
  }
}
</script>  
<?php if(session('success')): ?>
<script>
    swal("Success","<?php echo e(session('success')); ?>","success");
</script>
<?php endif; ?>
</body>
</html>


