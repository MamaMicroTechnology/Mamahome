<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      List of projects under you:<br>
      <table class="table">
        <thead>
          <th>Project_id</th>
          <th>sub_ward_id</th>
          <th>project_name</th>
          
        </thead>
        <tbody>
          <?php $__currentLoopData = $projectlist1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($project->project_id); ?></td>
              <td><?php echo e($project->sub_ward_id); ?></td>
              <td><?php echo e($project->project_name); ?></td>
             
             
            </tr>
           
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>