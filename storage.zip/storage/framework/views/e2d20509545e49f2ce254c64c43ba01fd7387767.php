<?php $__env->startSection('content'); ?>

  <?php if($ldate < $lodate): ?>
  <div>You are ahead of time.</div>
  <?php elseif($ldate > $outtime): ?>
  <div>You are done for today. Take a rest.</div>
  <?php else: ?>

<div class="container">
    <div class="row">
   
      <?php if($subwards): ?>
      <div class="col-md-3"> 
         You are in <?php echo e($subwards->sub_ward_name); ?><br><br>
        <?php if(Auth::user()->group_id == 6 && Auth::user()->department_id == 1): ?>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/listingEngineer">Add New Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/roads">Update Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/requirementsroads">Project Enquiry</a><br><br>
        <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/lcoorders">Orders</a><br><br>
        <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/public/subWardImages/<?php echo e($subwards->sub_ward_image); ?>"> SubWard image</a><br><br>
        
          <?php if( $totalprojects !=  $update): ?>
           <span class="">  <a  class="btn btn-primary form-control" onclick="vali(<?php echo e($bal); ?>)" >Completed</a></span>
            <?php else: ?>
          <span class="">  <a href="<?php echo e(URL::to('/')); ?>/salescompleted" class="btn btn-primary form-control">Completed</a></span>
        <?php endif; ?>
         <?php elseif(Auth::user()->group_id == 1 && Auth::user()->department_id == 0): ?>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/listingEngineer">Add New Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/roads">Update Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/requirementsroads">Project Enquiry</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/reports">My Report</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/lcoorders">Orders</a><br><br>
         <a href="<?php echo e(URL::to('/')); ?>/kra" class="form-control btn btn-primary">KRA</a><br><br> 
         
        <?php elseif(Auth::user()->group_id == 11 && Auth::user()->department_id == 2): ?>
          <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/accountlistingEngineer">Add New Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/accountroads">Update Project</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/accountrequirementsroads">Project Enquiry</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/accountreports">My Report</a><br><br>
         <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/lcoorders">Orders</a><br><br>
        <a href="<?php echo e(URL::to('/')); ?>/kra" class="form-control btn btn-primary">KRA</a><br><br>
        <a class="btn btn-primary form-control" href="<?php echo e(URL::to('/')); ?>/projectsUpdate" id="updates">Account Executive Projects</a><br><br>  
          <?php endif; ?>
          <br><br>
         <table class="table table-responsive table-striped table-hover" style="border: 2px solid gray;">
          <tbody >
                <!-- <tr>
                  <td style="border: 1px solid gray;"> <label>Total Number of Projects Listed till nOw</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($numbercount); ?></strong></td>
                </tr> -->
                <tr>
                  <td style="border: 1px solid gray;"> <label>Total Number of Projects Listed in Last 30Days</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($lastmonth); ?></strong></td>
                </tr>
                <tr>  
                  <td style="border: 1px solid gray;"><label>Total Number of Projects Listed Today</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($total); ?></strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>Enquiries Initiated </label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($ordersInitiated); ?></strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>Enquiries Confirmed</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($ordersConfirmed); ?><strong></td>
                </tr>
          </tbody>
        </table>
         <?php if(Auth::user()->group_id == 6 && Auth::user()->department_id == 1): ?>
        <!--  <table  class="table table-responsive table-striped table-hover" style="border: 2px  solid gray;">
          <tbody>
            <thead>
              <th style="text-align: center;" colspan="2">Total Listings</th>
          
            </thead>
         
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td style="border: 1px solid gray;"><label><?php echo e($user->name); ?></label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($totalListing[$user->id]); ?></strong></label></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table> -->
        <?php endif; ?>

         
        <table class="table table-responsive table-striped table-hover" style="border: 2px solid gray;">
          <tbody >
                <!-- <tr>
                  <td style="border: 1px solid gray;"> <label>Total Number of Projects Listed till nOw</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($numbercount); ?></strong></td>
                </tr> -->
                <tr>
                  <td style="border: 1px solid gray;"> <label>TOtal number of projects in <?php echo e($subwards->sub_ward_name); ?></label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($totalprojects); ?></strong></td>
                </tr>
                <tr>  
                  <td style="border: 1px solid gray;"><label>Genuine Projects</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($genuineprojects); ?></strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>Unverified Projects</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($unverifiedprojects); ?></strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>Fake Projects</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($fakeprojects); ?><strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>Updated Projects</label></td>
                  <td style="border: 1px solid gray;"><strong><?php echo e($update); ?><strong></td>
                </tr>
                <tr>
                  <td style="border: 1px solid gray;"><label>remaining Projects</label></td>
                  <td style="border: 1px solid gray;"><?php echo e($bal); ?><strong><strong></td>
                </tr>
          </tbody>
        </table>
        
        <?php endif; ?>
       </div>
        <div class="col-md-8"><br><br>
     
      <div id="map" style="width:1000px;height:500px"></div>
      </div>

    </div>
    <!-- <div class="row hidden">
      <div class="col-md-4 col-md-offset-4">
        <table class="table table-hover" border=1>
        <center><label for="Points">Your Points For Today</label></center>
          <thead>
            <th>Reason For Earning Point</th>
            <th>Point Earned</th>
          </thead>
          <tbody>
            <?php $__currentLoopData = $points_indetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $points): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo $points->reason; ?></td>
              <td style="text-align: right"><?php echo e($points->type == "Add" ? "+".$points->point : "-".$points->point); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: right;"><b>Total</b></td>
              <td style="text-align: right"><?php echo e($total); ?></td>
            </tr>
          </tbody>
        </table>
        </div>
    </div> -->
   
     
</div>
<script type="text/javascript" scr="https://maps.google.com/maps/api/js?sensor=false"></script>
<?php if(count($projects) == 0): ?>
<script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    var newpath = [];
    <?php if($subwardMap != "None"): ?>
    var latlng = "<?php echo e($subwardMap->lat); ?>";
    var col = "<?php echo e($subwardMap->color); ?>";
    <?php else: ?>
    var latlng = "";
    var col = "456369"
    <?php endif; ?>
    var places = latlng.split(",");
    for(var i=0;i<places.length;i+=2){
          newpath.push({lat: parseFloat(places[i]), lng: parseFloat(places[i+1])});
    }

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 16,
      center: new google.maps.LatLng(12.9716, 77.5946),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();
   
    var marker, i;
    var subward = new google.maps.Polygon({
        paths:  newpat,
        strokeColor: '#'+col,
        strokeOpacity: 1,
        strokeWeight: 2,
        fillColor: '#'+col,
        fillOpacity: 0.9
      });
  subward.setMap(map);
  }
  </script>
<?php else: ?>
  <script type="text/javascript">
    window.onload = function() {
    var locations = new Array();
    var created = new Array();
    var updated = new Array();
    var status = new Array();
    var newpath = [];
    <?php if($subwardMap != "None"): ?>
    var latlng = "<?php echo e($subwardMap->lat); ?>";
    var col = "<?php echo e($subwardMap->color); ?>";
    <?php else: ?>
    var latlng = "";
    var col = "456369"
    <?php endif; ?>
    var places = latlng.split(",");
    for(var i=0;i<places.length;i+=2){
          newpath.push({lat: parseFloat(places[i]), lng: parseFloat(places[i+1])});
    }
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      locations.push(["<a href=\"https://maps.google.com/?q=<?php echo e($project->address); ?>\"><?php echo e($project->project_id); ?> <?php echo e($project->project_name); ?>,<?php echo e($project->address); ?></a>",<?php echo e($project->latitude); ?>, <?php echo e($project->longitude); ?>]);
      created.push("<?php echo e($project->created_at); ?>");
      updated.push("<?php echo e($project->updated_at); ?>");
      status.push("<?php echo e($project->status); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15.5,
      center: new google.maps.LatLng(locations[0][1], locations[0][2]),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) { 
    if(created[i] == updated[i]){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
      });
    }else if(status[i] == "Order Confirmed"){
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'
      });
    }else{
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
      });
    }

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
    if(newpath.length > 1){
    
      var subward = new google.maps.Polygon({
          paths: newpath,
          strokeColor: '#'+col,
          strokeOpacity: 1,
          strokeWeight: 2,
          fillColor: '#'+col,
          fillOpacity: 0.4
        });
    subward.setMap(map);
    }
  }
  </script>
<?php endif; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGSf_6gjXK-5ipH2C2-XFI7eUxbHg1QTU&callback=myMap"></script>

<script>

</script>
<?php endif; ?>
<script>
  function vali(arg){

    alert("Please Update The Remaing Projects:" +arg);

  }


</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.leheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>