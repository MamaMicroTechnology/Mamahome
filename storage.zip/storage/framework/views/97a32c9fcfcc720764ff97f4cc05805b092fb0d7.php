<?php $__env->startSection('content'); ?>
<br><br>
<h2><center>WELCOME TO ZONAL MANAGER 
<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><br>
    <SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
</center></h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>