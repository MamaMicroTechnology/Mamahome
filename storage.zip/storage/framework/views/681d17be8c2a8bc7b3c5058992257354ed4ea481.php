<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-9 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading text-center" ><b>BreakTime</b>
            <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color: black;"></i></button>
            </div>
            <div class ="panel-body">
              <?php if(Auth::user()->group_id != 2): ?>
              <form method="GET" action="<?php echo e(URL::to('/')); ?>/breakhistory">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-12">
                            <div class="col-md-3">
                                <label>From Date</label>
                                <input required value = "<?php echo e(isset($_GET['from']) ? $_GET['from']: ''); ?>" type="date" class="form-control" name="from">
                            </div>
                            <div class="col-md-3">
                                <label>To   Date</label>
                                <input required value = "<?php echo e(isset($_GET['to']) ? $_GET['to']: ''); ?>" type="date" class="form-control" name="to">
                            </div>
                           
                        <div class="col-md-3">
                            <label></label>
                            <input type="submit" value="Fetch" class="form-control btn btn-primary">
                        </div>
                    </div> 
                </form>
                <?php endif; ?>
                       <table class="table table-hover">
                           <thead>
                               <th>Date</th>
                               <th>Name</th>
                               <th>Start Time</th>
                               <th>Stop Time</th>
                               <th>Time Taken</th>
                           </thead>
                            <tbody>
                            <?php $__currentLoopData = $breaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $break): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                    <td><?php echo e(date('d-m-Y',strtotime($break->date))); ?></td>
                                    <td><?php echo e($break->name); ?></td>
                                    <td><?php echo e($break->start_time); ?></td>
                                    <td><?php echo e($break->stop_time); ?></td>

                                    <td>
                                        <?php if($break->stop_time != null): ?>
                                        <?php
                                            $A = strtotime($break->start_time);
                                            $B = strtotime($break->stop_time);
                                            $diff = $B - $A;
                                             
                                         ?>
                                         <?php if(($diff / 60) > 60): ?>
                                             <?php echo e(gmdate("H", $diff)); ?> Hours, <?php echo e(gmdate("i", $diff)); ?> Minutes
                                         <?php else: ?>
                                            <?php echo e($diff / 60); ?> minutes</td>
                                         <?php endif; ?>
                                         <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                       </table>
            </div>
        </div>
    </div>
</div>

<?php if(session('Success')): ?>
<script>
    swal("success","<?php echo e(session('Success')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('Success')): ?>
<script>
    swal("error","<?php echo e(session('error')); ?>","error");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>