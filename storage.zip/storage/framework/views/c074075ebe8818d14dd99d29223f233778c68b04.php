<?php
	$user = Auth::user()->group_id;
	$ext = ($user == 4? "layouts.amheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<div class="col-md-8 col-md-offset-2">
		<div class="panel panel-default" style="border-color: #f4811f">
			<div class="panel-heading" style="background-color: #f4811f;text-align:center">
				<b style="font-size: 1.3em;color:white;">Enquiry Sheet</b>
				<?php $x=$enq->project_id ;
				?>
				 <?php if($x == ""): ?>   
				<b  class="pull-right" style="text-align:right;color:white;font-size:1.1em;">Manufacturer Type:&nbsp;<?php echo e($enq->manu != NULL ? $enq->manu->manufacturer_type:''); ?></b>
				<?php endif; ?>
				<br><br>
      <p>(Add Only One Category With One Enquiry,<br>
        Do Not Add All Category In Single Enquiry, <br>If You Want To Add All Categories Just Mension In Remarks)</p>
			</div>
			<div class="panel-body">
				<form method="POST" id="sub" action="<?php echo e(URL::to('/')); ?>/editinputdata">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" value="<?php echo e($enq->id); ?>" name="reqId">
					<?php if(SESSION('success')): ?>
					<div class="text-center alert alert-success">
						<h3 style="font-size:1.8em"><?php echo e(SESSION('success')); ?></h3>
					</div>
					<?php endif; ?>
					<?php if(session('Error')): ?>
					<div class="alert alert-danger alert-dismissable">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<?php echo e(session('Error')); ?>

					</div>
					<?php endif; ?>
					<table class="table table-responsive table-hover">
						<tbody>
							<tr>
								<td style="width:30%"><label>Requirement Date* : </label></td>
								<td style="width:70%"><input value="<?php echo e($enq->requirement_date); ?>" required type="date" name="edate" id="edate" class="form-control" style="width:30%" /></td>
							</tr>
							<tr>
								<td><label>Contact Number* : </label></td>
								<td>
									<?php echo e($enq->procurement_contact_no); ?> <?php echo e($enq->contractor_contact_no); ?> <?php echo e($enq->site_engineer_contact_no); ?>

									<?php echo e($enq->owner_contact_no); ?> <?php echo e($enq->consultant_contact_no); ?>


									 <?php echo e($enq->manu != NULL ? $enq->manu->contact_no:''); ?> <?php echo e($enq->proc != NULL ? $enq->proc->contact:''); ?>

									<!-- <input value="" required type="text" name="econtact" id='econtact' maxlength="10" onkeyup="check('econtact')" onblur="getProjects()" placeholder="10 Digits Only" class="form-control" /><div id="error"></div> -->
								</td>
							</tr>
							<!-- <tr>
								<td><label>Name* : </label></td>
								<td><input required type="text" name="ename" id="ename" class="form-control"/></td>
							</tr> -->
							<tr>
								<td><label>Project* : </label></td>
								<td>
									<?php echo e($enq->project_id); ?><?php echo e($enq->manu_id); ?>

								</td>
							</tr>	
							<tr>
								<td><label>Select category:</label></td>
								<td><button id="mybutton" type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">Product</button></td>
							</tr>
							
<?php
	$sub = explode(", ",$enq->quantity);
	$brands = explode(", ",$enq->brand);
?>

<!-- model -->
<div class="modal fade" id="myModal" role="dialog">
<div class="modal-dialog" style="width:80%">
<!-- Modal content-->
<div class="modal-content">
<div class="modal-header" style="background-color: rgb(244, 129, 31);color: white;" >
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title"><center>CATEGORY</center></h4>
</div>
<div class="modal-body" style="height:500px;overflow-y:scroll;">
    <br><br>
    <div class="row">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="panel panel-success">
                <div class="panel-heading"><?php echo e($cat->category_name); ?></div>
                <div class="panel-body" style="height:300px; max-height:300; overflow-y: scroll;">
						<?php
							$i = 0;
						?>
                <?php $__currentLoopData = $cat->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <b class="btn btn-sm btn-warning form-control" style="border-radius: 0px;" data-toggle="collapse" data-target="#demo<?php echo e($brand->id); ?>"><u><?php echo e($brand->brand); ?></u></b>
                    <br>
                    <div id="demo<?php echo e($brand->id); ?>" class="collapse">
                        <?php $__currentLoopData = $brand->subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <label class="checkbox-inline">
                                <input type="hidden" id="quantity<?php echo e($subcategory->id); ?>" value="<?php echo e($subcategory->Quantity); ?>">
                                <input <?php echo e(in_array($subcategory->sub_cat_name, explode(" :",$sub[$i])) ? 'checked' : ''); ?> type="checkbox" name="subcat[]" id="subcat<?php echo e($subcategory->id); ?>" value="<?php echo e($subcategory->id); ?>" id=""><?php echo e($subcategory->sub_cat_name); ?>

								<?php 
									$qnt = explode(' :',$sub[$i]);
								?>
								<input value= "<?php echo e(in_array($subcategory->sub_cat_name, explode(' :',$sub[$i])) ? $qnt[1] : ''); ?>" type="text" placeholder="Quantity" id="quan<?php echo e($subcategory->id); ?>" onblur="quan('<?php echo e($subcategory->id); ?>')" onkeyup="check('quan<?php echo e($subcategory->id); ?>')" autocomplete="off" name="quan[]" class="form-control">
                            </label>
                            <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php
								$i++;
								if($i == count($sub)){
									$i = 0;
								}
							?>
                        <center><span id="total" >total:</span></center>
                    </div>
                    <br>
                </div><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php if($loop->iteration % 3==0): ?>
        </div>
        <div class="row">
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
</div>
</div>
</div>
</div>
<!-- model end -->

							<?php if(Auth::user()->group_id == 7): ?>
							
							<tr>
								<td><label>Initiator* : </label></td>
								<td>	
									<select required class="form-control"  name="initiator">
										<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
							</tr>
								
							<?php elseif(Auth::user()->group_id == 6): ?>
							<tr>
								<td><label>Initiator* : </label></td>
								<td>	
									<select required class="form-control"  name="initiator">
										<?php $__currentLoopData = $users1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
							</tr>
							<?php else: ?>
									<?php if($enq->name == null): ?>
									<tr>
										<td><label>Initiator* : </label></td>
										<td>	
											<select required class="form-control"  name="initiator">
												<option value="">--Select--</option>
												<?php $__currentLoopData = $users2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</td>
									</tr>
									<?php else: ?>
									<tr>
										<td><label>Initiator* : </label></td>
										<td>	
											<select required class="form-control" name="initiator">
												
												
												<option value="<?php echo e($enq->name); ?>"><?php echo e($enq->name); ?></option>
												
											</select>
										</td>
									</tr>
								<?php endif; ?>
							<?php endif; ?>
							<tr>
								<td><label>Location* : </label></td>
								<td><?php echo e($enq->address); ?><?php echo e($enq->manu != NULL ? $enq->manu->address:''); ?></td>
							</tr>

                              <tr>
    <td><label>Billing And Shipping Address : </label></td>
    <td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal4">
 Address
</button>
<!-- The Modal -->
<div class="modal" id="myModal4">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Billing And Shipping Address </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       
        <label>Blling Adderss</label>
            <textarea class="form-control" type="text" name="billadress" cols="70" rows="7" style="resize:none;" value="<?php echo e($enq->billadress); ?>"><?php echo e($enq->billadress); ?>

        </textarea>
            
       <br>
        <label>Shipping Adderss &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label><br><br>
        <div class="col-md-12">
            <div class="col-md-9">
               <label><input type="radio" name="name" id="ss" onclick="myfunction()">&nbsp;&nbsp;&nbsp;same Address</label><br><br>
            </div>
            
        </div>
        <label id="sp1">Shipping Adderss</label>
            <textarea class="form-control" id="sp" type="text" name="ship" cols="70" rows="7" style="resize:none;" value="<?php echo e($enq->ship); ?>">
            <?php echo e($enq->ship); ?>

        </textarea>
           <script type="text/javascript">
               function myfunction(){
          
                document.getElementById('sp').style.display = "none";
                document.getElementById('sp1').style.display = "none";
               }


           </script> 
       <br>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Save</button>
      </div>
</div>

      <!-- Modal footer -->

    </div>
  </div>



    </td>
</tr>

							<tr>
								<td><label>Quantity* : </label></td>
								<td><?php echo e($enq->quantity); ?></td>
							</tr>
							<tr>
								<td><label>Enquiry Quantity : </label></td>
								<td><input type="text" value="<?php echo e($enq->enquiry_quantity !=null ? $enq->enquiry_qantity : $enq->quantity); ?>" name="enquiryquantity" id="tquantity" class="form-control" />
								Before Entering the Enquiry Quantity Make Sure You Have Selected The Proper Sub-Category And Brand From Above Selection.<br>
								(Ex : 53 Grade:1500 )</td>
							</tr>
							<tr>
							<td><label>Brand :</label></td>
							<td><?php echo e($enq->brand); ?>(Note: Only One Brand For One Enquiry)</td>
							</tr>
							<tr>
								<td><label>Total Quantity : </label></td>
								<td><input  type="text" onkeyup="checkthis('totalquantity')" value="<?php echo e($enq->total_quantity); ?>" name="totalquantity" id="totalquantity" title="Three letter country code" class="form-control" />
								
								</td>

							</tr>
							<tr>
            <td><label>Price: </label></td>
            <td><input type="text"  name="price" placeholder="Enter price In Only Numbers" id="totalquantity"  class="form-control" required value="<?php echo e($enq->price); ?>" /></td>

                          </tr>
							<tr>
								<td><label>Remarks* : </label></td>
								<td>
									<textarea rows="4" cols="40" name="eremarks" id="eremarks" class="form-control" /><?php echo e($enq->notes); ?></textarea>
								</td>
							</tr>
						</tbody>
					</table>
					<input type="hidden" id="measure" name="measure">
					<div class="text-center">
						<button type="button" onclick="submiteditenq()" name="" id="" class="btn btn-md btn-success" style="width:40%" >Submit</button>
						<input type="reset" name="" class="btn btn-md btn-warning" style="width:40%" />
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script src="http://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript">
	function check(arg){
	 var input = document.getElementById(arg).value;
	    if(isNaN(input)){
		       document.getElementById(arg).value = "";
	    }
	    document.getElementById('econtact').style.borderColor = '';
	    if(input){
		    if(isNaN(input)){
		      while(isNaN(document.getElementById(arg).value)){
		      var str = document.getElementById(arg).value;
		      str     = str.substring(0, str.length - 1);
		      document.getElementById(arg).value = str;
		      }
		    }
		}
	}
	function getProjects()
	{
		var x = document.getElementById('econtact').value;
		document.getElementById('error').innerHTML = '';
		if(x)
		{
			$.ajax({
				type: 'GET',
				url: "<?php echo e(URL::to('/')); ?>/getProjects",
				data: {contact: x},
				async: false,
				success: function(response)
				{
					if(response == 'Nothing Found')
					{
						document.getElementById('econtact').style.borderColor = "red";
						document.getElementById('error').innerHTML = "<br><div class='alert alert-danger'>No Projects Found !!!</div>"; 
						document.getElementById('econtact').value = '';
					}
					else
					{
						var result = new String();
						result = "<option value='' disabled selected>----SELECT----</option>";
						for(var i=0; i<response.length; i++)
						{
							result += "<option value='"+response[i].project_id+"'>"+response[i].project_name+" - "+response[i].road_name+"</option>";
						}
						console.log(result);
						document.getElementById('selectprojects').innerHTML =result;	
					}
					
				}
			});
		}
	}    
	function getBrands(){
		var e = document.getElementById('mCategory');
	    var cat = e.options[e.selectedIndex].value;
	    if(cat == "All"){
	    	document.getElementById('brand').innerHTML = "<option value='All'>All</option>";
	    	document.getElementById('sCategory').innerHTML = "<option value='All'>All</option>";
	    }else{
	    	    $.ajax({
	    	        type:'GET',
	    	        url:"<?php echo e(URL::to('/')); ?>/getBrands",
	    	        async:false,
	    	        data:{cat : cat},
	    	        success: function(response)
	    	        {
	    	            console.log(response);
	    	            var ans = "<option value=''>--Select--</option><option value='All'>All</option>";
	    	            for(var i=0;i<response[0].length;i++)
	    	            {
	    	                ans += "<option value='"+response[0][i].id+"'>"+response[0][i].brand+"</option>";
	    	            }
	    	            document.getElementById('brand').innerHTML = ans;
	    	        }
	    	    });
	    	}
	}
	function getSubCat()
    {
        var e = document.getElementById("mCategory");
        var cat = e.options[e.selectedIndex].value;
        var brand = document.getElementById("brand").value;
        $.ajax({
            type:'GET',
            url:"<?php echo e(URL::to('/')); ?>/getSubCat",
            async:false,
            data:{cat : cat, brand: brand},
            success: function(response)
            {
                var text = "<option value='' disabled selected>----Select----</option><option value='All'>All</option>";
                for(var i=0; i < response[1].length; i++)
                {
                    text += "<option value="+response[1][i].id+">"+response[1][i].sub_cat_name+"</option>";
                }
                document.getElementById('sCategory').innerHTML = text;
                document.getElementById('measure').value = response[0].measurement_unit;
            }
        });    
    }
    function getAddress(){
    	var e = document.getElementById('selectprojects');
    	var projectId = e.options[e.selectedIndex].value;
    	$.ajax({
    		type: 'GET',
    		url: "<?php echo e(URL::to('/')); ?>/getAddress",
    		async: false,
    		data: { projectId : projectId},
    		success: function(response){
    			document.getElementById('elocation').value = response.address;
    		}
    	})
    }
</script>
<script type="text/javascript">
	 function getquantity()
	{
		var quan=document.myform.equantity.value;
			if(isNaN(quan)){
				document.getElementById('equantity').value="";
				myform.equantity.focus();
		     }
	}
	function checkthis(arg){
    var input = document.getElementById(arg).value;
    if(isNaN(input)){
               document.getElementById(arg).value = "";
    }

}
function submiteditenq(){
     if(document.getElementById("totalquantity").value == ""){
            window.alert("You Have Not Entered Total Quantity");
          }
        else{
            document.getElementById("sub").submit();
        }
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>