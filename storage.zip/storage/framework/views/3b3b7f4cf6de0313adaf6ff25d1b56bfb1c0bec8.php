<?php $__env->startSection('content'); ?>

<div class="col-md-4" style="overflow-y:scroll; height:570px; max-height:570px">
        <div class="panel panel-primary" style="overflow-x:scroll">
            <div class="panel-heading text-center">
                <b style="color:white">Category Officer Report</b>
            </div>
            <div class="panel-body">
				<?php if(Auth::user()->department_id != 1): ?>
            	<form method="GET" action="<?php echo e(URL::to('/')); ?>/catofficer">
				<?php else: ?>
				<form method="GET" action="<?php echo e(URL::to('/')); ?>/catofficer">
				<?php endif; ?>
                    <table class="table table-responsive">
	                    <tbody>
	                        <tr>
	                            <td>Select Category Sales Employee</td>
	                        </tr>
                            <tr>
                                <td>
                                    <select required name="se" class="form-control" id="selectle">
                                        <option disabled selected value="">(-- SELECT SE --)</option>
                                        <option value="ALL">All Category Officers</option>
                                        <?php if(Auth::user()->group_id != 22): ?>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(isset($_GET['se']) ? $_GET['se'] == $list->employeeId ? 'selected' : '' : ''); ?>  value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $tlUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(isset($_GET['se']) ? $_GET['se'] == $user->employeeId ? 'selected' : '' : ''); ?>  value="<?php echo e($user->employeeId); ?>"><?php echo e($user->name); ?></option>
    	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
	                                </select>
	                            </td>
	                        </tr>
	                        <tr>
	                            <td>Select From Date</td>
	                        </tr>
	                        <tr>
	                            <td>
	                                <input value="<?php echo e(isset($_GET['fromdate']) ? $_GET['fromdate'] : ''); ?>" type="date" placeholder= "From Date" class="form-control" id="fromdate" name="fromdate" />
	                            </td>
	                        </tr>
	                        <tr>
	                            <td>Select To Date</td>
	                        </tr>
	                        <tr>
	                            <td>
	                                <input value="<?php echo e(isset($_GET['todate']) ? $_GET['todate'] : ''); ?>" type="date"  placeholder= "To Date" class="form-control" id="todate" name="todate" />
	                            </td>
	                        </tr>
	                        <tr class="text-center">
	                            <td>
	                                <button class="btn bn-md btn-success" style="width:100%">Get Date Range Details</button>
	                            </td>
	                        </tr>
	                    </tbody>
	                </table>
            	</form>
            </div>
        </div>
        <div class="panel panel-default" style="border-color:green;">
            <div class="panel-heading text-center" style="background-color:green">
                <b style="color:white">Mini Report (Today)</b>
            </div>
            <div class="panel-body" style="overflow-x: scroll;">
                <table class="table table-striped" border="1">
                	<tr>
                		<th>Name</th>
                		<th>Projects Visited</th>
                		<th>Enquiry Added</th> 
                		<th>Genuine</th>
                		<th>call</th>
                	</tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
 
                        <td style="font-size: 10px; text-align: center;"><?php echo e($user->name); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['projectupdate']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['Enquiry']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['Genuine']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo e($noOfCalls[$user->id]['calls']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                </table>
            </div>
        </div>
    </div>

<div class="col-md-8">
    <div class="panel panel-primary" style="overflow-x:scroll">
        <div class="panel-heading" id="panelhead" style="padding:25px;">
           
            <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button>
        </div>
        <div class="panel-body" style="overflow-y:scroll; height:500px; max-height:500px">
            <table class='table pull-right' border="1" style="width:100%;margin-left:50%;">
                <thead>
                    <tr>
                        <th style="text-align:center">Project-ID</th>
                        <th style="text-align:center">Subward Name</th>
                        <th style="text-align:center" >Updater</th>
                        <th style="text-align:center">Quality</th>
                        <th style="text-align:center">Updated Location</th>
                        <th style="text-align:center">Project Location</th> 
                    </tr>
                </thead>
                <tbody id="mainPanel">
                        <?php $__currentLoopData = $str; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                       <tr>
                        <td style="text-align:center">
                        	<a href="<?php echo e(URL::to('/')); ?>/showThisProject?id=<?php echo e($sales->project_id); ?>"><?php echo e($sales->project_id); ?></a>
                        </td>
                        <td style="text-align:center">
                       <a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($sales->project_id); ?> && subward=<?php echo e($sales->sub_ward_id); ?>" target="_blank">
                               <?php echo e($sales->subwardids != null ? $sales->subwardids->sub_ward_name : ''); ?>

                                    </a>
                        </td>
                        <td style="text-align:center"><?php echo e($sales->user != null ? $sales->user->name :''); ?></td>
                        <td style="text-align:center"><?php echo e($sales->quality); ?></td>
                        <td style="text-align:center"><?php echo e($sales->location); ?></td>
                        <td style="text-align:center"><?php echo e($sales->siteaddress != null ? $sales->siteaddress->address :''); ?></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>