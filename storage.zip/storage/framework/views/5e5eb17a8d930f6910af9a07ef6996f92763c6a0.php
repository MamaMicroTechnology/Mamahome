<?php $__env->startSection('content'); ?>

    <?php
        $d=cal_days_in_month(CAL_GREGORIAN,11,2018);
        echo($d);
    ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('finance.layouts.headers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>