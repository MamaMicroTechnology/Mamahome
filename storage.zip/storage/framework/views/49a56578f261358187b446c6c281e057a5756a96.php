<?php $__env->startSection('content'); ?>

<div class="col-md-6 col-md-offset-3">
	<div class="panel panel-default">
		<div class="panel-heading">
			<?php if($loginTimes != null): ?>
				Report of <?php echo e(date('d-m-Y',strtotime($loginTimes->logindate))); ?>

			<?php else: ?>
				No records found
			<?php endif; ?>
		</div>
		<div class="panel-body">
		    <form method="GET" action="<?php echo e(URL::to('/')); ?>/reports">
					<div class="col-md-3">
						Choose Date:
					</div>
					<div class="col-md-4">
						<input required type="date" name="date" class="form-control input-sm">
					</div>
					<div>
						<button type="submit">Submit</button	>
					</div>
				</form><br>
			<label>Morning</label>
			<table class="table">
				<?php echo $display; ?>

			</table>

			<?php if($loginTimes != null && $loginTimes->morningMeter== NULL && !isset($_GET['date'])): ?>
			<?php if("08:20:00" > $now): ?>
			<form method="post" action="<?php echo e(URL::to('/')); ?>/addMorningMeter" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="morningCount" value="<?php echo e($projectCount); ?>">
				<table class="table">		
					<tr>
						<td>Meter Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="morningMeter" class="form-control"></td>
					</tr>
					<tr>
						<td>Meter Reading</td>
						<td>:</td>
						<td><input required type="text" name="morningMeterReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn form-control btn-xs btn-primary">
			</form>
			<?php endif; ?>
			<?php endif; ?>
			<?php if($loginTimes != null && $loginTimes->morningData  == NULL && !isset($_GET['date'])): ?>
			<?php if("08:20:00" > $now): ?>
			<form method="post" action="<?php echo e(URL::to('/')); ?>/addMorningData" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<table class="table">		
					<tr>
						<td>Data Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="morningData" class="form-control"></td>
					</tr>
					<tr>
						<td>Data Reading</td>
						<td>:</td>
						<td><input required type="text" name="morningDataReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn form-control btn-xs btn-primary">
			</form>
			<?php endif; ?>
			<?php endif; ?>
			<label>Evening</label>
			<table class="table">
			    <?php echo $evening; ?>

			</table>
			<?php if($loginTimes != null && $loginTimes->eveningMeter  == NULL && !isset($_GET['date'])): ?>
			<form method="POST" action="<?php echo e(URL::to('/')); ?>/eveningMeter" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<table class="table">
					<tr>
						<td>Meter Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="eveningMeterImage" class="form-control"></td>
					</tr>
					<tr>
						<td>Meter Reading</td>
						<td>:</td>
						<td><input required type="text" name="eveningMeterReading" class="form-control"></td>
					</tr>
					<!-- <tr>
						<td>Evening Remarks</td>
						<td>:</td>
						<td><input required type="text" name="eRemark" class="form-control"></td>
					</tr> -->
				</table>
				<input type="submit" value="Save" class="btn btn-primary btn-xs form-control">
			</form>
			<?php endif; ?>
			<?php if($loginTimes != null && $loginTimes->eveningData == Null && !isset($_GET['date'])): ?>
			<form method="POST" action="<?php echo e(URL::to('/')); ?>/eveningData" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="totalCount" value ="<?php echo e($projectCount); ?>">
				<table class="table">
					<tr>
						<td>Data Image</td>
						<td>:</td>
						<td><input required type="file" accept="image/*" name="eveningDataImage" class="form-control"></td>
					</tr>
					<tr>
						<td>Data Reading</td>
						<td>:</td>
						<td><input required type="text" name="eveningDataReading" class="form-control"></td>
					</tr>
				</table>
				<input type="submit" value="Save" class="btn btn-primary btn-xs form-control">
			</form>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>