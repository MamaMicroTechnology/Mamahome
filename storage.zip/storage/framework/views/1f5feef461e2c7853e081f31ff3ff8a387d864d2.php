<?php
  $user = Auth::user()->group_id;
  $ext = ($user == 4? "layouts.amheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <b style="font-size:1.4em;text-align:center">Cash Deposite Details &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Count : <?php echo e($countrec); ?></b>
                <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>"><b>Back</b></a>
            </div>
            <div class="panel-body">
                <table class="table table-responsive table-striped table-hover" border="1">
    				<thead>
                        <th style="text-align:center">Id</th>
                        <th style="text-align:center">User Name</th>
    				    <th style="text-align:center">OrderId</th>
                        <th style="text-align:center">Amount</th>
                        <th style="text-align: center">Image</th>
    					<th style="text-align:center">Bank Name</th>
                        <th style="text-align:center">Deposit Date</th>
                        <th style="text-align:center">Stutus</th>
                        

    					
                        <!-- <th style="text-aligh:center">View Invoice</th> -->
    				</thead>
    				<tbody>
                       <?php
                       $i = 1; 
                       ?>
                        <?php $__currentLoopData = $cash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td> <?php echo e($i++); ?></td>
                        <?php $__currentLoopData = $dep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($use->id == $view->user_id): ?>
                        <td style="text-align:center"><?php echo e($use->name); ?></td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <td style="text-align:center"><?php echo e($view->orderId); ?></td>
					        <td style="text-align:center">
					           <?php echo e($view->Amount); ?>

                            </td>
                            <td style="text-align:center">
                                  <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo e($view->id); ?>">
                                  Amount Image
                                  </button>
                            </td>   
  

  <!-- The Modal -->
  <div class="modal" id="myModal<?php echo e($view->id); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
    <div class="modal-header" style="background-color:#337ab7;padding:1px;">
          <h4 class="modal-title" style="color:white;">Amount Image</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <img src="<?php echo e(URL::to('/')); ?>/public/lcpayment/<?php echo e($view->image); ?>" style="width: 500px;height:500px">
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div>
					        <td style="text-align:center"><?php echo e($view->bankname); ?></td>
                            <td style="text-align:center"><?php echo e($view->bdate); ?></td>
                            
                           <td> 
                           <form  method="post" action="<?php echo e(URL::to('/')); ?>/close"  >
                            <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="orderid" value="<?php echo e($view->orderId); ?>">

                               <select class="form-control" name="status" style="width:50%;" onchange="this.form.submit()">

                                  <option  value="">----Select----</option>
                                 
                                  <option  <?php echo e($view->order->payment_status == "Closed" ? 'selected' : ''); ?> value="Closed" >Closed</option>
                                  <option  <?php echo e($view->order->payment_status == "Processing" ? 'selected' : ''); ?> value=" Processing"> Processing</option>

                                </select>

                           </form>
                         </td>
					      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					   
    			    </tbody>
    			</table>    
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>