<?php $__env->startSection('content'); ?>
<div class="">
	
	<div class="col-md-12">
		<div class="panel panel-default" style="border-color:green">
			 <div class="panel-heading" style="background-color: green;color:white;"><b>
			 Team Leader Training Video		
			 </b>
                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                    <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>">Back</a>
                </div>
			<div class="panel-body">
				
                     <table class="table table-responsive" >
                     	
                            <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
									<div class="col-md-4 " style="border: solid 1px green;">
		    						<br>
									<video class="img img-responsive" controls controlslist="nodownload">
		                                      <source src="<?php echo e(URL::to('/')); ?>/public/trainingvideo/<?php echo e($video->upload); ?>" type="video/mp4">
		                                      <source src="<?php echo e(URL::to('/')); ?>/public/trainingvideo/<?php echo e($video->upload); ?>" type="video/ogg">
		                              
		                             </video><br>
		                              <center style="color: green;font-size:20px;"><?php echo e($video->remark); ?></center>
		                           </div>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                         	</table>
	       	</div>
	    </div>
	</div>
</div> 
                    
						
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>