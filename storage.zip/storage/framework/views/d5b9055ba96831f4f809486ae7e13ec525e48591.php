<div class="panel panel-default">
<div class="panel-heading">Employees on <?php echo e($dept); ?></div>
<div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
<table class="table table-hover">
<thead>
    <th>Emp Id</th>
    <th>Name</th>
    <th>Dept.</th>
    <th>Office Phone</th>
    <th>Acceptance</th>
    <th>Designation</th>
</thead>
<tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->employeeId); ?></td>
        <td><a href="<?php echo e(URL::to('/')); ?>/viewEmployee?UserId=<?php echo e($user->employeeId); ?>"><?php echo e($user->name); ?></a></td>
        <td>
            <?php if($user->department != NULL): ?>
                <?php echo e($user->department->dept_name); ?>

            <?php endif; ?>
        </td>
        <td>
            <?php if($user->confirmation == 0): ?>
             User has not accepted the company policy.
             <?php elseif($user->confirmation == 1): ?>
             User has accepted company policy<br>but waiting for admin's approval.
             <?php else: ?>
             User has accepted company policy<br>and has been approved by admin.
             <?php endif; ?>
        </td>
        <td><?php echo e($user->group->group_name); ?></td>
        <td><?php echo e($user->office_phone); ?></td>
        <?php if($page == "anr"): ?>
        <td>
        <?php if($user->department_id != 10): ?>
            <?php if($user->department->dept_name == "Operation" && $user->group->group_name == "Listing Engineer"): ?>
            <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($user->id); ?>/date">
                Report
            </a>
            <?php else: ?>
            <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($user->employeeId); ?>/attendance">
                Attendance
            </a>
            <?php endif; ?>
        <?php else: ?>
            <?php if($user->group->group_name == "Listing Engineer"): ?>
            <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($user->id); ?>/date">
                Report
            </a>
            <?php else: ?>
            <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($user->employeeId); ?>/attendance">
                Attendance
            </a>
            <?php endif; ?>
        <?php endif; ?>
        </td>
        <?php endif; ?>
        <?php if($page == "hr" && $user->department != NULL): ?>
        <td>
            <div class="btn-group">
                <a href="<?php echo e(URL::to('/')); ?>/viewEmployee?UserId=<?php echo e($user->employeeId); ?>" class="btn btn-sm btn-primary">View</a>
                <a href="<?php echo e(URL::to('/')); ?>/editEmployee?UserId=<?php echo e($user->employeeId); ?>" class="btn btn-sm btn-success">Edit</a>
            </div>
        </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>