<?php $__env->startSection('content'); ?>

<div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://mmtchat.herokuapp.com">
    <!-- <iframe class="embed-responsive-item" src="http://localhost:3000"> -->
        <p>Your browser does not support iframes.</p>
    </iframe>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.leheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>