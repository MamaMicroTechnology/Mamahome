<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading text-center" ><b>Late Logins</b></div>
            <div class ="panel-body">
              <form method="GET" action="<?php echo e(URL::to('/')); ?>/loginhistory">
                <div class="col-md-12">
                    <?php echo e(csrf_field()); ?>

                            <div class="col-md-2">
                                <label>From Date</label>
                                <input required value = "<?php echo e(isset($_GET['from']) ? $_GET['from']: ''); ?>" type="date" class="form-control" name="from">
                            </div>
                            <div class="col-md-2">
                                <label>To   Date</label>
                                <input required value = "<?php echo e(isset($_GET['to']) ? $_GET['to']: ''); ?>" type="date" class="form-control" name="to">
                            </div>
                           
                        <div class="col-md-2">
                            <label></label>
                            <input type="submit" value="Fetch" class="form-control btn btn-primary">
                        </div>
                    </div> 
                </form>     
                       <table class="table table-hover">
                           <thead>
                               <th>Date</th> 
                               <th>Name</th>
                               <th>Login Time</th>
                               <th>Logout Time</th>
                               <th>Late Login Remark</th>
                               <th>Early Logout remark</th>
                               <th>Admin Approval</th>
                               <th>Action</th>
                           </thead>
                            <tbody>
                          
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-Y',strTotime($user->logindate))); ?></td>
                                    <td style="width:10%"><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->logintime); ?></td>
                                    <td><?php echo e($user->logout != null ? $user->logout  : " "); ?></td>
                                    <td style="width:20%"><?php echo e($user->remark); ?></td>
                                    <td style="width:10%"><?php echo e($user->logout_remark); ?></td>
                                    <td><?php echo e($user->adminapproval); ?></td>
                                        <?php if( $user->hrapproval == "Pending" ): ?>
                                        <td>
                                        <div class="btn-group">
                                            <form action="<?php echo e(URL::to('/')); ?>/hrapprove" method="post">
                                                 <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($user->user_id); ?>">
                                             <input type="hidden" name="logindate" value="<?php echo e($user->logindate); ?>">
                                            <button type="submit" class="btn btn-success btn-sm" style="width:90%;">
                                                Approve
                                            </button>
                                            </form>
                                            <form action="<?php echo e(URL::to('/')); ?>/hrreject" method="post">
                                                 <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($user->user_id); ?>">
                                            <input type="hidden" name="logindate" value="<?php echo e($user->logindate); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" style="width:90%;margin-top:-81%;margin-left:90%;">
                                                Reject
                                            </button>
                                        </form>
                                        </div>
                                        </td>
                                        <?php else: ?>
                                        <td style="padding-right :60px;"><?php echo e($user->hrapproval); ?></td>
                                        <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                       </table>
            </div>
        </div>
    </div>
<?php if(session('Success')): ?>
<script>
    swal("success","<?php echo e(session('Success')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    swal("error","<?php echo e(session('error')); ?>","error");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>