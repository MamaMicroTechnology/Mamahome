<?php $__env->startSection('content'); ?>
<div style="background-color:white" class="container" >
<h2 ><center>WELCOME TO MAMA MICRO TECHNOLOGY
<BR><BR>
    <SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
</center></h2></div>
<?php if(session('Success')): ?>
<script>
    swal("success","<?php echo e(session('Success')); ?>","success");
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    swal("success","<?php echo e(session('error')); ?>","success");
</script>
<?php endif; ?>


<?php if(session('earlylogout')): ?>
  <div class="modal fade" id="emplate" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header" style="background-color: #f27d7d;color:white;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Early logout</h4>
        </div>
        <div class="modal-body">
          <p style="text-align:center;"><?php echo session('earlylogout'); ?></p>  
        </div>
        <div class="modal-footer">
          <button type="button" style="background-color: #c9ced6;" class="btn btn-default" data-dismiss="modal" onClick="window.location.reload()">Close</button>
        </div>
      </div>
    </div>
  </div>
  
<script type="text/javascript">
  $(document).ready(function(){
      $("#emplate").modal('show');
  });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>