<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-md-offset-4">
	<div class="panel panel-default">
		<div class="panel-heading">Select Road
			<form>
				
			</form>
		</div>
		<div class="panel-body">
			<ul class="list-group">
				<li class="list-group-item">
					<a href="<?php echo e(URL::to('/')); ?>/projectlist?road=<?php echo e($todays); ?>&today=today">Today's Listing (<?php echo e($todays); ?> projects)</a>
				</li>
				<?php $__currentLoopData = $roads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $road): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($projectCount[$road] > 0): ?>
				<li class="list-group-item"><a href="<?php echo e(URL::to('/')); ?>/projectlist?road=<?php echo e($road); ?>"><?php echo e($road); ?> (<?php echo e($projectCount[$road]); ?> projects)</a></li>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>