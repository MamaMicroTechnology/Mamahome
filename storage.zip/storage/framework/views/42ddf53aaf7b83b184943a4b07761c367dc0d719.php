<?php
  $user = Auth::user()->group_id;
  $ext = ($user == 4? "layouts.amheader":"layouts.app");
?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <b style="font-size:1.4em;text-align:center">Delivered Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Count : <?php echo e($countrec); ?></b>
                <a class="pull-right btn btn-sm btn-danger" href="<?php echo e(url()->previous()); ?>"><b>Back</b></a>
            </div>
            <div class="panel-body">
                <table class="table table-responsive table-striped table-hover" border="1">
    				<thead>
    				    <th style="text-align:center">Order ID</th>
    				    <th style="text-align:center">Project Id</th>
    					<th style="text-align:center">Main Category</th>
    					<th style="text-align:center">Sub Category</th>
    					<th style="text-align:center">Quantity</th>
    					<th style="text-align:center">Status</th>
    					<th style="text-align:center">Requirement Date</th>
                        <!-- <th style="text-aligh:center">View Invoice</th> -->
    				</thead>
    				<tbody>
                       
                        <?php $__currentLoopData = $rec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e(in_array($view->orderid, $invoice) ? 'hidden' : ''); ?>">

					        <td style="text-align:center">
					            <a href="<?php echo e(URL::to('/')); ?>/inputinvoice?id=<?php echo e($view->orderid); ?>" target="_blank"><?php echo e($view->orderid); ?></a>
					        </td>
							<td style="text-align:center"><?php echo e($view->project_id); ?></td>
					        <td style="text-align:center"><?php echo e($view->main_category); ?></td>
					        <td style="text-align:center"><?php echo e($view->sub_category); ?></td>
					        <td style="text-align:center"><?php echo e($view->quantity); ?></td>
					        <td style="text-align:center"><?php echo e($view->status); ?></td>
					        <td style="text-align:center"><?php echo e(date('d-m-Y', strtotime($view->requirement_date))); ?></td>
                            <!-- <td style="text-align:center">
                                <a href="<?php echo e(URL::to('/')); ?>/invoice?id=<?php echo e($view->orderid); ?>">View Invoice</a>
                            </td> -->
					    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					   
    			    </tbody>
    			</table>    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>