<div class="panel panel-default" style="border-color:#f4811f">
<div class="panel-heading" style="background-color:#f4811f">
    <b style="color:white;font-size:1.3em">Employees on <?php echo e($dept); ?></b>
</div>
<div class="panel-body" style="height:500px;max-height:500px;overflow-x:hidden; overflow-y:scroll;">
<table class="table table-hover">
<thead>
    <th>Emp Id</th>
    <th>Name</th>
    <th>Email</th>
    <th>Expenses</th>
</thead>
<tbody>
<?php if($dept == "Operation"): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $total = 0;
        $total2 = 0;
    ?>
        <tr>
        <td><?php echo e($user->employeeId); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td>
            <table id="current<?php echo e($user->employeeId); ?>" class="table table-responsive table-hover" border="1">
                <thead>
                    <th>Date</th>
                    <th>LE</th>
                    <th>TL<button onclick="edit('<?php echo e($user->employeeId); ?>')" class="pull-right btn-success" type="button">Edit</button>
                    </th>
                </thead>
                <tbody>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->id == $expense->user_id): ?>
                    <tr>
                        <td><?php echo e($expense->logindate); ?></td>
                        <td><?php echo $cal = $expense->afternoonMeter - $expense->gtracing; ?></td>
                        <td>
                            <?php if($expense->total_kilometers != NULL): ?>
                                <?php echo e($expense->total_kilometers); ?>

                                <?php $total += $expense->total_kilometers; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Total</td>
                <td></td>
                <td><?php echo e($total); ?>km X ₹2 = ₹<?php echo e($total * 2); ?></td>
            </tr>
            </tbody>
            </table>
            
            <form method="post" action="<?php echo e(URL::to('/')); ?>/savePetrolExpenses">
                <?php echo e(csrf_field()); ?>

            <table id="edit<?php echo e($user->employeeId); ?>" class="hidden" border="1">
                <thead>
                    <th>Date</th>
                    <th>LE</th>
                    <th>TL<button onclick="cancel('<?php echo e($user->employeeId); ?>')" class="pull-right btn-success" type="button">Close</button>
                    <button onclick="submit('<?php echo e($user->employeeId); ?>')" class="pull-right btn-primary">Submit</button>
                    </th>
                </thead>
                <tbody>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->id == $expense->user_id): ?>
                    <tr>
                        <td><?php echo e($expense->logindate); ?></td>
                        <td><?php echo $cal = $expense->afternoonMeter - $expense->gtracing; ?></td>
                        <td>
                            <input type="hidden" value="<?php echo e($expense->id); ?>" name="id[]" class="form-control">
                            <input type="text" value="<?php echo e($expense->total_kilometers); ?>" name="exp[]" class="form-control">
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Total</td>
                <td></td>
                <td><?php echo e($total); ?>km X ₹2 = ₹<?php echo e($total * 2); ?></td>
            </tr>
            </tbody>
            </table>
            </form>
        </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($user->employeeId); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td>N/A</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<script>
    function edit(arg){
        var edit = 'edit'+arg;
        var current = 'current'+arg;
        document.getElementById(edit).className="table table-responsive table-hover";
        document.getElementById(current).className="hidden";
    }
    function cancel(arg){
        var edit = 'edit'+arg;
        var current = 'current'+arg;
        document.getElementById(edit).className="hidden";
        document.getElementById(current).className="table table-responsive table-hover";
    }
</script>

