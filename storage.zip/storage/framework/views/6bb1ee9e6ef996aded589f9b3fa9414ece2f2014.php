<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
               <div class="col-md-4">Project Details</div>
               <div class="pull-center col-md-4"><center>Project Id <?php echo e($details->project_id); ?></center></div>
               <div class="pull-right col-md-4">
                <a href="<?php echo e(URL::to('/')); ?>/ameditProject?projectId=<?php echo e($details->project_id); ?>" class="btn btn-warning btn-sm pull-right">Edit</a>
               </div>
              <br>
            </div>
            <div class="panel-body">
                <table class="table table-responsive table-striped table-hover">
                    <tbody>
                        <tr>
                            <td style="width:40%"><b>Listed On : </b></td>
                            
                            <td><?php echo e(date('d-m-Y h:i:s A',strtotime($details->created_at))); ?></td>
                        </tr>
                       
                         <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->department_id != 2): ?>
                        <tr>
                            <td><b>Listed By : </b></td>
                            <td>
                                <?php echo e($listedby != null ? $listedby->name : ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <td style="width:40%"><b>Call Attended By : </b></td>
                            <td><?php echo e($callAttendedBy != null ? $callAttendedBy->name: ''); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endif; ?>
                        <tr>
                            <td style="width:40%"><b>Updated On : </b></td>
                            <td><?php echo e(date('d-m-Y h:i:s A',strtotime($details->updated_at))); ?></td>
                        </tr>
                        
                        <tr>
                            <td><b>Project Name : </b></td>
                            <td><?php echo e($details->project_name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Road Name/Road No./Landmark : <b></td>
                            <td><?php echo e($details->road_name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Road Width : <b></td>
                            <td><?php echo e($details->road_width); ?></td>
                        </tr>
                       <tr>
                            <td><b>Address : </b></td>
                            <td>
                                <a target="_blank" href="https://maps.google.com?q=<?php echo e($details->siteaddress != null ? $details->siteaddress->address : ''); ?>"><?php echo e($details->siteaddress != null ? $details->siteaddress->address : ''); ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td><b>Construction Type : </b></td>
                            <td><?php echo e($details->construction_type); ?></td>
                        </tr>
                        <tr>
                            <td><b>Interested in RMC ? : </b></td>
                            <td><?php echo e($details->interested_in_rmc); ?></td>
                        </tr>
                        <tr>
                            <td><b>Interested In Bank Loans ? :</b></td>
                            <td><?php echo e($details->interested_in_loan); ?></td>
                        </tr>
                          <tr>
                            <td><b>Interested In UPVC Doors And Windows ? : </b></td>
                            <td><?php echo e($details->interested_in_doorsandwindows); ?></td>
                        </tr>
                        <tr>
                            <td><b>Interested In Kitchen Cabinates and Wardrobes ? : </b></td>
                            <td><?php echo e($details->Kitchen_Cabinates); ?></td>
                        </tr>
                        <tr>
                            <td><b>Interested In Brila Super / Ultratech Products? : </b></td>
                            <td><?php echo e($details->brilaultra); ?></td>
                        </tr>
                         <tr>
                            <td><b>Interested in Home Automation ? : </b></td>
                            <td><?php echo e($details->automation); ?></td>
                        </tr>
                         <tr>
                            <td><b>Interested in Premium Products ? : </b></td>
                            <td><?php echo e($details->interested_in_premium); ?></td>
                        </tr>
                        <tr>
                            <td><b>Type of Contract : </b></td>
                            <td>
                                <?php if($details->contract == "With Material Contractor"): ?>
                                    Material Contract
                                <?php elseif($details->contract == "With Labour Contractor"): ?>
                                    Labour Contract
                                <?php else: ?>
                                    <?php echo e($details->contract); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="width:40%"><b>Sub-ward : </b></td>
                            <td><a href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($details->project_id); ?> && subward=<?php echo e($subward); ?>" data-toggle="tooltip" data-placement="top" title="click here to view map" class="red-tooltip" target="_blank"><?php echo e($subward); ?>

                                    </a></td>
                        </tr>
                        <tr>
                            <?php if($details->municipality_approval == "N/A"): ?>
                            <td><b>Govt. Approvals(Municipal, BBMP, etc) : </b></td>
                            <td>None</td>
                            <?php else: ?>
                            <td><b>Govt. Approvals(Municipal, BBMP, etc) : </b></td>
                            <td><img height="350" width="350"  src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($details->municipality_approval); ?>" class="img img-thumbnail"></td>
                            <?php endif; ?>
                        </tr>
                         <tr>
                            <td><b>Project Status : </b></td>
                            <td><?php echo e($details->project_status); ?></td>
                        </tr>
                        <tr>
                            <td><b>Project Type : </b></td>
                            <td>B<?php echo e($details->basement); ?> + G + <?php echo e($details->ground); ?> = <?php echo e($details->basement + $details->ground + 1); ?></td>
                        </tr>
                         <tr>
                            <td><b>Project Size : </b></td>
                            <td><?php echo e($details->project_size); ?></td>
                        </tr>
                        <tr>
                            <td><b>Plot Size : </b></td>
                            <td>L(<?php echo e($details->length); ?>) * B (<?php echo e($details->breadth); ?>) = <?php echo e($details->plotsize); ?></td>
                        </tr>
                       <tr> 
                            <td><b>Budget (Cr.) : </b></td>
                            <td>
                                <?php echo e($details->budget); ?> Cr.              [  <?php echo e($details->budgetType); ?>  ]
                            </td>
                        </tr>
                        <tr>
                                <td style="width:40%;"><b>Budget (per sq.ft) :</b></td>
                                <td>
                                    <?php if($details->project_size != 0): ?>
                                        <?php echo e(round((10000000 * $details->budget)/$details->project_size,3)); ?>

                                    <?php endif; ?>
                                </td>
                        </tr>
                        <tr>
                            <td><b>Project Image : </b></td>
                            <td>
                               <?php
                                               $images = explode(",", $details->image);
                                               ?>
                                             <div class="row">
                                                 <?php for($i = 0; $i < count($images); $i++): ?>
                                                     <div class="col-md-3">
                                                          <img height="350" width="350"  src="<?php echo e(URL::to('/')); ?>/public/projectImages/<?php echo e($images[$i]); ?>" class="img img-thumbnail">
                                                     </div>
                                                 <?php endfor; ?>
                                              </div>
                            </td>
                            </td>
                        </tr>
                        
                        <tr>
                                 <td><b>Image Updated On : </b></td>
                                
                                  <?php if($projectupdate == null): ?>
                                  <td><?php echo e(date('d-m-Y h:i:s A', strtotime($details->created_at))); ?></td>
                                  <?php else: ?>
                                      <td><?php echo e(date('d-m-Y h:i:s A', strtotime($projectupdate))); ?></td>
                                  <?php endif; ?>
                                 
                                 
                               </tr>

                        <tr>
                        <tr>
                            <td style="width:40%"><b>Followup Started : </b></td>
                            <td><?php echo e($details->followup); ?> <?php if($followupby): ?> (marked by <?php echo e($followupby->name); ?>) <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td><b>Questions :</b></td>
                            <td><?php echo e($details->with_cont); ?></td>
                        </tr>
                        <tr>
                            <td><b>Quality :</b></td>
                            <td><?php echo e($details->quality); ?></td>
                        </tr>
                        <tr>
                            <td><b>Remarks : </b></td>
                            <td>
                                <?php echo e($details->remarks); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
 
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:orange">
            <div class="panel-heading" style="background-color:orange">
               <b style="color:white">Room Types</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Floor No.</th>
                        <th>Room Type</th>
                        <th>No. Of House</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($roomtype->floor_no); ?></td>
                            <td><?php echo e($roomtype->room_type); ?></td>
                            <td><?php echo e($roomtype->no_of_rooms); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Owner Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Owner Name</th>
                        <th>Owner Contact</th>
                        <th>Owner Email</th>
                    </thead>
                    <tbody>
                        <tr>
                             <td><?php echo e($details->ownerdetails != null ? $details->ownerdetails->owner_name : ''); ?></td>
                              <td><?php echo e($details->ownerdetails != null ? $details->ownerdetails->owner_contact_no : ''); ?></td>
                           <td><?php echo e($details->ownerdetails != null ? $details->ownerdetails->owner_email : ''); ?></td>
                           
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:orange">
            <div class="panel-heading" style="background-color:orange">
               <b style="color:white">Contractor Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Contractor Name</th>
                         <th>Contractor Contact</th>
                         <th>Contractor Email</th>
                    </thead>    
                    <tbody>
                        <tr>
                            <td><?php echo e($details->contractordetails != null ? $details->contractordetails->contractor_name : ''); ?></td>
                            <td><?php echo e($details->contractordetails != null ? $details->contractordetails->contractor_contact_no : ''); ?></td>
                            <td><?php echo e($details->contractordetails != null ? $details->contractordetails->contractor_email : ''); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Consultant Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th> Consultant Name</th>
                       <th> Consultant Contact</th>
                       <th> Consultant Email</th>
                    </thead>    
                    <tbody>
                        <tr>
                            <td><?php echo e($details->consultantdetails != null ? $details->consultantdetails->     consultant_name : ''); ?></td>
                              <td><?php echo e($details->consultantdetails != null ? $details->consultantdetails->consultant_contact_no : ''); ?></td>
                            <td><?php echo e($details->consultantdetails != null ? $details->consultantdetails->consultant_email : ''); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:orange">
            <div class="panel-heading" style="background-color:orange">
               <b style="color:white">Site Engineer Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Site Engineer Name</th>
                        <th>Site Engineer Contact</th>
                        <th>Site Engineer Email</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($details->siteengineerdetails != null ? $details->siteengineerdetails->site_engineer_name : ''); ?></td>
                            <td><?php echo e($details->siteengineerdetails != null ? $details->siteengineerdetails->site_engineer_contact_no : ''); ?></td>
                            <td><?php echo e($details->siteengineerdetails != null ? $details->siteengineerdetails->site_engineer_email : ''); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>  
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Procurement Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Procurement Name</th>
                        <th>Procurement Contact</th>
                        <th>Procurement Email</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($details->procurementdetails != null ? $details->procurementdetails->procurement_name : ''); ?></td>
                            <td><?php echo e($details->procurementdetails != null ? $details->procurementdetails->procurement_contact_no : ''); ?></td>
                            <td><?php echo e($details->procurementdetails != null ? $details->procurementdetails->procurement_email : ''); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default" style="border-color:green">
            <div class="panel-heading" style="background-color:green">
               <b style="color:white">Builder Details</b> 
            </div>
            <div class="panel-body">
                <table class="table table-hover">
                    <thead>
                        <th>Builder Name</th>
                        <th>Builder Contact</th>
                        <th>Builder Email</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($details->builders != null ? $details->builders->builder_name : ''); ?></td>
                            <td><?php echo e($details->builders != null ? $details->builders->builder_contact_no : ''); ?></td>
                            <td><?php echo e($details->builders != null ? $details->builders->builder_email : ''); ?></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
     background-color: #00acd6 

});
</script>

      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>