<?php $__env->startSection('content'); ?>
<br><br>
<div style="background-color:white" class="container" >
<h2 ><center>WELCOME TO FINANCE
<br>ZONE 1, BANGALORE'S DASHBOARD
<BR><BR>
    <SMALL>You must know your responsibilities and carry out your tasks responsibly.<br>
    We appreciate you services.
    </SMALL>
</center></h2></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('finance.layouts.headers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>