<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      List of projects under you:<br>
      <table class="table">
        <thead>
          <th>Project Name</th>
          <th>Address</th>
          <th>Status</th>
          <th>Procurement Name</th>
          <th>Procurement Contact No.</th>
          <th>Action</th>
        </thead>
        <tbody>
          <?php $__currentLoopData = $projectlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($project->quality == NULL || $project->quality == 'Genuine'): ?>
            <tr>
              <td><?php echo e($project->project_name); ?></td>
              <td>
                <a href="https://www.google.com/maps/place/<?php echo e($project->siteaddress->address); ?>/{{ $project->siteaddress->latitude }},<?php echo e($project->siteaddress->longitude); ?>"><?php echo e($project->siteaddress->address); ?></a>
              </td>
              <td><?php echo e($project->project_status); ?></td>
              <td><?php echo e($project->procurementdetails->procurement_name); ?></td>
              <td><?php echo e($project->procurementdetails->procurement_contact_no); ?></td>
              <td><?php echo e($project->room_types); ?></td>
              <td>
              <?php if($pageName == "Update"): ?>
                <a href="<?php echo e(URL::to('/')); ?>/edit?projectId=<?php echo e($project->project_id); ?>" class="btn btn-default input-sm">Edit</a>
              <?php else: ?>
                <a href="<?php echo e(URL::to('/')); ?>/requirements?projectId=<?php echo e($project->project_id); ?>" class="btn btn-default input-sm">View</a>
              <?php endif; ?>
              </td>
            </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>