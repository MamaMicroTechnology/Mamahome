<?php
	$user = Auth::user()->group_id;
	$ext = ($user == 4? "layouts.amheader":"layouts.app");
?>


<?php $__env->startSection('content'); ?>
<div class="col-md-12">
		<div class="panel panel-primary" >
			 <div class="panel-heading text-center" ><b>
			 	<p class="pull-left">Total Enquiry Count : <?php echo e($cancelcount); ?></p>
			 Enquiry Cancelled		 	
			 </b>
                    <?php if(session('ErrorFile')): ?>
                        <div class="alert-danger pull-right"><?php echo e(session('ErrorFile' )); ?></div>
                    <?php endif; ?> 
                    <button type="button" onclick="history.back(-1)" class="bk-btn-triangle pull-right" style="margin-top:-10px;" > <i class="fa fa-arrow-circle-left" style="padding:5px;width:50px;color:black;"></i></button>
              </div>
			<div class="panel-body" style="overflow-x:scroll;overflow-y:scroll;height:1000px">

					<table id="myTable" class="table table-responsive table-striped table-hover">
					<thead>
						<tr>
							<th style="text-align: center">Project</th>
							<th style="text-align: center">Subward Number</th>
							<th style="text-align: center">Name</th>
							<th style="text-align: center">Requirement Date</th>
							<th style="text-align: center">Enquiry Date</th>
							<th style="text-align: center">Contact</th>
							<th style="text-align: center">Product</th>
							<th style="text-align: center">Quantity</th>
							<th style="text-align: center">Initiator</th>
							<th style="text-align: center">Status</th>
							<th style="text-align: center">Remarks</th>
							
							<!-- <th style="text-align: center">Edit</th> -->
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
						<tr>
							<td style="text-align: center">
								<a href="<?php echo e(URL::to('/')); ?>/showThisProject?id=<?php echo e($enquiry -> project_id); ?>">
									<b><?php echo e($enquiry -> project_id); ?></b>
								</a> 
							</td>
							<td style="text-align: center">
							<a  href="<?php echo e(URL::to('/')); ?>/viewsubward?projectid=<?php echo e($enquiry -> project_id); ?> && subward=<?php echo e($subwards2[$enquiry->project_id]); ?>" data-toggle="tooltip" data-placement="top" title="click here to view map" class="red-tooltip" target="_blank"><?php echo e($subwards2[$enquiry->project_id]); ?>

                                    </a></td>
							<td style="text-align: center"><?php echo e($enquiry -> procurement_name); ?></td>
							<td style="text-align: center"><?php echo e($newDate = date('d/m/Y', strtotime($enquiry->requirement_date))); ?></td>
							<td style="text-align: center"><?php echo e(date('d/m/Y', strtotime($enquiry->created_at))); ?></td>
							<td style="text-align: center"><?php echo e($enquiry -> procurement_contact_no); ?></td>
							<td style="text-align: center"><?php echo e($enquiry -> main_category); ?> (<?php echo e($enquiry->sub_category); ?>), <?php echo e($enquiry->material_spec); ?></td>
							<td style="text-align: center"><?php echo e($enquiry -> quantity); ?></td>
							<td style="text-align: center"><?php echo e($enquiry -> name); ?></td>
							<td style="text-align: center">
								<?php echo e($enquiry->status); ?>

							</td>
							<td style="text-align: center" onclick="edit('<?php echo e($enquiry->id); ?>')" id="<?php echo e($enquiry->id); ?>">
								<form method="POST" action="<?php echo e(URL::to('/')); ?>/editEnquiry">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($enquiry->id); ?>" name="id">
									<input onblur="this.className='hidden'; document.getElementById('now<?php echo e($enquiry->id); ?>').className='';" name="note" id="next<?php echo e($enquiry->id); ?>" type="text" size="35" class="hidden" value="<?php echo e($enquiry->notes); ?>"> 
									<p id="now<?php echo e($enquiry->id); ?>"><?php echo e($enquiry->notes); ?></p>
								</form>
							</td>
							
							<!-- <td>
								<a href="<?php echo e(URL::to('/')); ?>/editenq?reqId=<?php echo e($enquiry->id); ?>" class="btn btn-xs btn-primary">Edit</a>
							</td> -->
						</tr>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
     background-color: #00acd6 

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($ext, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>