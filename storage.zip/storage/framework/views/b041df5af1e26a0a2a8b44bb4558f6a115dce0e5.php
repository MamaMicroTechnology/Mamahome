<?php $__env->startSection('content'); ?>
<br><br>
<h2><center>WELCOME TO AUDITOR DASHBOARD
<BR><br>
    <SMALL>This dashboard is temporarily created for the auditor<br>
    to give a glance of how planning can be done.
    </SMALL>
</center></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auditor.layout.auditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>